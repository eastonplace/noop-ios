#!/usr/bin/env python3
"""Extract unchanged production reclip math and reproduce old/fixed caller contracts."""
from pathlib import Path
import subprocess
import sys

repo = Path(sys.argv[1]).resolve()
swift = sys.argv[2]
out = Path(__file__).resolve().parent
source = (repo / "Packages/StrandAnalytics/Sources/StrandAnalytics/SleepWindowRecovery.swift").read_text()
start = source.index("enum SleepTimestampMath {")
cursor = source.index("{", start) + 1
depth = 1
while depth:
    depth += (source[cursor] == "{") - (source[cursor] == "}")
    cursor += 1
math = source[start:cursor]
reclip = (repo / "Packages/StrandAnalytics/Sources/StrandAnalytics/SleepWindowReclip.swift").read_text()
harness = out / "reclip_contract.swift"
harness.write_text(math + "\n" + reclip + r'''
let original = #"{"awake":30,"light":280,"deep":80,"rem":90}"#
let first = SleepWindowReclip.reclip(stagesJSON: original, sessionStart: 1000,
                                    oldEnd: 29800, newStart: 3400, newEnd: 29800)!
let legacySecond = SleepWindowReclip.reclip(stagesJSON: first, sessionStart: 1000,
                                           oldEnd: 29800, newStart: 3400, newEnd: 29800)!
let currentSecond = SleepWindowReclip.reclip(stagesJSON: first, sessionStart: 3400,
                                            oldEnd: 29800, newStart: 3400, newEnd: 29800)!
func minutes(_ value: String) -> [String: Double] {
    try! JSONSerialization.jsonObject(with: value.data(using: .utf8)!) as! [String: Double]
}
print("RED baseline caller: second identical save light=\(minutes(legacySecond)["light"]!), expected 270.0")
print("GREEN current-effective-onset caller: second identical save light=\(minutes(currentSecond)["light"]!), expected 270.0")
precondition(minutes(legacySecond)["light"] == 230)
precondition(minutes(currentSecond) == ["awake": 0, "light": 270, "deep": 80, "rem": 90])
''')
raise SystemExit(subprocess.call([swift, "-module-cache-path", "/tmp/noop-data-clang-cache", str(harness)]))
