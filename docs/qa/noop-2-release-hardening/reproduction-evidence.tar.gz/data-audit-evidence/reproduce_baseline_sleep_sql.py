#!/usr/bin/env python3
"""Synthetic DATA01/DATA04 repro; executes SQL extracted from audited base.

Uses a minimal SQLite fixture, not a copy of a user's database. Exits 1 when all
three expected regressions reproduce. Run from the repository or pass its path.
"""
import pathlib
import re
import sqlite3
import subprocess
import sys

REPO = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
BASE = "a7ade2598d439d33cd20816d69ccc991b29322fc"


def baseline(path):
    return subprocess.check_output(["git", "show", f"{BASE}:{path}"], cwd=REPO, text=True)


def sql_after(source, marker):
    return re.search(r'sql: """\n(.*?)\n\s*"""', source.split(marker, 1)[1], re.S)[1]


metrics = baseline("Packages/WhoopStore/Sources/WhoopStore/MetricsCache.swift")
schema = baseline("Packages/WhoopStore/Sources/WhoopStore/SleepRecoverySchema.swift")
edit = sql_after(metrics, "public func applySleepEdit(")
interval_read = sql_after(metrics, "public nonisolated func sleepSessions(")
invalidation = schema.split('migrator.registerMigration("sleep-window-recovery-invalidation-v1")', 1)[1]
invalidate = re.search(r'let invalidate = """\n(.*?)\n\s*"""', invalidation, re.S)[1]
delete_trigger = sql_after(invalidation, "let invalidate").replace(r"\(invalidate)", invalidate)

db = sqlite3.connect(":memory:")
db.executescript("""
CREATE TABLE sleepSession(deviceId TEXT, startTs INTEGER, endTs INTEGER,
  efficiency REAL, restingHr INTEGER, avgHrv REAL, stagesJSON TEXT,
  userEdited INTEGER DEFAULT 0, startTsAdjusted INTEGER, motionJSON TEXT,
  sleepStateJSON TEXT, PRIMARY KEY(deviceId,startTs));
CREATE TABLE sleepRecoveryDailyOverride(deviceId TEXT, day TEXT, sessionStartTs INTEGER,
  totalSleepMin REAL, efficiency REAL, deepMin REAL, remMin REAL, lightMin REAL,
  disturbances INTEGER, restingHr INTEGER, avgHrv REAL, recovery REAL,
  restScore REAL, updatedAt INTEGER, PRIMARY KEY(deviceId,day));
CREATE TABLE dailyMetric(deviceId TEXT, day TEXT, totalSleepMin REAL, efficiency REAL,
  deepMin REAL, remMin REAL, lightMin REAL, disturbances INTEGER, restingHr INTEGER,
  avgHrv REAL, recovery REAL, strain REAL, PRIMARY KEY(deviceId,day));
CREATE TABLE metricSeries(deviceId TEXT, day TEXT, key TEXT, value REAL,
  PRIMARY KEY(deviceId,day,key));
""")
db.executescript(delete_trigger)
owner = "my-whoop-noop"
db.execute("INSERT INTO sleepSession(deviceId,startTs,endTs,stagesJSON) VALUES(?,?,?,?)",
           (owner, 1000, 29800, '{"awake":30,"light":280,"deep":80,"rem":90}'))

# The baseline Repository generic edit tries only the active-device namespaces.
changed = 0
for device in ("whoop-readded-noop", "whoop-readded"):
    changed += db.execute(edit, (3400, 29800, None, device, 1000)).rowcount
print(f"RED canonical edit: {changed} rows updated; expected 1; stored onset "
      f"{db.execute('SELECT COALESCE(startTsAdjusted,startTs) FROM sleepSession').fetchone()[0]}")

# Its undo lookup uses the visible interval reader at the immutable start second.
db.execute("UPDATE sleepSession SET startTsAdjusted=3400,userEdited=1")
found = db.execute(interval_read, (owner, 1000, 1000, 4)).fetchall()
print(f"RED edited-row undo snapshot: {len(found)} rows resolved at immutable key; expected 1")

# Baseline undo reinserts only session+aux tracks after this real delete trigger.
day = "2026-10-20"
db.execute("INSERT INTO sleepRecoveryDailyOverride(deviceId,day,sessionStartTs,recovery,restScore) "
           "VALUES(?,?,?,?,?)", (owner, day, 1000, 78, 88))
db.execute("INSERT INTO dailyMetric(deviceId,day,recovery,strain) VALUES(?,?,?,?)", (owner, day, 78, 25))
db.execute("INSERT INTO metricSeries VALUES(?,?,?,?)", (owner, day, "sleep_performance", 88))
snapshot = db.execute("SELECT * FROM sleepSession").fetchone()
db.execute("DELETE FROM sleepSession WHERE deviceId=? AND startTs=?", (owner, 1000))
db.execute("INSERT INTO sleepSession VALUES(" + ",".join("?" for _ in snapshot) + ")", snapshot)
overrides = db.execute("SELECT count(*) FROM sleepRecoveryDailyOverride").fetchone()[0]
recovery = db.execute("SELECT recovery FROM dailyMetric").fetchone()[0]
rest = db.execute("SELECT count(*) FROM metricSeries WHERE key='sleep_performance'").fetchone()[0]
print(f"RED recovered undo: override count {overrides}; expected 1; Recovery {recovery}; "
      f"expected 78; Rest rows {rest}; expected 1")
assert changed == 0 and len(found) == 0 and overrides == 0 and recovery is None and rest == 0
sys.exit(1)
