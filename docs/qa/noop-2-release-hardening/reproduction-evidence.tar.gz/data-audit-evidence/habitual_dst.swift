import Foundation

/// Decode a sleep session's `stagesJSON` (either the on-device segment array `[{start,end,stage}]` or
/// the imported minute dict `{light,deep,rem,awake}`) into stage MINUTE totals, and aggregate a night's
/// blocks into the sleep-derived daily fields. Pure + deterministic, so the daily-aggregate recompute
/// that honors a user's wake-time edit can run off the stored (reshaped) stages — no raw streams needed.
public enum SleepStageTotals {

    public struct Minutes: Equatable {
        public var awake: Double, light: Double, deep: Double, rem: Double
        public var asleep: Double { light + deep + rem }
        public var inBed: Double { asleep + awake }
        public init(awake: Double = 0, light: Double = 0, deep: Double = 0, rem: Double = 0) {
            self.awake = awake; self.light = light; self.deep = deep; self.rem = rem
        }
    }

    // MARK: - Safe timestamp and stage arithmetic

    /// A non-negative timestamp gap, or nil when the inputs are reversed or their subtraction would
    /// overflow. The zero case matters for adjacent fragments, which intentionally bridge.
    static func nonnegativeDifferenceSeconds(start: Int, end: Int) -> Int? {
        guard end >= start else { return nil }
        let (duration, overflow) = end.subtractingReportingOverflow(start)
        guard !overflow else { return nil }
        return duration
    }

    /// A positive timestamp span, or nil when the inputs are malformed or their subtraction would overflow.
    /// Sleep data is external input, so an impossible span must be ignored rather than trap or become a
    /// giant fabricated night.
    static func positiveDurationSeconds(start: Int, end: Int) -> Int? {
        guard let duration = nonnegativeDifferenceSeconds(start: start, end: end), duration > 0 else {
            return nil
        }
        return duration
    }

    /// Add a non-negative duration to an epoch without allowing a malformed timestamp to wrap around.
    static func addingSeconds(_ seconds: Int, to timestamp: Int) -> Int? {
        guard seconds >= 0 else { return nil }
        let (result, overflow) = timestamp.addingReportingOverflow(seconds)
        return overflow ? nil : result
    }

    /// The midpoint used by selection. Nil means the block is malformed and must not participate.
    static func midpointSeconds(start: Int, end: Int) -> Int? {
        guard let duration = positiveDurationSeconds(start: start, end: end) else { return nil }
        return addingSeconds(duration / 2, to: start)
    }

    /// Preserve the existing truncation-to-whole-seconds behavior while rejecting non-finite or unrepresentable
    /// minute totals before converting back to Int.
    static func seconds(fromMinutes minutes: Double) -> Int? {
        guard minutes.isFinite, minutes >= 0 else { return nil }
        let seconds = minutes * 60.0
        guard seconds.isFinite, seconds >= 0, seconds < Double(Int.max) else { return nil }
        return Int(seconds)
    }

    private static func finiteNonNegativeSum(_ lhs: Double, _ rhs: Double) -> Double? {
        guard lhs.isFinite, rhs.isFinite, lhs >= 0, rhs >= 0 else { return nil }
        let sum = lhs + rhs
        return sum.isFinite ? sum : nil
    }

    private static func valid(_ minutes: Minutes) -> Bool {
        guard let asleepWithoutREM = finiteNonNegativeSum(minutes.light, minutes.deep),
              let asleep = finiteNonNegativeSum(asleepWithoutREM, minutes.rem),
              finiteNonNegativeSum(asleep, minutes.awake) != nil else { return false }
        return true
    }

    private static func add(_ source: Minutes, to total: inout Minutes) -> Bool {
        guard valid(source),
              let awake = finiteNonNegativeSum(total.awake, source.awake),
              let light = finiteNonNegativeSum(total.light, source.light),
              let deep = finiteNonNegativeSum(total.deep, source.deep),
              let rem = finiteNonNegativeSum(total.rem, source.rem) else { return false }
        total = Minutes(awake: awake, light: light, deep: deep, rem: rem)
        return true
    }

    /// Normalize without ever forming `timestamp + offset` first: both operands can be Int extrema.
    private static func secondOfDay(_ seconds: Int) -> Int {
        let remainder = seconds % secondsPerDay
        return remainder >= 0 ? remainder : remainder + secondsPerDay
    }

    /// Stage minutes for one session's `stagesJSON`, or nil if it decodes to nothing usable. The on-device
    /// stager calls awake "wake"; the importer "awake" — both map to `awake`.
    public static func minutes(fromStagesJSON json: String?) -> Minutes? {
        guard let json, let data = json.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) else { return nil }
        if let arr = obj as? [[String: Any]] {                 // segment array (computed)
            var m = Minutes()
            for seg in arr {
                guard let s = (seg["start"] as? NSNumber)?.intValue,
                      let e = (seg["end"] as? NSNumber)?.intValue,
                      let name = seg["stage"] as? String else { continue }
                guard let duration = positiveDurationSeconds(start: s, end: e) else { continue }
                let mins = Double(duration) / 60.0
                switch name {
                case "wake", "awake":
                    guard let awake = finiteNonNegativeSum(m.awake, mins) else { return nil }
                    m.awake = awake
                case "light":
                    guard let light = finiteNonNegativeSum(m.light, mins) else { return nil }
                    m.light = light
                case "deep":
                    guard let deep = finiteNonNegativeSum(m.deep, mins) else { return nil }
                    m.deep = deep
                case "rem":
                    guard let rem = finiteNonNegativeSum(m.rem, mins) else { return nil }
                    m.rem = rem
                default: continue
                }
            }
            guard valid(m), m.inBed > 0 else { return nil }
            return m
        }
        if let dict = obj as? [String: Any] {                  // minute dict (imported)
            func v(_ k: String) -> Double { (dict[k] as? NSNumber)?.doubleValue ?? 0 }
            let m = Minutes(awake: v("awake"), light: v("light"), deep: v("deep"), rem: v("rem"))
            guard valid(m), m.inBed > 0 else { return nil }
            return m
        }
        return nil
    }

    /// #259: return `stagesJSON` with its `[{start,end,stage}]` segments trimmed to begin no earlier than
    /// `onsetSec` — segments fully before the onset are dropped, one straddling it is cut to `[onsetSec, end]`.
    /// Only the computed segment-array shape carries the timestamps a trim needs, so the `{stage:min}` /
    /// dict (imported) shape and any unparseable JSON are returned UNCHANGED. A no-op when every segment
    /// already starts at/after the onset (the common, already-consistent case). The result is re-parsed by
    /// `minutes` / `dailyAggregate` on the SAME platform, so only the decoded minute totals need
    /// cross-platform parity, not the exact string. Mirrors Kotlin `clampStagesToOnset`.
    public static func clampStagesToOnset(_ stagesJSON: String?, onsetSec: Int) -> String? {
        guard let stagesJSON, let data = stagesJSON.data(using: .utf8),
              let arr = (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]] else {
            return stagesJSON   // dict/imported shape or unparseable → unchanged
        }
        var out: [[String: Any]] = []
        for seg in arr {
            // Shape check is start+end only (matches Kotlin): a {stage:min} entry has neither → bail
            // unchanged. A malformed segment missing only `stage` defaults to "" (minutes() ignores it),
            // exactly as the Kotlin twin's `optString("stage", "")` does.
            guard let rawS = (seg["start"] as? NSNumber)?.intValue,
                  let e = (seg["end"] as? NSNumber)?.intValue else { return stagesJSON }
            let name = seg["stage"] as? String ?? ""
            let s = max(rawS, onsetSec)
            guard e > s else { continue }                                        // fully before the onset → drop
            out.append(["start": s, "end": e, "stage": name])
        }
        guard let outData = try? JSONSerialization.data(withJSONObject: out),
              let str = String(data: outData, encoding: .utf8) else { return stagesJSON }
        return str
    }

    /// The sleep-derived daily fields for a night made of these blocks' `stagesJSON`, or nil if none
    /// decode. `efficiency` is asleep / in-bed (TST / Σ stage minutes) in [0,1]. For the segment stages
    /// noop stores (which TILE the window, last segment clamped to the wake), Σ stage minutes equals the
    /// clock span, so this coincides with `AnalyticsEngine.analyzeDay`'s TST/(end−start); it is not the
    /// literal same expression, and would diverge only for malformed non-tiling stages.
    public struct DailySleep: Equatable {
        public let totalSleepMin: Double, efficiency: Double
        public let deepMin: Double, remMin: Double, lightMin: Double
    }

    public static func dailyAggregate(_ stagesJSONs: [String?]) -> DailySleep? {
        dailyAggregate(stagesJSONs, interFragmentAwakeSeconds: 0)
    }

    /// As `dailyAggregate(_:)`, but folds the OUT-OF-BED time between bridged main-night fragments into the
    /// night's AWAKE total (and therefore its in-bed denominator). #777/#705 regression fix: when a main
    /// sleep is bridged from two fragments split by a 20-min wake gap, that gap is real time the user was
    /// awake/out of bed - it must show as ~20 min awake, not vanish. The fragments' own stages tile only
    /// their individual `[start,end)` spans, so the inter-fragment gap is in NO fragment; the caller computes
    /// it once (sum of gaps between consecutive fragments' effective ends and onsets) and passes it here so
    /// both the analytics rollup and the edit/recompute seam apply ONE consistent definition: gap → awake →
    /// in-bed. `interFragmentAwakeSeconds` ≤ 0 reproduces the legacy sum-of-stages behaviour. (#777/#705)
    public static func dailyAggregate(_ stagesJSONs: [String?],
                                      interFragmentAwakeSeconds: Double) -> DailySleep? {
        guard interFragmentAwakeSeconds.isFinite else { return nil }
        var total = Minutes()
        var any = false
        for j in stagesJSONs {
            if let m = minutes(fromStagesJSON: j) {
                guard add(m, to: &total) else { return nil }
                any = true
            }
        }
        if interFragmentAwakeSeconds > 0 {
            guard let awake = finiteNonNegativeSum(total.awake, interFragmentAwakeSeconds / 60.0) else {
                return nil
            }
            total.awake = awake
        }
        guard any, valid(total), total.inBed > 0 else { return nil }
        return DailySleep(totalSleepMin: total.asleep, efficiency: total.asleep / total.inBed,
                          deepMin: total.deep, remMin: total.rem, lightMin: total.light)
    }

    /// The OUT-OF-BED time (seconds) BETWEEN consecutive bridged sleep fragments - the inter-fragment wake
    /// gaps the #561 gap-bridge spans but no fragment's own `[start,end)` covers. Each fragment is one
    /// `(start,end)` span; sorted by start, the gap after fragment i is `max(0, start[i+1] - end[i])`. Sums
    /// only positive gaps (overlapping/abutting fragments contribute 0). This is the single shared definition
    /// of "awake between fragments" both `analyzeDay` and the edit/recompute seam fold into AWAKE, so the two
    /// paths agree (no seam double-count). Pure + deterministic; cross-platform identical. (#777/#705)
    public static func interFragmentAwakeSeconds(_ spans: [(start: Int, end: Int)]) -> Double {
        guard spans.count > 1 else { return 0 }
        let sorted = spans.sorted { $0.start < $1.start }
        var gap = 0.0
        for i in 1..<sorted.count {
            guard let g = positiveDurationSeconds(start: sorted[i - 1].end, end: sorted[i].start) else {
                continue
            }
            guard let next = finiteNonNegativeSum(gap, Double(g)) else { return 0 }
            gap = next
        }
        return gap
    }

    // MARK: - Canonical main-night selection (#525 / #547 — learned-timing scored pick)

    /// Broad overnight band used ONLY for the cold-start alignment bonus (NOT a gate). A block whose
    /// midpoint lands near this band's center earns the timing credit when we have no learned habitual
    /// midsleep yet. The band is [`overnightStartHour`, `overnightEndHour`) local, reconciled with the
    /// detector's `SleepStager.isOvernightOnset` window [20:00, 11:00) so the selector and detector agree
    /// (this removes the old [10:00, 11:00) off-by-one where the detector kept a ~10:30 onset as "night"
    /// but the selector demoted it to a nap). (#547)
    public static let overnightStartHour = 20
    /// Local hour (exclusive) that closes the cold-start overnight band. Now 11 (was 10) to match the
    /// detector's [20:00, 11:00) onset window. A block onset in [`overnightEndHour`, `overnightStartHour`)
    /// is daytime; everything else is overnight.
    public static let overnightEndHour = 11

    /// Seconds in a day, for circular time-of-day math.
    public static let secondsPerDay = 86_400

    /// The fixed alignment credit (in MINUTES) added to a block's asleep minutes when its midpoint sits
    /// right on the user's habitual midsleep (or, cold-start, the overnight band center). This is a BONUS,
    /// not an infinite gate: a long enough off-timing block can still out-score a short well-timed one, so
    /// a genuine 7h daytime sleep beats a 1.5h overnight fragment, while a normal 4h night beats a longer
    /// daytime nap. ~90 min is one sleep-cycle's worth of credit. (#547)
    public static let alignmentBonusMin: Double = 90.0

    /// Full alignment bonus is paid when the block midpoint is within this many seconds (circular) of the
    /// habitual midsleep; the bonus then decays LINEARLY to 0 at `alignmentZeroSec`. ±2h full, →0 by ±5h.
    public static let alignmentFullWindowSec = 2 * 3_600
    /// Circular distance (seconds) at/after which the alignment bonus is 0.
    public static let alignmentZeroSec = 5 * 3_600

    /// Adjacent sleep runs separated by a wake gap shorter than this are bridged into one block for
    /// selection, so a biphasic / briefly-interrupted main sleep is scored as a single night rather than
    /// two fragments. Matches the sleep-staging research's <60 min "same sleep period" threshold. The
    /// detector already bridges sparse-gravity gaps up to 90 min (`SleepStager.sparseBridgeGapMin`); this
    /// is the selector-side backstop for blocks that reach the selector still split. (#547)
    public static let gapBridgeMaxMin = 60

    /// Wider wake-gap bridge (minutes) applied ONLY to an overnight night-tail fragment, so a single
    /// overnight sleep broken by a real but longer mid-night wake (at/over `gapBridgeMaxMin`, under this) is
    /// not over-fragmented into a NAP + a main sleep, the #861 report ("night sleeps are split into naps and
    /// sleep"). This mirrors the detector's own `SleepStager.nightContinuationGapMin` (90 min), the same
    /// "this is the night's tail, not an isolated nap" threshold the detection spine already trusts. It is
    /// applied (in `mainNightGroupIndices`) ONLY when the later fragment's onset is still in the overnight
    /// band (`isOvernightOnset`), so a genuine daytime nap (which is hours away AND begins in daytime)
    /// can never be folded into the night. Below `gapBridgeMaxMin` the unconditional bridge is unchanged
    /// (so `bridgeAdjacent` and its golden tests stay byte-identical). (#861)
    public static let nightTailBridgeMaxMin = 90

    /// One candidate block for main-night selection. The `start` is the EFFECTIVE onset (a user wake/
    /// bed edit moves `end`, never the detected onset key), and `tzOffsetSeconds` turns it local so the
    /// timing test reads the user's clock, not UTC.
    public struct NightBlock {
        public let start: Int, end: Int
        public init(start: Int, end: Int) { self.start = start; self.end = end }
        /// Existing non-optional API preserved: malformed spans report zero rather than trapping.
        public var durationS: Int { SleepStageTotals.positiveDurationSeconds(start: start, end: end) ?? 0 }
        /// Existing non-optional API preserved: malformed spans fall back to their onset and are excluded
        /// from selector candidates by `isUsable`.
        public var midpointSec: Int { SleepStageTotals.midpointSeconds(start: start, end: end) ?? start }
        fileprivate var isUsable: Bool {
            SleepStageTotals.positiveDurationSeconds(start: start, end: end) != nil
        }
    }

    // MARK: - Selection reason (explainability — WHY this block is the main night) (spec 2026-06-20)

    /// Why the selector chose the block it did, derived from the EXACT signals the score used, so the UI
    /// can explain the pick in plain English without re-deriving anything. Identical cases + identical
    /// ordering as the Kotlin `MainNightReason` (cross-platform parity is mandatory). (spec 2026-06-20)
    public enum MainNightReason: String, Equatable {
        /// The day has a single sleep block, so there is nothing to choose between.
        case onlyBlock
        /// The chosen block is the longest by asleep duration and there is no meaningful timing credit
        /// behind the pick (cold-start with no learned habitual, or the longest block is outside the
        /// alignment-bonus window). Duration alone decided it.
        case longest
        /// The chosen block is the longest by asleep duration AND it earned a meaningful alignment bonus
        /// (a learned habitual midsleep exists and the block's midpoint sits inside the bonus window).
        /// Duration would have picked it anyway, and the timing agrees.
        case longestNearUsual
        /// The chosen block is NOT the longest by asleep duration; the alignment bonus (not raw duration)
        /// is what flipped the pick away from the longest block toward this one.
        case alignedToUsual
    }

    /// A block is treated as having a MEANINGFUL alignment bonus when it earns ANY positive credit, i.e.
    /// its midpoint sits inside the bonus window (circular distance < `alignmentZeroSec`). Outside the
    /// window the bonus is exactly 0 and contributes nothing to the pick. Tiny epsilon so floating-point
    /// noise at the window edge can't be mistaken for credit. Identical cross-platform. (spec 2026-06-20)
    static let meaningfulBonusEpsilon: Double = 1e-9

    /// The result of main-night selection enriched with the explainability fields the UI renders: the
    /// chosen block's index, the reason it won, and the chosen block's ASLEEP duration so the copy can
    /// fill {DUR} (Xh Ym) without re-decoding. `asleepSeconds`/`asleepMinutes` are the SAME duration the
    /// score used for that block (clock span for the `NightBlock` overload; decoded asleep minutes for the
    /// stages overload). Mirrors the Kotlin `MainNightSelection`. (spec 2026-06-20)
    public struct MainNightSelection: Equatable {
        public let index: Int
        public let reason: MainNightReason
        /// The chosen block's asleep duration in SECONDS (the figure the score ranked on).
        public let asleepSeconds: Int
        public init(index: Int, reason: MainNightReason, asleepSeconds: Int) {
            self.index = index; self.reason = reason; self.asleepSeconds = asleepSeconds
        }
        /// The chosen block's asleep duration in MINUTES, for copy that fills {DUR} as Xh Ym.
        public var asleepMinutes: Double { Double(asleepSeconds) / 60.0 }
    }

    /// True when a block's onset falls in the cold-start overnight band (≥ `overnightStartHour` or
    /// < `overnightEndHour`, local). Retained for callers/tests that still ask the binary question, but
    /// the scored selector no longer GATES on it — it only feeds the cold-start alignment bonus.
    /// Mirrors `SleepStager.isOvernightOnset`. `offsetSec` is seconds EAST of UTC. (#525 / #547)
    public static func isOvernightOnset(_ ts: Int, offsetSec: Int) -> Bool {
        let secOfDay = localSecOfDay(ts, offsetSec: offsetSec)
        let hour = secOfDay / 3_600
        return hour >= overnightStartHour || hour < overnightEndHour
    }

    /// Local time-of-day, in seconds [0, 86400), of a unix timestamp shifted east by `offsetSec`.
    static func localSecOfDay(_ ts: Int, offsetSec: Int) -> Int {
        let local = secondOfDay(ts) + secondOfDay(offsetSec)
        return local >= secondsPerDay ? local - secondsPerDay : local
    }

    /// Smallest circular distance (seconds, 0...43200) between two times-of-day, so 23:30 and 00:30 are
    /// 3600s apart, not 82800. Both inputs are seconds-of-day in [0, 86400).
    static func circularDistanceSec(_ a: Int, _ b: Int) -> Int {
        let lhs = secondOfDay(a)
        let rhs = secondOfDay(b)
        let raw = lhs >= rhs ? lhs - rhs : rhs - lhs
        return min(raw, secondsPerDay - raw)
    }

    /// The cold-start anchor: the CENTER of the overnight band [overnightStartHour, overnightEndHour),
    /// as a time-of-day in seconds. With the band wrapping midnight (20:00 → 11:00 = 15h wide) the center
    /// is 03:30 local. Used as the habitual-midsleep stand-in before enough history exists. (#547)
    static var coldStartAnchorSec: Int {
        let startSec = overnightStartHour * 3_600
        let span = ((overnightEndHour - overnightStartHour) * 3_600 + secondsPerDay) % secondsPerDay // wrap
        return (startSec + span / 2) % secondsPerDay
    }

    /// The alignment bonus (MINUTES) a block earns for sitting near the target midsleep. Full
    /// `alignmentBonusMin` within `alignmentFullWindowSec`, decaying linearly to 0 by `alignmentZeroSec`.
    /// `blockMidSec` and `targetMidSec` are local times-of-day in seconds. (#547)
    static func alignmentBonusMinutes(blockMidSec: Int, targetMidSec: Int) -> Double {
        let d = circularDistanceSec(blockMidSec, targetMidSec)
        if d <= alignmentFullWindowSec { return alignmentBonusMin }
        if d >= alignmentZeroSec { return 0 }
        let frac = Double(alignmentZeroSec - d) / Double(alignmentZeroSec - alignmentFullWindowSec)
        return alignmentBonusMin * frac
    }

    /// The target midsleep time-of-day (seconds) the scorer aligns to: the learned `habitualMidsleepSec`
    /// when supplied (a late/shift sleeper's real bedtime), else the cold-start overnight-band center.
    static func targetMidsleepSec(_ habitualMidsleepSec: Int?) -> Int {
        habitualMidsleepSec ?? coldStartAnchorSec
    }

    // MARK: - Gap-bridging (biphasic / briefly-interrupted nights → one block)

    /// Merge adjacent `NightBlock`s separated by a wake gap shorter than `gapBridgeMaxMin` into single
    /// blocks for selection, so a fragmented main sleep is scored as one night. Input order is preserved
    /// by sorting on `start` first (the selector is order-independent, but bridging must see neighbours).
    /// Pure + deterministic. (#547)
    public static func bridgeAdjacent(_ blocks: [NightBlock]) -> [NightBlock] {
        let sorted = blocks.filter(\.isUsable).sorted { $0.start < $1.start }
        guard sorted.count > 1 else { return sorted }
        let bridgeS = gapBridgeMaxMin * 60
        var out: [NightBlock] = [sorted[0]]
        for b in sorted.dropFirst() {
            let last = out[out.count - 1]
            if let gap = nonnegativeDifferenceSeconds(start: last.end, end: b.start), gap < bridgeS {
                out[out.count - 1] = NightBlock(start: last.start, end: max(last.end, b.end))
            } else {
                out.append(b)
            }
        }
        return out
    }

    /// One bridged night group over the whole input: the fragments (as ORIGINAL indices, ascending)
    /// plus the group's inter-fragment wake seams. Produced by `bridgedNightGroups` for the consumers
    /// that must present a briefly-interrupted night as ONE night — the Health write-back and the
    /// sleep screens — so they group exactly as the day totals do and can fold each seam in as an
    /// explicit `wake` segment. (#364)
    public struct BridgedNightGroup: Equatable {
        public let indices: [Int]
        public let gaps: [GapSpan]
        /// One inter-fragment seam: (previous bridged end, next fragment start), end > start always.
        public struct GapSpan: Equatable {
            public let start: Int, end: Int
            public init(start: Int, end: Int) { self.start = start; self.end = end }
        }
        public init(indices: [Int], gaps: [GapSpan]) { self.indices = indices; self.gaps = gaps }
    }

    /// EVERY bridged group over `blocks` — the same two-tier bridge `mainNightGroupIndices` applies
    /// (#561 short-wake, plus the #861 overnight night-tail widening), WITHOUT the winner pick. A
    /// negative gap (a block starting inside the previous span) does not bridge — pinned legacy
    /// semantics, `gap >= 0` — and never fabricates a seam. Groups ordered by start; pure and
    /// deterministic; Kotlin twin `bridgedNightGroups`. (#364)
    public static func bridgedNightGroups(_ blocks: [NightBlock], offsetSec: Int) -> [BridgedNightGroup] {
        guard !blocks.isEmpty else { return [] }
        // Sort indices by onset so bridging sees neighbours, exactly as `bridgeAdjacent` sorts the blocks.
        let order = blocks.indices.filter { blocks[$0].isUsable }
            .sorted { blocks[$0].start < blocks[$1].start }
        let bridgeS = gapBridgeMaxMin * 60
        let nightTailBridgeS = nightTailBridgeMaxMin * 60
        // Build the bridged spans AND the original indices that compose each one, in one pass over `order`.
        var bridged: [NightBlock] = []
        var groups: [[Int]] = []
        var gaps: [[BridgedNightGroup.GapSpan]] = []
        for idx in order {
            let b = blocks[idx]
            if let last = bridged.last {
                let gap = nonnegativeDifferenceSeconds(start: last.end, end: b.start)
                // Unconditional short-wake bridge (< gapBridgeMaxMin), byte-identical to `bridgeAdjacent`.
                // Then a WIDER bridge for a true overnight night-tail (#861): a gap in
                // [gapBridgeMaxMin, nightTailBridgeMaxMin) folds the fragment in ONLY when its onset is
                // still in the overnight band: a real mid-night wake, not an isolated daytime nap. This
                // stops one overnight sleep being split into a nap + a main sleep, while a daytime nap
                // (daytime onset, or a gap at/over nightTailBridgeMaxMin) still stands as its own block.
                let bridges = gap.map {
                    $0 < bridgeS
                        || ($0 < nightTailBridgeS && isOvernightOnset(b.start, offsetSec: offsetSec))
                } ?? false
                if bridges {
                    if let gap, gap > 0 {
                        gaps[gaps.count - 1].append(.init(start: last.end, end: b.start))
                    }
                    bridged[bridged.count - 1] = NightBlock(start: last.start, end: max(last.end, b.end))
                    groups[groups.count - 1].append(idx)
                    continue
                }
            }
            bridged.append(b)
            groups.append([idx])
            gaps.append([])
        }
        return zip(groups, gaps).map { BridgedNightGroup(indices: $0.sorted(), gaps: $1) }
    }

    /// The indices (into the ORIGINAL `blocks`) of the MAIN-NIGHT GROUP: the main night plus any adjacent
    /// fragments bridged into it. A biphasic / briefly-interrupted main sleep that reaches the selector still
    /// split into two blocks (a wake gap shorter than `gapBridgeMaxMin` between them) is scored as ONE night
    /// rather than two competing fragments, then the winning bridged group's fragments are ALL returned so the
    /// caller can SUM their stages for the day's headline figure. (#561)
    ///
    /// Pipeline:
    ///   1. `bridgedNightGroups` merges blocks whose gap is in `[0, gapBridgeMaxMin*60)` (or the #861
    ///      night-tail window) into bridged groups, in `start` order.
    ///   2. `mainNightIndex` scores the BRIDGED spans (so a two-fragment night's combined span out-scores a
    ///      lone nap) and picks the winning bridged group.
    ///   3. The original indices of that winning group are returned, ascending.
    ///
    /// Returns nil only for an empty list. A day with no bridgeable gap collapses to the single-block group the
    /// bare `mainNightIndex` would pick — byte-identical to the old behaviour for the common case. Pure +
    /// deterministic; shares the `bridgedNightGroups` pass + `mainNightIndex` so the bridged pick stays
    /// cross-platform stable. (#561)
    public static func mainNightGroupIndices(_ blocks: [NightBlock], offsetSec: Int,
                                             habitualMidsleepSec: Int? = nil) -> [Int]? {
        guard !blocks.isEmpty else { return nil }
        let all = bridgedNightGroups(blocks, offsetSec: offsetSec)
        guard !all.isEmpty else { return nil }
        // Rebuild each group's bridged span for scoring: sorted-ascending fragments make the span
        // (first start, running-max end) — identical to the span the one-pass loop accumulated.
        let bridgedSpans = all.map { g -> NightBlock in
            NightBlock(start: g.indices.map { blocks[$0].start }.min() ?? 0,
                       end: g.indices.map { blocks[$0].end }.max() ?? 0)
        }
        guard let winner = mainNightIndex(bridgedSpans, offsetSec: offsetSec,
                                          habitualMidsleepSec: habitualMidsleepSec) else { return nil }
        return all[winner].indices
    }

    /// Index of the day's MAIN night among `blocks`, by the LEARNED-TIMING SCORE (replaces the old hard
    /// overnight gate). score(block) = asleepMinutes + alignmentBonus, where the bonus credits a block
    /// whose midpoint sits near the user's habitual midsleep (`habitualMidsleepSec`), or — cold-start —
    /// near the broad overnight-band center. There is NO hard duration floor and NO overnight gate: a
    /// short main sleep or a nap-only day still resolves to a main block, and a genuine long daytime sleep
    /// can win on score. The highest score wins; exact ties break toward the EARLIER onset (stable across
    /// platforms). Returns nil only for an empty list. This `NightBlock` overload has no decoded stages,
    /// so "asleep minutes" is the block's clock span — preserving the prior duration semantics for callers
    /// that rank by span (`analyzeDay`). Pass `habitualMidsleepSec` from `habitualMidsleepSec(...)` once
    /// enough history exists; leave nil for the cold-start band. (#525 / #547)
    public static func mainNightIndex(_ blocks: [NightBlock], offsetSec: Int,
                                      habitualMidsleepSec: Int? = nil) -> Int? {
        let eligible = blocks.indices.filter { blocks[$0].isUsable }
        guard let first = eligible.first else { return nil }
        let target = targetMidsleepSec(habitualMidsleepSec)
        func score(_ b: NightBlock) -> Double {
            let asleepMin = Double(b.durationS) / 60.0
            let midSec = localSecOfDay(b.midpointSec, offsetSec: offsetSec)
            return asleepMin + alignmentBonusMinutes(blockMidSec: midSec, targetMidSec: target)
        }
        var bestIdx = first
        for i in eligible.dropFirst() {
            let cand = blocks[i], best = blocks[bestIdx]
            let cs = score(cand), bs = score(best)
            let candWins: Bool
            if cs != bs {
                candWins = cs > bs                       // higher score wins
            } else {
                candWins = cand.start < best.start       // exact tie → earlier onset (stable)
            }
            if candWins { bestIdx = i }
        }
        return bestIdx
    }

    /// Main-night selection ENRICHED with the explainability reason + the chosen block's asleep duration,
    /// for the "why this is your main sleep" UI. The `index` is byte-identical to `mainNightIndex(...)`
    /// (same score, same earlier-onset tie-break) — this is the same pick, just annotated, so callers on
    /// the bare `mainNightIndex` are unaffected. The reason is decided from the SAME signals the score
    /// used (no re-derivation):
    ///   - `onlyBlock` — a single block.
    ///   - `alignedToUsual` — the chosen block is NOT the longest by asleep duration; the alignment bonus
    ///     flipped the pick away from the duration-only winner toward this one.
    ///   - `longestNearUsual` — the chosen block IS the longest by asleep duration AND a learned habitual
    ///     midsleep exists AND the chosen block's midpoint earns a meaningful (positive) alignment bonus.
    ///   - `longest` — otherwise (incl. cold-start with no learned habitual, or the longest block outside
    ///     the bonus window).
    /// The "longest" comparison ranks by the SAME duration the score adds (clock span for this overload),
    /// tie-broken by earlier onset exactly like the score, so the duration-only winner is well-defined and
    /// platform-stable. `asleepSeconds` is the chosen block's clock span. (spec 2026-06-20)
    public static func mainNightSelection(_ blocks: [NightBlock], offsetSec: Int,
                                          habitualMidsleepSec: Int? = nil) -> MainNightSelection? {
        guard let idx = mainNightIndex(blocks, offsetSec: offsetSec,
                                       habitualMidsleepSec: habitualMidsleepSec) else { return nil }
        let chosen = blocks[idx]
        let usable = blocks.indices.filter { blocks[$0].isUsable }
        let usableDurations = usable.map { blocks[$0].durationS }
        let usableOnsets = usable.map { blocks[$0].start }
        let reason = mainNightReason(
            chosenAsleepSec: chosen.durationS, chosenOnset: chosen.start,
            chosenMidLocalSec: localSecOfDay(chosen.midpointSec, offsetSec: offsetSec),
            blockCount: usable.count,
            // duration-only winner over the SAME asleep figure (clock span) + same earlier-onset tie-break.
            longestAsleepSec: usableDurations.max() ?? chosen.durationS,
            longestOnset: durationOnlyWinnerOnset(asleepSecs: usableDurations, onsets: usableOnsets),
            chosenIsDurationWinnerOnset: chosen.start,
            habitualMidsleepSec: habitualMidsleepSec)
        return MainNightSelection(index: idx, reason: reason, asleepSeconds: chosen.durationS)
    }

    /// The onset of the DURATION-ONLY winner among parallel `asleepSecs`/`onsets` arrays: the block with
    /// the greatest asleep figure, ties broken toward the EARLIER onset — the same tie-break the score
    /// uses, so "would duration alone have picked this same block?" is decided identically on both
    /// platforms. Returns the first onset when empty (callers never pass empty). (spec 2026-06-20)
    static func durationOnlyWinnerOnset(asleepSecs: [Int], onsets: [Int]) -> Int {
        guard !asleepSecs.isEmpty else { return 0 }
        var bestIdx = 0
        for i in 1..<asleepSecs.count {
            let candDur = asleepSecs[i], bestDur = asleepSecs[bestIdx]
            let candWins: Bool
            if candDur != bestDur {
                candWins = candDur > bestDur
            } else {
                candWins = onsets[i] < onsets[bestIdx]
            }
            if candWins { bestIdx = i }
        }
        return onsets[bestIdx]
    }

    /// Decide the `MainNightReason` from the chosen block + the duration-only winner, using ONLY signals
    /// the score already computed. Pure so it is unit-tested directly and shared byte-for-byte with Kotlin.
    /// `chosenIsDurationWinnerOnset` is the chosen block's onset; the chosen block IS the duration-only
    /// winner iff (its asleep == the longest asleep) AND (its onset == the duration-only winner's onset) —
    /// matching the longest figure and the earlier-onset tie-break the duration-only ranking uses.
    /// (spec 2026-06-20)
    static func mainNightReason(chosenAsleepSec: Int, chosenOnset: Int, chosenMidLocalSec: Int,
                                blockCount: Int, longestAsleepSec: Int, longestOnset: Int,
                                chosenIsDurationWinnerOnset: Int, habitualMidsleepSec: Int?) -> MainNightReason {
        if blockCount <= 1 { return .onlyBlock }
        let chosenIsLongest = (chosenAsleepSec == longestAsleepSec)
            && (chosenIsDurationWinnerOnset == longestOnset)
        if !chosenIsLongest {
            // Duration alone would NOT have picked this block; the alignment bonus flipped the pick.
            return .alignedToUsual
        }
        // The chosen block is the longest. It is "near usual" only when a learned habitual exists AND the
        // block earns a meaningful (positive) alignment bonus — cold-start (nil habitual) is plain longest.
        if let habitual = habitualMidsleepSec {
            let bonus = alignmentBonusMinutes(blockMidSec: chosenMidLocalSec, targetMidSec: habitual)
            if bonus > meaningfulBonusEpsilon { return .longestNearUsual }
        }
        return .longest
    }

    /// The night's daily sleep aggregate, substituting any USER-EDITED block for its detected twin
    /// before summing, then UNIONING in any user-added block that has no detected twin. `detected` is
    /// the auto-detected blocks (their stable startTs + stages); `edited` maps a block's startTs → its
    /// hand-corrected (reshaped) stages — a wake-time edit never moves startTs, so the edited block
    /// lands exactly on its detected twin. `manual` is user-added blocks (e.g. a hand-logged nap) that
    /// the detector never found; each is keyed by its own stable startTs and FOLDED IN so its minutes
    /// count toward the day's totals (a detector-found nap already folds via `detected`). De-duped by
    /// startTs so a block already represented in `detected` (or substituted via `edited`) is never
    /// double-counted. Returns the aggregate plus whether an edit OR a manual block actually contributed
    /// (so the caller only overrides the day when it did), or nil when nothing decodes. This is the
    /// integration seam between the edit and the daily recompute — kept pure so it's unit-tested with
    /// synthetic data, no store or stager needed. (#518 / #508)
    public static func dailyAggregateHonoringEdits(
        detected: [(startTs: Int, stagesJSON: String?)],
        edited: [Int: String?],
        manual: [(startTs: Int, stagesJSON: String?)] = [],
        // The block's effective onset (a wake/bed edit moves end, not the detected start key) plus the
        // device's UTC offset, so the MAIN-NIGHT pick reads the user's local clock. When a caller can't
        // supply onsets, leave nil and the legacy SUM-of-all-blocks behaviour is preserved (no regression
        // for older callers); the day rollup passes them so the daily total matches the Sleep tab. (#525)
        onsetByStart: [Int: Int]? = nil,
        // Each block's effective END (its stored wake, keyed by the stable startTs), so the main-night pick
        // runs on the SAME [onset, end] spans `analyzeDay` scored (AN-12). nil → onset + decoded in-bed,
        // for callers that only hold stages.
        endByStart: [Int: Int]? = nil,
        offsetSec: Int = 0,
        // The learned habitual midsleep (local time-of-day seconds) so the scored pick aligns to the
        // user's real bedtime, not a fixed clock band. nil = cold-start (fall back to the overnight-band
        // bonus). Existing callers compile unchanged. (#547)
        habitualMidsleepSec: Int? = nil
    ) -> (sleep: DailySleep, editApplied: Bool)? {
        // Substitute an edited block's stages ONLY when the edit has usable (non-nil) stages — an edit
        // that reshaped to nil must fall back to the detected stages, never drop the block (which would
        // collapse the night's sleep total). `editApplied` likewise reflects a real substitution. We keep
        // each block's identity (its startTs + effective stages) so the main-night pick can run after.
        var applied = false
        // (startTs, effective stages) for every block on the day — detected (edit-substituted) then any
        // twinless manual block UNIONED in. Identity is preserved for the main-night selection.
        var blocks: [(startTs: Int, stagesJSON: String?)] = detected.map { d in
            if let stages = edited[d.startTs] ?? nil {   // flatten String?? → String?, then require non-nil
                applied = true
                return (startTs: d.startTs, stagesJSON: stages)
            }
            return (startTs: d.startTs, stagesJSON: d.stagesJSON)
        }
        // Union: a user-added block the detector never found (no detected twin) must still be on the day
        // so the main-night pick (or the legacy sum) sees it — otherwise a manually-logged nap is dropped.
        // Match on the stable startTs and add ONLY rows absent from `detected`, with usable stages.
        let detectedStarts = Set(detected.map(\.startTs))
        for m in manual where !detectedStarts.contains(m.startTs) {
            if let stages = m.stagesJSON {
                blocks.append((startTs: m.startTs, stagesJSON: stages))
                applied = true
            }
        }
        // Canonical per-day total (#525): when the caller supplies block onsets, the daily figure is the
        // MAIN NIGHT only (the longest, overnight-preferring block — the SAME block the Sleep tab shows),
        // so Intelligence / Sleep Need / the debt ledger / the card all read the same number as the Sleep
        // tab. Nap blocks stay their own session rows elsewhere; they are NOT summed into this figure.
        // No onsets supplied → the legacy sum-of-all-blocks total (older callers unchanged).
        if let onsetByStart {
            // AN-12: ONE selector. The seam picks the main-night group with the SAME bridging + scoring
            // (`mainNightGroupIndices`) that `analyzeDay` and the Sleep tab use, over each block's
            // [effective onset, effective end] span, and SUMS that group's stages. A separate stages-scored
            // selector used to rank on decoded asleep minutes, so editing any block could switch the day's
            // main night. Naps outside the group remain their own rows.
            let selectionSpans = seamNightBlocks(blocks, onsetByStart: onsetByStart, endByStart: endByStart)
            let group = mainNightGroupIndices(selectionSpans, offsetSec: offsetSec,
                                              habitualMidsleepSec: habitualMidsleepSec)
            // OUT-OF-BED time between the bridged fragments counts as AWAKE (#777/#705), using the SAME
            // single definition `analyzeDay` applies so the seam can't double-count it. Each fragment's
            // effective span is `[onset, onset + decoded in-bed]`; the gap between consecutive fragments is
            // awake the fragments' own stages don't cover.
            if let group {
                // #259: trim each SELECTED block's stages to its EFFECTIVE onset before summing. A hand-edited
                // or onset-trimmed bedtime that the raw was too sparse to re-stage (WHOOP 4.0) leaves pre-onset
                // segments in the stored stagesJSON; summing them in full pushes asleep past time-in-bed (the
                // impossible "6h41m asleep / 4h33m in bed" card). Selection above ran on the ORIGINAL blocks,
                // so no #525/#547 pick regression — only the SUMMED main-night total is clamped. A block
                // already staged from its onset (the common case) is unchanged. Mirrors Kotlin.
                let clampedStages: [String?] = group.map { i in
                    if let onset = onsetByStart[blocks[i].startTs] {
                        return clampStagesToOnset(blocks[i].stagesJSON, onsetSec: onset)
                    }
                    return blocks[i].stagesJSON
                }
                var spans: [(start: Int, end: Int)] = []
                for (gi, i) in group.enumerated() {
                    if endByStart != nil {
                        // The caller's real bounds: the gap is exactly the one `analyzeDay` counted.
                        spans.append((start: selectionSpans[i].start, end: selectionSpans[i].end))
                        continue
                    }
                    let onset = onsetByStart[blocks[i].startTs] ?? blocks[i].startTs
                    let inBedSec: Int
                    if let minutes = minutes(fromStagesJSON: clampedStages[gi]) {
                        guard let seconds = seconds(fromMinutes: minutes.inBed) else { return nil }
                        inBedSec = seconds
                    } else {
                        inBedSec = 0
                    }
                    guard let end = addingSeconds(inBedSec, to: onset) else { return nil }
                    spans.append((start: onset, end: end))
                }
                let gapAwakeS = interFragmentAwakeSeconds(spans)
                if let agg = dailyAggregate(clampedStages, interFragmentAwakeSeconds: gapAwakeS) {
                    return (agg, applied)
                }
            }
            return nil
        }
        guard let agg = dailyAggregate(blocks.map(\.stagesJSON)) else { return nil }
        return (agg, applied)
    }

    /// Selection spans for the edit/recompute seam (AN-12): `[effective onset, effective end]` per block,
    /// the end being the caller's stored wake when supplied (the bounds `analyzeDay` scored), else onset +
    /// decoded in-bed. A block whose stages don't decode gets an empty span, so a stage-less stub is never a
    /// main-night candidate and can't displace staged sleep. Index-aligned with `blocks`.
    static func seamNightBlocks(_ blocks: [(startTs: Int, stagesJSON: String?)],
                                onsetByStart: [Int: Int],
                                endByStart: [Int: Int]?) -> [NightBlock] {
        blocks.map { block in
            let onset = onsetByStart[block.startTs] ?? block.startTs
            guard let decoded = minutes(fromStagesJSON: block.stagesJSON) else {
                return NightBlock(start: onset, end: onset)
            }
            if let end = endByStart?[block.startTs] { return NightBlock(start: onset, end: end) }
            guard let inBed = seconds(fromMinutes: decoded.inBed),
                  let end = addingSeconds(inBed, to: onset) else { return NightBlock(start: onset, end: onset) }
            return NightBlock(start: onset, end: end)
        }
    }

    // MARK: - Habitual midsleep (learned timing — non-circular dependency)

    /// One detected sleep block from the trailing history, for learning the user's habitual timing.
    /// `start`/`end` are unix seconds; `dayKey` groups blocks by local calendar day so the LONGEST block
    /// per day can be picked selection-independently (no chicken-and-egg with main-night selection).
    public struct HistoryBlock {
        public let start: Int, end: Int, dayKey: String
        /// The wall-clock offset in force at this block's own midpoint (AN-02). nil → the caller's single
        /// `offsetSec`. Per-block offsets keep nights on both sides of a DST change on one local clock.
        public let clockOffsetSec: Int?
        public init(start: Int, end: Int, dayKey: String, clockOffsetSec: Int? = nil) {
            self.start = start; self.end = end; self.dayKey = dayKey
            self.clockOffsetSec = clockOffsetSec
        }
        /// Existing non-optional API preserved: malformed spans report zero rather than trapping.
        public var durationS: Int { SleepStageTotals.positiveDurationSeconds(start: start, end: end) ?? 0 }
        /// Existing non-optional API preserved: malformed spans fall back to their onset and are ignored
        /// by `habitualMidsleepSec`.
        public var midpointSec: Int { SleepStageTotals.midpointSeconds(start: start, end: end) ?? start }
        fileprivate var isUsable: Bool {
            SleepStageTotals.positiveDurationSeconds(start: start, end: end) != nil
        }
    }

    /// Minimum number of DAYS (with at least one block) needed before a habitual midsleep is trusted; a
    /// shorter history returns nil (cold-start → the scorer uses the overnight band). ~2 weeks of nights
    /// is the lower bound the sleep-timing literature uses for a stable midpoint. (#547)
    public static let habitualMinDays = 14

    /// The user's habitual midsleep as a LOCAL TIME-OF-DAY (seconds in [0, 86400)), or nil when there is
    /// too little history (cold-start). Computed as the CIRCULAR MEAN of the midpoint-time-of-day of the
    /// LONGEST block per local day across `history` (the mean direction of the midpoint angles — the
    /// natural circular central tendency for clock times). Longest-per-day is selection-INDEPENDENT, so
    /// this has no circular dependency on main-night selection. Circular math (mean of the angle, then
    /// back to seconds) makes 23:30 and 00:30 an hour apart, not 23h, so a near-midnight sleeper's midsleep
    /// is learned correctly. `offsetSec` turns each midpoint local; `minDays` is the cold-start floor. (#547)
    public static func habitualMidsleepSec(_ history: [HistoryBlock], offsetSec: Int,
                                           minDays: Int = habitualMinDays) -> Int? {
        guard !history.isEmpty else { return nil }
        // Longest block per local day (selection-independent). Ties within a day → earlier onset (stable).
        var longestByDay: [String: HistoryBlock] = [:]
        for b in history where b.isUsable {
            if let cur = longestByDay[b.dayKey] {
                if b.durationS > cur.durationS || (b.durationS == cur.durationS && b.start < cur.start) {
                    longestByDay[b.dayKey] = b
                }
            } else {
                longestByDay[b.dayKey] = b
            }
        }
        guard longestByDay.count >= minDays else { return nil }
        // Circular mean of each day's midpoint time-of-day: convert each to an angle, take the mean
        // direction via the unit-vector sum (order-independent), map back to seconds-of-day. nil when
        // the resultant vector is degenerate (antipodal/uniform midpoints) — falls back to cold-start.
        let midSecs: [Int] = longestByDay.values.compactMap { block -> Int? in
            guard let midpoint = midpointSeconds(start: block.start, end: block.end) else { return nil }
            return localSecOfDay(midpoint, offsetSec: block.clockOffsetSec ?? offsetSec)
        }
        return circularMeanSec(midSecs)
    }

    /// Minimum mean-resultant-vector length (R = |Σ(sin,cos)| / n, in [0, 1]) for a circular mean to be
    /// meaningful. Below this the midpoint angles are antipodal/uniform: their resultant is ~0 so atan2
    /// returns an arbitrary direction that Swift and Kotlin can disagree on (a parity break in the
    /// degenerate case). Tiny and identical cross-platform so both sides reject the SAME inputs. (#547)
    static let circularMeanMinResultant = 1e-9

    /// Circular mean of times-of-day (seconds in [0, 86400)) via the mean unit vector (atan2 of summed
    /// sin/cos). Returns the mean direction as seconds-of-day in [0, 86400), or nil when the resultant
    /// vector is degenerate (empty, or antipodal/uniform so its magnitude is below
    /// `circularMeanMinResultant` and the angle is meaningless). nil makes `habitualMidsleepSec` fall
    /// back to cold-start rather than emit a meaningless (and cross-platform-divergent) anchor. Used for
    /// the habitual-midsleep anchor so near-midnight times average correctly. (#547)
    static func circularMeanSec(_ secs: [Int]) -> Int? {
        guard !secs.isEmpty else { return nil }
        var sumSin = 0.0, sumCos = 0.0
        let k = 2.0 * Double.pi / Double(secondsPerDay)
        for s in secs {
            let a = Double(secondOfDay(s)) * k
            sumSin += sin(a); sumCos += cos(a)
        }
        // Resultant length R = |(Σsin, Σcos)| / n. Below epsilon the direction is meaningless.
        let resultant = (sumSin * sumSin + sumCos * sumCos).squareRoot() / Double(secs.count)
        guard resultant >= circularMeanMinResultant else { return nil }
        var ang = atan2(sumSin, sumCos)               // [-π, π]
        if ang < 0 { ang += 2.0 * Double.pi }         // → [0, 2π)
        let sec = Int((ang / k).rounded()) % secondsPerDay
        return (sec + secondsPerDay) % secondsPerDay
    }
}

let zone = TimeZone(identifier: "America/New_York")!
var calendar = Calendar(identifier: .gregorian)
calendar.timeZone = zone
let format = DateFormatter()
format.calendar = calendar
format.locale = Locale(identifier: "en_US_POSIX")
format.timeZone = zone
format.dateFormat = "yyyy-MM-dd HH:mm"
let first = format.date(from: "2026-10-18 03:00")!
let now = format.date(from: "2026-11-15 12:00")!
let todayOffset = zone.secondsFromGMT(for: now)
var repositoryBlocks: [SleepStageTotals.HistoryBlock] = []
var engineBlocks: [SleepStageTotals.HistoryBlock] = []
for i in 0..<28 {
    let midpoint = calendar.date(byAdding: .day, value: i, to: first)!
    let ts = Int(midpoint.timeIntervalSince1970)
    let day = String(format.string(from: midpoint).prefix(10))
    repositoryBlocks.append(.init(start: ts - 4 * 3600, end: ts + 4 * 3600, dayKey: day))
    engineBlocks.append(.init(start: ts - 4 * 3600, end: ts + 4 * 3600, dayKey: day,
                              clockOffsetSec: zone.secondsFromGMT(for: midpoint)))
}
let repositoryHabitual = SleepStageTotals.habitualMidsleepSec(repositoryBlocks, offsetSec: todayOffset)!
let engineHabitual = SleepStageTotals.habitualMidsleepSec(engineBlocks, offsetSec: 0)!
func time(_ value: String) -> Int { Int(format.date(from: value)!.timeIntervalSince1970) }
let candidates = [
    SleepStageTotals.NightBlock(start: time("2026-11-14 21:50"), end: time("2026-11-15 01:50")),
    SleepStageTotals.NightBlock(start: time("2026-11-15 03:30"), end: time("2026-11-15 07:30")),
]
let repositoryPick = SleepStageTotals.mainNightGroupIndices(candidates, offsetSec: todayOffset,
                                                           habitualMidsleepSec: repositoryHabitual)!
let enginePick = SleepStageTotals.mainNightGroupIndices(candidates, offsetSec: todayOffset,
                                                       habitualMidsleepSec: engineHabitual)!
print("28 nights at local 03:00 midpoint, equally split before/after autumn DST")
print("Repository caller habitual: \(repositoryHabitual) sec (02:30); engine caller: \(engineHabitual) sec (03:00)")
print("Two same-wake-day four-hour blocks separated by 100 min: UI group \(repositoryPick); engine group \(enginePick)")
precondition(repositoryHabitual == 9000 && engineHabitual == 10800)
precondition(repositoryPick == [0] && enginePick == [1])
