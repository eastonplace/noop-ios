#!/usr/bin/env python3
"""Build a Linux-only test scaffold, without modifying product code.

Copies the exact production helper, recovery writer and recovery migrations;
extracts exact production value types/accessors. Only WhoopStore initialization
and base prerequisite schema are a fixture. Does not replace native package CI.
"""
from pathlib import Path
import shutil
import sys

repo = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
grdb = Path(sys.argv[3]).resolve()
src = out / "Sources" / "WhoopStore"
tests = out / "Tests" / "WhoopStoreTests"
src.mkdir(parents=True, exist_ok=True)
tests.mkdir(parents=True, exist_ok=True)


def block(text, marker):
    start = text.index(marker)
    opening = text.index("{", start)
    depth = 1
    i = opening + 1
    while depth:
        depth += (text[i] == "{") - (text[i] == "}")
        i += 1
    return text[start:i]


store_src = repo / "Packages/WhoopStore/Sources/WhoopStore"
for name in ("SleepSessionUndoStore.swift", "SleepRecoveryDailyOverrideStore.swift", "SleepRecoverySchema.swift"):
    shutil.copyfile(store_src / name, src / name)
shutil.copyfile(repo / "Packages/WhoopStore/Tests/WhoopStoreTests/SleepSessionUndoTransactionTests.swift",
                tests / "SleepSessionUndoTransactionTests.swift")
metrics = (store_src / "MetricsCache.swift").read_text()
series = (store_src / "MetricSeriesStore.swift").read_text()
identity = (store_src / "HistoricalDataCommitJournal.swift").read_text()
models = [block(metrics, "public struct CachedSleepSession:"), block(metrics, "public struct DailyMetric:"),
          block(series, "public struct MetricPoint:")]
methods = [block(metrics, marker) for marker in (
    "public func upsertSleepSessions(", "public func applySleepEdit(",
    "public func persistSessionMotion(", "public func sessionMotion(",
    "public func persistSessionSleepState(", "public func sessionSleepState(",
    "static func encodeDoubleArray(", "static func decodeDoubleArray(",
    "static func encodeIntArray(", "static func decodeIntArray(",
    "public nonisolated func dailyMetrics(", "public nonisolated func sleepSessions(",
)]
methods += [block(series, "public nonisolated func metricSeries("),
            block(identity, "public func databaseInstanceId("),
            block(identity, "static func databaseInstanceId(")]
(src / "ExtractedModelsAndMethods.swift").write_text(
    "import Foundation\nimport GRDB\nimport WhoopProtocol\n\n" + "\n\n".join(models) +
    "\n\nextension WhoopStore {\n" + "\n\n".join(methods) + "\n}\n")
(src / "SyntheticStoreFixture.swift").write_text('''import Foundation
import GRDB

enum HistoricalDataCommitJournalError: Error { case missingDatabaseIdentity }

public actor WhoopStore {
    public nonisolated let registryWriter: DatabaseQueue
    private init(_ writer: DatabaseQueue) { registryWriter = writer }
    public static func inMemory() async throws -> WhoopStore {
        let writer = try DatabaseQueue()
        try await writer.write { db in
            try db.execute(sql: """
            CREATE TABLE sleepSession(deviceId TEXT NOT NULL, startTs INTEGER NOT NULL, endTs INTEGER NOT NULL,
                efficiency REAL, restingHr INTEGER, avgHrv REAL, stagesJSON TEXT, userEdited INTEGER NOT NULL DEFAULT 0,
                startTsAdjusted INTEGER, motionJSON TEXT, sleepStateJSON TEXT, PRIMARY KEY(deviceId,startTs));
            CREATE TABLE dailyMetric(deviceId TEXT NOT NULL, day TEXT NOT NULL, totalSleepMin REAL, efficiency REAL,
                deepMin REAL, remMin REAL, lightMin REAL, disturbances INTEGER, restingHr INTEGER, avgHrv REAL,
                recovery REAL, strain REAL, exerciseCount INTEGER, spo2Pct REAL, skinTempDevC REAL, respRateBpm REAL,
                steps INTEGER, activeKcalEst REAL, spo2Red INTEGER, spo2Ir INTEGER, strainVersion INTEGER,
                PRIMARY KEY(deviceId,day));
            CREATE TABLE metricSeries(deviceId TEXT NOT NULL, day TEXT NOT NULL, key TEXT NOT NULL,
                value REAL NOT NULL, PRIMARY KEY(deviceId,day,key));
            CREATE TABLE todayHealthSnapshotDatabase(id TEXT NOT NULL);
            """)
            try db.execute(sql: "INSERT INTO todayHealthSnapshotDatabase VALUES(?)", arguments: [UUID().uuidString])
        }
        try migrateSleepRecoverySchema(writer)
        return WhoopStore(writer)
    }
    func syncRead<T>(_ body: (Database) throws -> T) throws -> T { try registryWriter.read(body) }
    func syncWrite<T>(_ body: (Database) throws -> T) throws -> T { try registryWriter.write(body) }
    nonisolated func poolRead<T: Sendable>(_ body: @Sendable @escaping (Database) throws -> T) async throws -> T {
        try await syncRead(body)
    }
}
''')
(out / "Package.swift").write_text(f'''// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "SleepMutationHarness", dependencies: [
    .package(path: "{grdb}"),
    .package(path: "{repo / 'Packages/WhoopProtocol'}")
], targets: [
    .target(name: "WhoopStore", dependencies: ["WhoopProtocol", .product(name: "GRDB", package: "GRDB.swift")]),
    .testTarget(name: "WhoopStoreTests", dependencies: ["WhoopStore"])
])
''')
print(f"Generated focused scaffold in {out}; product files remain unchanged.")
