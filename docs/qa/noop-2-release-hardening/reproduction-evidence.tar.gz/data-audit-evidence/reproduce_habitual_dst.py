#!/usr/bin/env python3
"""Run the production habitual-timing learner/selector with each existing caller's inputs."""
from pathlib import Path
import subprocess
import sys

repo = Path(sys.argv[1]).resolve()
out = Path(__file__).resolve().parent / "habitual_dst.swift"
source = (repo / "Packages/StrandAnalytics/Sources/StrandAnalytics/SleepStageTotals.swift").read_text()
out.write_text(source + r'''
let zone = TimeZone(identifier: "America/New_York")!
var calendar = Calendar(identifier: .gregorian)
calendar.timeZone = zone
let format = DateFormatter()
format.calendar = calendar
format.locale = Locale(identifier: "en_US_POSIX")
format.timeZone = zone
format.dateFormat = "yyyy-MM-dd HH:mm"
let first = format.date(from: "2026-10-18 03:00")!
let now = format.date(from: "2026-11-15 12:00")!
let todayOffset = zone.secondsFromGMT(for: now)
var repositoryBlocks: [SleepStageTotals.HistoryBlock] = []
var engineBlocks: [SleepStageTotals.HistoryBlock] = []
for i in 0..<28 {
    let midpoint = calendar.date(byAdding: .day, value: i, to: first)!
    let ts = Int(midpoint.timeIntervalSince1970)
    let day = String(format.string(from: midpoint).prefix(10))
    repositoryBlocks.append(.init(start: ts - 4 * 3600, end: ts + 4 * 3600, dayKey: day))
    engineBlocks.append(.init(start: ts - 4 * 3600, end: ts + 4 * 3600, dayKey: day,
                              clockOffsetSec: zone.secondsFromGMT(for: midpoint)))
}
let repositoryHabitual = SleepStageTotals.habitualMidsleepSec(repositoryBlocks, offsetSec: todayOffset)!
let engineHabitual = SleepStageTotals.habitualMidsleepSec(engineBlocks, offsetSec: 0)!
func time(_ value: String) -> Int { Int(format.date(from: value)!.timeIntervalSince1970) }
let candidates = [
    SleepStageTotals.NightBlock(start: time("2026-11-14 21:50"), end: time("2026-11-15 01:50")),
    SleepStageTotals.NightBlock(start: time("2026-11-15 03:30"), end: time("2026-11-15 07:30")),
]
let repositoryPick = SleepStageTotals.mainNightGroupIndices(candidates, offsetSec: todayOffset,
                                                           habitualMidsleepSec: repositoryHabitual)!
let enginePick = SleepStageTotals.mainNightGroupIndices(candidates, offsetSec: todayOffset,
                                                       habitualMidsleepSec: engineHabitual)!
print("28 nights at local 03:00 midpoint, equally split before/after autumn DST")
print("Repository caller habitual: \(repositoryHabitual) sec (02:30); engine caller: \(engineHabitual) sec (03:00)")
print("Two same-wake-day four-hour blocks separated by 100 min: UI group \(repositoryPick); engine group \(enginePick)")
precondition(repositoryHabitual == 9000 && engineHabitual == 10800)
precondition(repositoryPick == [0] && enginePick == [1])
''')
raise SystemExit(subprocess.call([sys.argv[2], "-module-cache-path", "/tmp/noop-data-clang-cache", str(out)]))
