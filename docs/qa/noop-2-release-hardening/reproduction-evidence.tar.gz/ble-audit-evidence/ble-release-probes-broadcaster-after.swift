import Foundation
final class Broadcaster {
 var wantAdvertising=true
 var lastBpm: Int?
 var sent: [Int]=[]
 func notify(bpm:Int) { sent.append(bpm) }
    public func update(heartRate bpm: Int?) {
        guard let bpm, (20...255).contains(bpm) else {
            lastBpm = nil
            return
        }
        guard wantAdvertising else { return }
        lastBpm = bpm
        notify(bpm: bpm)
    }
}
let b=Broadcaster()
b.update(heartRate:94)
b.update(heartRate:nil)
print("cached BPM after source retirement:", b.lastBpm.map(String.init) ?? "nil")
print("sent readings:", b.sent)
