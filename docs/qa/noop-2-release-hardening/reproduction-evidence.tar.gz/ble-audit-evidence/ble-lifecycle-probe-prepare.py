from pathlib import Path

source = Path('/workspace/scratch/fc582a8e42a6/noop-ios/Strand/BLE/BLEManager.swift').read_text()
start = source.index('    public func centralManagerDidUpdateState(_ central: CBCentralManager) {')
end = source.index('\n    public func centralManager(_ central: CBCentralManager,\n                               didDiscover peripheral:', start)
handler = source[start:end]
prelude = '''import Foundation
enum CBManagerState: Int { case unknown, resetting, unsupported, unauthorized, poweredOff, poweredOn }
enum CBManagerAuthorization { case denied, restricted, allowedAlways, notDetermined }
final class CBCentralManager {
    var state: CBManagerState = .poweredOff
    static let authorization = CBManagerAuthorization.allowedAlways
    func connect(_ p: CBPeripheral, options: [String: Any]?) {}
}
final class CBPeripheral {
    enum State { case disconnected, connected }
    let identifier = UUID()
    var state: State = .disconnected
}
final class LiveState {
    var connected = true
    var bluetoothUnavailableMessage: String?
    var lastSyncError: String?
}
final class BLEManager {
    let state = LiveState()
    var unauthorizedSettleWork: DispatchWorkItem?
    var radioStateErrorShown = false
    var restoredPeripheral: CBPeripheral?
    enum Family { case whoop4, whoop5 }
    struct Model { let deviceFamily: Family }
    let selectedModel = Model(deviceFamily: .whoop4)
    enum UnauthorizedAction { case showRegrantBanner, waitForSettle }
    static let unauthorizedSettleSeconds = 120
    static func unauthorizedAction(_ authorization: CBManagerAuthorization) -> UnauthorizedAction { .waitForSettle }
    func log(_ value: String) {}
    func invalidateHistoricalBackfill(reason: String) {}
    func showBluetoothRegrantBanner() {}
    func armUnauthorizedSettleDeadline() {}
    func bootstrapStore() async {}
    func handleBluetoothPoweredOn(restored: (identifier: UUID, isConnected: Bool)?, reconnect: () -> Void, resumeDiscovery: () -> Void) {}
    func startWhoop5DiscoveryIfNeeded(on p: CBPeripheral) {}
    func discoverPrimaryServices(on p: CBPeripheral) {}
'''
tests = '''
}
var failed = 0
for state in [CBManagerState.poweredOff, .resetting] {
    let manager = BLEManager()
    let central = CBCentralManager()
    central.state = state
    manager.centralManagerDidUpdateState(central)
    if manager.state.connected {
        print("FAIL: production radio handler retained connected=true after state=\\(state)")
        failed += 1
    }
}
exit(failed == 0 ? 0 : 1)
'''
Path('/tmp/noop-ble-lifecycle-probe/main.swift').write_text(prelude + handler + tests)
