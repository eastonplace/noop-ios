import Foundation
@MainActor enum HistoricalSyncBackgroundTaskRegistrar {
    static func makeOperation(
        _ operation: @escaping @MainActor @Sendable () async -> Void
    ) -> Task<Void, Never> {
        Task { @MainActor in
            guard !Task.isCancelled else { return }
            await operation()
        }
    }
}
@main struct Probe {
    @MainActor static func main() async {
        var syncRequests = 0
        let expired = HistoricalSyncBackgroundTaskRegistrar.makeOperation { syncRequests += 1 }
        expired.cancel()
        await expired.value
        print("cancelled before first execution: syncRequests=\(syncRequests)")
        let cancelledPassed = syncRequests == 0
        let active = HistoricalSyncBackgroundTaskRegistrar.makeOperation { syncRequests += 1 }
        await active.value
        print("one subsequent unexpired launch: total syncRequests=\(syncRequests)")
        exit(cancelledPassed && syncRequests == 1 ? 0 : 1)
    }
}
