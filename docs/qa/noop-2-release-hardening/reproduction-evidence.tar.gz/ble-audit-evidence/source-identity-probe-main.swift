import Foundation
struct HistoricalCursorScope { let deviceId: String }
struct PairedDevice { let id: String; var peripheralId: String? }
@MainActor final class Registry {
 var activeDeviceId: String? = "a"
 var devices = [PairedDevice(id: "a", peripheralId: nil), PairedDevice(id: "b", peripheralId: nil)]
 func historicalCursorScope(for id: String) throws -> HistoricalCursorScope { .init(deviceId:id) }
 func setPeripheralId(_ id: String, peripheralId: String) throws -> Bool { devices[devices.firstIndex(where:{$0.id==id})!].peripheralId = peripheralId; return true }
}
@MainActor final class Live { var encryptedBond = false; func append(log: String) {} }
@MainActor final class SourceCoordinator {
 let registry: Registry; let transitionFence: SourceTransitionFence; let live = Live()
 var connectedWhoopUuid: String?
 var identityObservationGeneration: UInt64 = 0
 let onPeripheralIdentityWillChangeWithPeripheral: ((String, HistoricalCursorScope, String) async throws -> Void)? = nil
 let onPeripheralIdentityWillChange: (String, HistoricalCursorScope) async throws -> Void = {_,_ in}
 let onPeripheralIdentityDidChange: (String) async throws -> Void = {_ in}
 init(_ registry: Registry, _ fence: SourceTransitionFence) { self.registry=registry; self.transitionFence=fence }
 func publish(_ uuid: String) { connectedPeripheralChanged(to: uuid) }
 private func isWhoop(_ id: String) -> Bool { true }
 private func peripheralId(for id: String) -> String? { registry.devices.first(where:{$0.id==id})?.peripheralId }
    func connectedPeripheralChanged(to uuid: String?) -> Task<Void, Never> {
        identityObservationGeneration &+= 1
        let observationGeneration = identityObservationGeneration
        let observedDeviceId = registry.activeDeviceId
        let observedEncryptedBond = live.encryptedBond
        return Task { @MainActor [weak self] in
            guard let self else { return }
            await self.transitionFence.run { @MainActor [weak self] in
                guard let self,
                      self.identityObservationGeneration == observationGeneration,
                      self.registry.activeDeviceId == observedDeviceId else { return }
                await self.reconcileConnectedPeripheral(to: uuid, encryptedBond: observedEncryptedBond)
            }
        }
    }
    private func reconcileConnectedPeripheral(to uuid: String?, encryptedBond: Bool) async {
        // Track the live strap's uuid for the WHOOP->WHOOP adopt-in-place skip (#74). nil is a
        // disconnect/never-connected republish: clear it so a later make-active can't wrongly match a stale
        // link, then fall through to the existing ignore.
        connectedWhoopUuid = uuid
        guard let uuid else { return }

        guard let activeId = registry.activeDeviceId else { return }
        guard isWhoop(activeId),
              let device = registry.devices.first(where: { $0.id == activeId }) else { return }

        switch device.peripheralId {
        case .none:
            // First connect for this WHOOP row → adopt the strap's stable identity.
            do { try await adoptPeripheralIdentity(uuid, for: activeId) }
            catch { live.append(log: "Physical source transition deferred: \(error)") }
        case .some(uuid):
            break                               // already adopted this exact strap → nothing to do
        case .some(let existing):
            // A DIFFERENT strap connected under this WHOOP row. Re-adopt ONLY when this is the #52 stale-pin
            // handoff — i.e. the engine is genuinely encrypted-bonded to the strap whose id just arrived.
            // BLEManager only republishes `connectedPeripheralUUID` with `encryptedBond` true as that vetted
            // handoff (after the pinned strap refused the bond N× while this one bonded); an ordinary
            // pre-bond `didConnect` publish always carries `encryptedBond == false`, so the protective
            // "don't clobber" path below is preserved for every normal/transient different-strap connect.
            if encryptedBond {
                live.append(log: "Multi-WHOOP (#52): active device \(activeId) was pinned to strap \(existing) which refused to bond — re-adopting the working strap \(uuid).")
                do { try await adoptPeripheralIdentity(uuid, for: activeId) }
                catch { live.append(log: "Physical source transition deferred: \(error)") }
            } else {
                live.append(log: "Multi-WHOOP: active device \(activeId) is registered to strap \(existing) but \(uuid) connected — not overwriting.")
            }
        }
    }
    private func adoptPeripheralIdentity(_ uuid: String, for activeId: String) async throws {
        guard peripheralId(for: activeId) != uuid else { return }
        let oldScope = try registry.historicalCursorScope(for: activeId)
        if let callback = onPeripheralIdentityWillChangeWithPeripheral {
            try await callback(activeId, oldScope, uuid)
            try await onPeripheralIdentityDidChange(activeId)
            return
        }
        try await onPeripheralIdentityWillChange(activeId, oldScope)
        guard try registry.setPeripheralId(activeId, peripheralId: uuid) else { return }
        try await onPeripheralIdentityDidChange(activeId)
    }
}
@main struct Probe {
 @MainActor static func main() async {
  let registry=Registry(), fence=SourceTransitionFence()
  let coordinator=SourceCoordinator(registry,fence)
  await fence.run {
   // A's callback lands while A-to-B durable transition is awaiting cleanup.
   coordinator.publish("uuid-from-strap-a")
   for _ in 0..<10 { await Task.yield() }
   registry.activeDeviceId="b"
  }
  for _ in 0..<100 {
   if registry.devices[1].peripheralId != nil { break }
   await Task.yield()
  }
  print("A identity:", registry.devices[0].peripheralId ?? "nil")
  print("B identity:", registry.devices[1].peripheralId ?? "nil")
  if registry.devices[1].peripheralId == "uuid-from-strap-a" { exit(1) }
 }
}
