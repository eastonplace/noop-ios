import Foundation
enum CBManagerState: Int { case unknown, resetting, unsupported, unauthorized, poweredOff, poweredOn }
enum CBManagerAuthorization { case denied, restricted, allowedAlways, notDetermined }
final class CBCentralManager {
    var state: CBManagerState = .poweredOff
    static let authorization = CBManagerAuthorization.allowedAlways
    func connect(_ p: CBPeripheral, options: [String: Any]?) {}
}
final class CBPeripheral {
    enum State { case disconnected, connected }
    let identifier = UUID()
    var state: State = .disconnected
}
final class LiveState {
    var connected = true
    var bluetoothUnavailableMessage: String?
    var lastSyncError: String?
}
final class BLEManager {
    let state = LiveState()
    var unauthorizedSettleWork: DispatchWorkItem?
    var radioStateErrorShown = false
    var restoredPeripheral: CBPeripheral?
    enum Family { case whoop4, whoop5 }
    struct Model { let deviceFamily: Family }
    let selectedModel = Model(deviceFamily: .whoop4)
    enum UnauthorizedAction { case showRegrantBanner, waitForSettle }
    static let unauthorizedSettleSeconds = 120
    static func unauthorizedAction(_ authorization: CBManagerAuthorization) -> UnauthorizedAction { .waitForSettle }
    func log(_ value: String) {}
    func invalidateHistoricalBackfill(reason: String) {}
    func showBluetoothRegrantBanner() {}
    func armUnauthorizedSettleDeadline() {}
    func bootstrapStore() async {}
    func handleBluetoothPoweredOn(restored: (identifier: UUID, isConnected: Bool)?, reconnect: () -> Void, resumeDiscovery: () -> Void) {}
    func startWhoop5DiscoveryIfNeeded(on p: CBPeripheral) {}
    func discoverPrimaryServices(on p: CBPeripheral) {}
    public func centralManagerDidUpdateState(_ central: CBCentralManager) {
        log("Central state: \(central.state.rawValue) (5 = poweredOn)")
        #if DEBUG
        if CommandLine.arguments.contains("--demo-bluetooth-off") {
            state.bluetoothUnavailableMessage = "Bluetooth is off. Turn it on in Settings to connect a device."
            return
        }
        #endif
        // #391: ANY state update means the cold-start settling window moved on — a pending
        // unauthorized-settle escalation is obsolete whether the new state is good news (poweredOn)
        // or its own banner-worthy case (poweredOff handles itself below).
        unauthorizedSettleWork?.cancel()
        unauthorizedSettleWork = nil
        guard central.state == .poweredOn else {
            invalidateHistoricalBackfill(reason: "Bluetooth is no longer powered on")
            switch central.state {
            case .poweredOff:
                state.bluetoothUnavailableMessage = "Bluetooth is off. Turn it on in Settings to connect a device."
            case .unauthorized:
                state.bluetoothUnavailableMessage = "Bluetooth access is denied. Allow NOOP in Settings › Privacy & Security › Bluetooth."
            case .unsupported:
                state.bluetoothUnavailableMessage = "Bluetooth isn't supported on this device."
            default:
                state.bluetoothUnavailableMessage = "Bluetooth is unavailable right now. Try again in a moment."
            }
            // #280: a non-poweredOn radio state used to be a SILENT return — the strap log showed only
            // "Central state: 3" and the UI just read "not connected", so a user whose Mac had denied NOOP
            // Bluetooth (.unauthorized == raw 3) had nothing explaining why no strap was ever found. This is
            // the #280 case: an unsigned universal rebuild (8.4.0) gets a new code identity, so the earlier
            // macOS Bluetooth TCC grant no longer applied and CoreBluetooth reported .unauthorized before
            // any scan/connect. Surface the actionable states via lastSyncError (shown in Live + Today);
            // leave .unknown/.resetting alone — they're transient and the next state update resolves them.
            // Android already surfaces all three (WhoopBleClient: no-LE / off / permission), so this brings
            // iOS+macOS up to that parity rather than adding a new behaviour.
            switch central.state {
            case .unauthorized:
                // #391 (design from digitalerdude's #407): CoreBluetooth on macOS can transiently report
                // `.unauthorized` during the cold-start settling window (before the central finishes
                // connecting to bluetoothd) even when the TCC grant is fine — the state then advances to
                // .poweredOff/.poweredOn on the next callback and the strap connects. The `authorization`
                // property reads the TCC grant DIRECTLY, independent of that transient state, so it can tell
                // a genuine denial (#280/#295) from the settling case — latching the re-grant banner on ANY
                // `.unauthorized` pushed users to toggle Bluetooth off/on to clear a false message. The
                // settle path is NOT unbounded silence: a wedged grant (#429) presents identically and never
                // settles, so it runs under `armUnauthorizedSettleDeadline`'s one-shot escalation.
                // The CLASS property (`CBCentralManager.authorization`), not the `central.authorization`
                // instance property — that one is deprecated on iOS (13.0 → 13.1); both read the same grant.
                switch Self.unauthorizedAction(CBCentralManager.authorization) {
                case .showRegrantBanner:
                    showBluetoothRegrantBanner()
                case .waitForSettle:
                    log("Central reported unauthorized but the Bluetooth grant reads OK — transient cold-start settling (#391); re-grant banner deferred \(Self.unauthorizedSettleSeconds)s")
                    armUnauthorizedSettleDeadline()
                }
            case .poweredOff:
                state.lastSyncError = "Bluetooth is off. Turn it on to connect to your strap."
                log("Bluetooth is off — cannot scan or connect")
                radioStateErrorShown = true
            case .unsupported:
                state.lastSyncError = "This device can't use Bluetooth Low Energy."
                log("Bluetooth LE unsupported on this device")
                radioStateErrorShown = true
            default:
                break
            }
            return
        }
        state.bluetoothUnavailableMessage = nil
        // #280: radio is back — clear a stale radio-state banner (only one WE set), so a "Bluetooth is off"
        // message doesn't outlive the radio coming on. A genuine sync error is left untouched.
        if radioStateErrorShown {
            state.lastSyncError = nil
            radioStateErrorShown = false
        }
        // Bootstrap the async store once on first poweredOn (idempotent if already set).
        Task { @MainActor in await bootstrapStore() }
        let restored = restoredPeripheral
        handleBluetoothPoweredOn(
            restored: restored.map { (identifier: $0.identifier, isConnected: $0.state == .connected) },
            reconnect: { [central] in
                if let restored { central.connect(restored, options: nil) }
            },
            resumeDiscovery: {
                guard let restored else { return }
                if selectedModel.deviceFamily == .whoop5 {
                    startWhoop5DiscoveryIfNeeded(on: restored)
                } else {
                    discoverPrimaryServices(on: restored)
                }
            })
    }

}
var failed = 0
for state in [CBManagerState.poweredOff, .resetting] {
    let manager = BLEManager()
    let central = CBCentralManager()
    central.state = state
    manager.centralManagerDidUpdateState(central)
    if manager.state.connected {
        print("FAIL: production radio handler retained connected=true after state=\(state)")
        failed += 1
    }
}
exit(failed == 0 ? 0 : 1)
