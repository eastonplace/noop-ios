import Foundation
final class State {
    var publications = 0
    var standardHRMode: String? { didSet { publications += 1 } }
}
final class BLEManager {
    enum Family { case whoop4, whoop5 }
    struct Model { let deviceFamily: Family }
    enum Fallback { case none, standardOnlyConfirmed }
    let selectedModel = Model(deviceFamily: .whoop5)
    let whoop5SecureReady = false
    var whoop5FallbackMode = Fallback.none
    var autoReconnectPausedForWhoop5SecureFailure = false
    let state = State()
    var logs: [String] = []
    func log(_ text: String) { logs.append(text) }
    func updateWhoop5StandardHRFallback() {
        guard selectedModel.deviceFamily == .whoop5, !whoop5SecureReady else { return }
        whoop5FallbackMode = .standardOnlyConfirmed
        let mode = autoReconnectPausedForWhoop5SecureFailure
            ? "Live HR only - secure session paused. Tap Connect to retry."
            : "Live HR only - secure WHOOP session is still being established."
        // @Published emits even when assigned the same string. Announce only a transition; every
        // notification still goes through parseStandardHR before this method, including HR/RR storage.
        guard state.standardHRMode != mode else { return }
        state.standardHRMode = mode
        if autoReconnectPausedForWhoop5SecureFailure {
            log("WHOOP 5/MG: standard HR is live while secure recovery remains paused.")
        } else {
            log("WHOOP 5/MG: standard HR is live while the proprietary secure session remains unverified.")
        }
    }
}
let manager = BLEManager()
for _ in 0..<3600 { manager.updateWhoop5StandardHRFallback() }
print("3600 fallback notifications: publications=\(manager.state.publications) logs=\(manager.logs.count)")
let firstPass = manager.state.publications == 1 && manager.logs.count == 1
manager.autoReconnectPausedForWhoop5SecureFailure = true
for _ in 0..<3600 { manager.updateWhoop5StandardHRFallback() }
print("3600 paused notifications: total publications=\(manager.state.publications) logs=\(manager.logs.count)")
exit(firstPass && manager.state.publications == 2 && manager.logs.count == 2 ? 0 : 1)
