from pathlib import Path
import subprocess
repo=Path('/workspace/scratch/fc582a8e42a6/noop-ios')
out=Path('/tmp/noop-ble-release-probes')
base='a7ade2598d439d33cd20816d69ccc991b29322fc'
def source(path, old):
 return subprocess.check_output(['git','show',base+':'+path],cwd=repo,text=True) if old else (repo/path).read_text()
def method(src, token):
 start=src.index(token); brace=src.index('{',start); depth=1; end=brace+1
 while depth:
  depth+=(src[end]=='{')-(src[end]=='}');end+=1
 return src[start:end]
for old in (True,False):
 suffix='before' if old else 'after'
 ble=source('Strand/BLE/BLEManager.swift',old)
 upsert_start=ble.index('        try? await store.upsertDevice' if old else '        try? await upsertDevice')
 upsert_end=ble.index('        collector?.log',upsert_start)
 upsert=ble[upsert_start:upsert_end]
 seed_start=ble.index('        let seedNow = Int(Date().timeIntervalSince1970)')
 seed_end=ble.index('\n    }',seed_start)
 seed=ble[seed_start:seed_end]
 harness='''import Foundation
struct BatterySample { let ts: Int; let soc: Double? }
@MainActor final class Store {
 var onUpsert: (() -> Void)?
 var onRead: (() -> Void)?
 func upsertDevice(id: String, mac: String?, name: String?) async throws { onUpsert?() }
 func batterySamples(deviceId: String, from: Int, to: Int, limit: Int) async throws -> [BatterySample] { onRead?(); return [BatterySample(ts:1,soc:88)] }
}
@MainActor final class Collector { init(store: Store, deviceId: String, enableRawCapture: Bool) {} }
@MainActor final class State {
 var currentHeartRateSource: String?
 var batterySamples: [(ts:Int,soc:Double)]=[]
 func seedBatterySamples(_ rows: [(ts:Int,soc:Double)]) { batterySamples += rows }
}
@MainActor final class ProbeManager {
 var restoreInProgress=false
 var historicalMaterializationStoreGeneration=1
 var historicalSourceEpoch=1
 var deviceId="strap-a"
 var dataStore: Store? = Store()
 var collector: Collector?
 let state=State()
 func bootstrap() async {
  let store=dataStore!
  let registryReadStoreGeneration=historicalMaterializationStoreGeneration
  let upsertDevice: @MainActor (Store,String) async throws -> Void = { try await $0.upsertDevice(id:$1,mac:nil,name:nil) }
''' + upsert + '''
 }
 func seedBattery() async {
  let store=dataStore!
  let registryReadStoreGeneration=historicalMaterializationStoreGeneration
  let readBatterySamples: @MainActor (Store,String,Int,Int) async throws -> [BatterySample] = { try await $0.batterySamples(deviceId:$1,from:$2,to:$3,limit:2000) }
''' + seed + '''
 }
}
@main struct Main {
 @MainActor static func main() async {
  let bootstrap=ProbeManager()
  bootstrap.dataStore?.onUpsert={ bootstrap.dataStore=Store(); bootstrap.historicalMaterializationStoreGeneration += 1 }
  await bootstrap.bootstrap()
  print("retired store installed collector:",bootstrap.collector != nil)
  let battery=ProbeManager()
  battery.dataStore?.onRead={ battery.deviceId="strap-b"; battery.historicalSourceEpoch += 1; battery.state.batterySamples=[(2,22)] }
  await battery.seedBattery()
  print("battery samples after source replacement:", battery.state.batterySamples.map(\\.soc))
 }
}
'''
 (out/f'bootstrap-{suffix}.swift').write_text(harness)
 broad=source('Strand/BLE/HrBroadcaster.swift',old)
 update=method(broad,'    public func update(')
 (out/f'broadcaster-{suffix}.swift').write_text('''import Foundation
final class Broadcaster {
 var wantAdvertising=true
 var lastBpm: Int?
 var sent: [Int]=[]
 func notify(bpm:Int) { sent.append(bpm) }
'''+update+'''
}
let b=Broadcaster()
b.update(heartRate:94)
b.update(heartRate:nil)
print("cached BPM after source retirement:", b.lastBpm.map(String.init) ?? "nil")
print("sent readings:", b.sent)
''')
