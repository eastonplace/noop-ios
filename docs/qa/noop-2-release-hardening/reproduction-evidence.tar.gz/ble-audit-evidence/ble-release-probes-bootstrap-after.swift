import Foundation
struct BatterySample { let ts: Int; let soc: Double? }
@MainActor final class Store {
 var onUpsert: (() -> Void)?
 var onRead: (() -> Void)?
 func upsertDevice(id: String, mac: String?, name: String?) async throws { onUpsert?() }
 func batterySamples(deviceId: String, from: Int, to: Int, limit: Int) async throws -> [BatterySample] { onRead?(); return [BatterySample(ts:1,soc:88)] }
}
@MainActor final class Collector { init(store: Store, deviceId: String, enableRawCapture: Bool) {} }
@MainActor final class State {
 var currentHeartRateSource: String?
 var batterySamples: [(ts:Int,soc:Double)]=[]
 func seedBatterySamples(_ rows: [(ts:Int,soc:Double)]) { batterySamples += rows }
}
@MainActor final class ProbeManager {
 var restoreInProgress=false
 var historicalMaterializationStoreGeneration=1
 var historicalSourceEpoch=1
 var deviceId="strap-a"
 var dataStore: Store? = Store()
 var collector: Collector?
 let state=State()
 func bootstrap() async {
  let store=dataStore!
  let registryReadStoreGeneration=historicalMaterializationStoreGeneration
  let upsertDevice: @MainActor (Store,String) async throws -> Void = { try await $0.upsertDevice(id:$1,mac:nil,name:nil) }
        try? await upsertDevice(store, deviceId)
        // Restore or another bootstrap can retire this handle while SQLite is suspended.
        // Only the opening generation may install its collectors into the current manager.
        guard !restoreInProgress, collector == nil, dataStore === store,
              historicalMaterializationStoreGeneration == registryReadStoreGeneration else { return }
        // Research toggle — OFF by default. When disabled the app is decoded-only and never
        // persists raw frames. Flip "enableRawCapture" in UserDefaults to capture raw again.
        let enableRawCapture = UserDefaults.standard.bool(forKey: "enableRawCapture")
        collector = Collector(store: store, deviceId: deviceId,
                              enableRawCapture: enableRawCapture)

 }
 func seedBattery() async {
  let store=dataStore!
  let registryReadStoreGeneration=historicalMaterializationStoreGeneration
  let readBatterySamples: @MainActor (Store,String,Int,Int) async throws -> [BatterySample] = { try await $0.batterySamples(deviceId:$1,from:$2,to:$3,limit:2000) }
        let seedNow = Int(Date().timeIntervalSince1970)
        let fourteenDays = 14 * 24 * 3600
        let seedDeviceId = deviceId
        let seedSourceEpoch = historicalSourceEpoch
        let seedHeartRateSource = state.currentHeartRateSource
        guard !restoreInProgress, dataStore === store,
              historicalMaterializationStoreGeneration == registryReadStoreGeneration else { return }
        if let rows = try? await readBatterySamples(store, seedDeviceId, seedNow - fourteenDays, seedNow) {
            guard !restoreInProgress, dataStore === store,
                  historicalMaterializationStoreGeneration == registryReadStoreGeneration,
                  deviceId == seedDeviceId, historicalSourceEpoch == seedSourceEpoch,
                  state.currentHeartRateSource == seedHeartRateSource else { return }
            let seed = rows.compactMap { row -> (ts: Int, soc: Double)? in
                guard let soc = row.soc else { return nil }
                return (ts: row.ts, soc: soc)
            }
            state.seedBatterySamples(seed)
        }
 }
}
@main struct Main {
 @MainActor static func main() async {
  let bootstrap=ProbeManager()
  bootstrap.dataStore?.onUpsert={ bootstrap.dataStore=Store(); bootstrap.historicalMaterializationStoreGeneration += 1 }
  await bootstrap.bootstrap()
  print("retired store installed collector:",bootstrap.collector != nil)
  let battery=ProbeManager()
  battery.dataStore?.onRead={ battery.deviceId="strap-b"; battery.historicalSourceEpoch += 1; battery.state.batterySamples=[(2,22)] }
  await battery.seedBattery()
  print("battery samples after source replacement:", battery.state.batterySamples.map(\.soc))
 }
}
