import Foundation
struct Streams: Sendable {}
struct Counts { let gravity: Int }
@MainActor final class Store {
 var owners:[String]=[]; var onInsert:(() -> Void)?
 func insert(_ streams:Streams,deviceId:String) async throws -> Counts { owners.append(deviceId);onInsert?();return Counts(gravity:1) }
}
@MainActor final class Archive {
 var onStart:(() -> Void)?
 func replay(subLagInterp:Bool,insert:@Sendable(Streams)async throws->Int) async throws->Int { onStart?();return try await insert(Streams()) }
}
enum PuffinExperiment { static let ppgHrSubLagInterpEnabled=false }
@MainActor final class Manager {
 typealias RejectedHistoryReplay = @MainActor (@escaping @Sendable (Streams) async throws -> Int) async throws -> Int
 var deviceId="strap-a"; var historicalSourceEpoch:Int64=1
 var historicalMaterializationStoreGeneration=1;var restoreInProgress=false
 var dataStore:Store?=Store();let rejectedHistoryArchive=Archive()
 static let rejectArchiveReplayKey="noop-audit-probe-only-replay-key"
 static func rejectArchiveReplayStamp()->String { "completed" }
 static func rejectArchiveReplayIsDue()->Bool { true }
 func log(_ text:String) {}
 func run() async {
 let store=dataStore!;let registryReadStoreGeneration=historicalMaterializationStoreGeneration
 let replayRejectedHistory:RejectedHistoryReplay?=nil
        let replayKey = Self.rejectArchiveReplayKey
        let replayStamp = Self.rejectArchiveReplayStamp()
        if Self.rejectArchiveReplayIsDue() {
            do {
                let rows = try await rejectedHistoryArchive.replay(
                    subLagInterp: PuffinExperiment.ppgHrSubLagInterpEnabled
                ) { streams in
                    try await store.insert(streams, deviceId: deviceId).gravity
                }
                if rows > 0 { log("Backfill: retro-decoded \(rows) record(s) from the reject archive after an update.") }
                // Advance the gate ONLY on success — a failed insert must retry next launch, because
                // the archive holds the only surviving copy of these records. (#152)
                UserDefaults.standard.set(replayStamp, forKey: replayKey)
            } catch {
                log("Backfill: reject-archive retro-decode deferred (store insert failed) — will retry next launch.")
            }
        }


}
    private func isStoreBootstrapCurrent(
        store: Store, generation: Int, deviceId: String, sourceEpoch: Int64
    ) -> Bool {
        !restoreInProgress && dataStore === store
            && historicalMaterializationStoreGeneration == generation
            && self.deviceId == deviceId && historicalSourceEpoch == sourceEpoch
    }
}
@main struct Probe {
 @MainActor static func main() async {
  let d=UserDefaults.standard;d.removeObject(forKey:Manager.rejectArchiveReplayKey)
  let manager=Manager();let store=manager.dataStore!
  manager.rejectedHistoryArchive.onStart={ manager.deviceId="strap-b";manager.historicalSourceEpoch += 1 }
  await manager.run()
  print("replay write owners after source switch:",store.owners)
  print("source-switched replay stamped:",d.object(forKey:Manager.rejectArchiveReplayKey) != nil)
  d.removeObject(forKey:Manager.rejectArchiveReplayKey)
  let restoring=Manager();let oldStore=restoring.dataStore!
  oldStore.onInsert={ restoring.dataStore=Store();restoring.historicalMaterializationStoreGeneration += 1 }
  await restoring.run()
  print("retired-store replay stamped:",d.object(forKey:Manager.rejectArchiveReplayKey) != nil)
  d.removeObject(forKey:Manager.rejectArchiveReplayKey)
 }
}
