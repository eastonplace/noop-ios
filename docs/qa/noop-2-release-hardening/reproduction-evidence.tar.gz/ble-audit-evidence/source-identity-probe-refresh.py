from pathlib import Path
repo=Path('/workspace/scratch/fc582a8e42a6/noop-ios')
src=(repo/'Strand/BLE/SourceCoordinator.swift').read_text()
p=Path('/tmp/noop-source-identity-probe/main.swift')
original=p.read_text()
def method(name):
 token='    func '+name if name=='connectedPeripheralChanged' else '    private func '+name
 start=src.index(token); brace=src.index('{',start); depth=1; end=brace+1
 while depth:
  depth += (src[end]=='{')-(src[end]=='}'); end+=1
 return src[start:end]
start=original.index('    private func connectedPeripheralChanged')
end=original.index('\n}\n@main',start)
original=original[:start]+'\n'.join(method(n) for n in ['connectedPeripheralChanged','reconcileConnectedPeripheral','adoptPeripheralIdentity'])+original[end:]
original=original.replace(' var connectedWhoopUuid: String?', ' var connectedWhoopUuid: String?\n var identityObservationGeneration: UInt64 = 0')
p.write_text(original)
