import Foundation
struct Source: Equatable { let providerSessionID: String?; let deviceId: String }
@MainActor final class State {
 var currentHeartRateSource: Source?
 func activateHeartRateSource(_ source: Source?) { currentHeartRateSource = source }
}
final class Store: @unchecked Sendable { let registryWriter = 0 }
struct DeviceRegistryStore {
 static var onRead: (() -> String?)?
 init(dbQueue: Int) {}
 func activeDeviceId() throws -> String? { Self.onRead?() }
}
@MainActor final class ProbeManager {
 var deviceId = "strap-a"
 var historicalSourceEpoch: Int64 = 1
 var historicalMaterializationStoreGeneration = 1
 var restoreInProgress = false
 var collector: Int?
 let state = State()
 func setActiveDeviceId(_ id: String) {
  if id != deviceId { historicalSourceEpoch += 1 }
  deviceId = id
  state.activateHeartRateSource(nil)
 }
 func resumeBootstrapRegistryRead() async {
  let store = Store()
        let registryWriter = store.registryWriter
        let registryReadDeviceId = deviceId
        let registryReadSource = state.currentHeartRateSource
        let registryReadStoreGeneration = historicalMaterializationStoreGeneration
        let activeId = await Task.detached(priority: .userInitiated) {
            try? DeviceRegistryStore(dbQueue: registryWriter).activeDeviceId()
        }.value
        guard !restoreInProgress, collector == nil,
              historicalMaterializationStoreGeneration == registryReadStoreGeneration else { return }
        // A source selection can finish during the read. Keep initializing the collector for the current
        // explicit owner, but do not let this older registry snapshot reparent it or clear provider HR.
        if let activeId, !activeId.isEmpty,
           deviceId == registryReadDeviceId,
           state.currentHeartRateSource == registryReadSource,
           state.currentHeartRateSource?.providerSessionID == nil {
            self.deviceId = activeId
            if let source = state.currentHeartRateSource, source.deviceId != activeId {
                state.activateHeartRateSource(nil)
            }
        }

 }
}
@main struct Main {
 @MainActor static func main() async {
  let manager = ProbeManager()
  DeviceRegistryStore.onRead = {
   let readSnapshot = "strap-b"
   let finished = DispatchSemaphore(value: 0)
   Task { @MainActor in
    manager.setActiveDeviceId("strap-b")
    manager.setActiveDeviceId("strap-a")
    finished.signal()
   }
   finished.wait()
   return readSnapshot
  }
  await manager.resumeBootstrapRegistryRead()
  print("Source epoch after A→B→A:", manager.historicalSourceEpoch)
  print("Current owner after stale B registry read:", manager.deviceId)
  if manager.deviceId != "strap-a" {
   print("FAIL: stale registry read overwrote latest explicit owner")
   exit(1)
  }
  print("PASS: latest explicit owner retained")
 }
}
