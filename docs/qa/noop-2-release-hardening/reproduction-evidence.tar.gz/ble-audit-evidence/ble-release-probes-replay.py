from pathlib import Path
import subprocess
repo=Path('/workspace/scratch/fc582a8e42a6/noop-ios'); out=Path('/tmp/noop-ble-release-probes')
base='a7ade2598d439d33cd20816d69ccc991b29322fc'
def block(src):
 a=src.index('        let replayKey = Self.rejectArchiveReplayKey'); b=src.index('        // Battery "~X days left" seed',a)
 return src[a:b]
def method(src):
 a=src.index('    private func isStoreBootstrapCurrent('); brace=src.index('{',a);depth=1;b=brace+1
 while depth: depth+=(src[b]=='{')-(src[b]=='}');b+=1
 return src[a:b].replace('WhoopStore','Store')
head=(repo/'Strand/BLE/BLEManager.swift').read_text()
for old in (True,False):
 src=subprocess.check_output(['git','show',base+':Strand/BLE/BLEManager.swift'],cwd=repo,text=True) if old else head
 harness='''import Foundation
struct Streams: Sendable {}
struct Counts { let gravity: Int }
@MainActor final class Store {
 var owners:[String]=[]; var onInsert:(() -> Void)?
 func insert(_ streams:Streams,deviceId:String) async throws -> Counts { owners.append(deviceId);onInsert?();return Counts(gravity:1) }
}
@MainActor final class Archive {
 var onStart:(() -> Void)?
 func replay(subLagInterp:Bool,insert:@Sendable(Streams)async throws->Int) async throws->Int { onStart?();return try await insert(Streams()) }
}
enum PuffinExperiment { static let ppgHrSubLagInterpEnabled=false }
@MainActor final class Manager {
 typealias RejectedHistoryReplay = @MainActor (@escaping @Sendable (Streams) async throws -> Int) async throws -> Int
 var deviceId="strap-a"; var historicalSourceEpoch:Int64=1
 var historicalMaterializationStoreGeneration=1;var restoreInProgress=false
 var dataStore:Store?=Store();let rejectedHistoryArchive=Archive()
 static let rejectArchiveReplayKey="noop-audit-probe-only-replay-key"
 static func rejectArchiveReplayStamp()->String { "completed" }
 static func rejectArchiveReplayIsDue()->Bool { true }
 func log(_ text:String) {}
 func run() async {
 let store=dataStore!;let registryReadStoreGeneration=historicalMaterializationStoreGeneration
 let replayRejectedHistory:RejectedHistoryReplay?=nil
''' + block(src) + '\n}\n' + method(head) + '''
}
@main struct Probe {
 @MainActor static func main() async {
  let d=UserDefaults.standard;d.removeObject(forKey:Manager.rejectArchiveReplayKey)
  let manager=Manager();let store=manager.dataStore!
  manager.rejectedHistoryArchive.onStart={ manager.deviceId="strap-b";manager.historicalSourceEpoch += 1 }
  await manager.run()
  print("replay write owners after source switch:",store.owners)
  print("source-switched replay stamped:",d.object(forKey:Manager.rejectArchiveReplayKey) != nil)
  d.removeObject(forKey:Manager.rejectArchiveReplayKey)
  let restoring=Manager();let oldStore=restoring.dataStore!
  oldStore.onInsert={ restoring.dataStore=Store();restoring.historicalMaterializationStoreGeneration += 1 }
  await restoring.run()
  print("retired-store replay stamped:",d.object(forKey:Manager.rejectArchiveReplayKey) != nil)
  d.removeObject(forKey:Manager.rejectArchiveReplayKey)
 }
}
'''
 (out/('replay-before.swift' if old else 'replay-after.swift')).write_text(harness)
