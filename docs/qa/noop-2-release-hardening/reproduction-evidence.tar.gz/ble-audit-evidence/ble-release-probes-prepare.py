from pathlib import Path
root = Path('/workspace/scratch/fc582a8e42a6/noop-ios')
out = Path('/tmp/noop-ble-release-probes')
def method(path, marker):
    source=(root/path).read_text()
    start=source.index(marker)
    opening=source.index('{',start)
    depth=1
    for end in range(opening+1,len(source)):
        if source[end]=='{':depth+=1
        if source[end]=='}':depth-=1
        if depth==0:return source[start:end+1]
    raise AssertionError(marker)
fallback=method('Strand/BLE/BLEManager.swift','    func updateWhoop5StandardHRFallback()')
(out/'fallback.swift').write_text('''import Foundation
final class State {
    var publications = 0
    var standardHRMode: String? { didSet { publications += 1 } }
}
final class BLEManager {
    enum Family { case whoop4, whoop5 }
    struct Model { let deviceFamily: Family }
    enum Fallback { case none, standardOnlyConfirmed }
    let selectedModel = Model(deviceFamily: .whoop5)
    let whoop5SecureReady = false
    var whoop5FallbackMode = Fallback.none
    var autoReconnectPausedForWhoop5SecureFailure = false
    let state = State()
    var logs: [String] = []
    func log(_ text: String) { logs.append(text) }
''' + fallback + '''
}
let manager = BLEManager()
for _ in 0..<3600 { manager.updateWhoop5StandardHRFallback() }
print("3600 fallback notifications: publications=\\(manager.state.publications) logs=\\(manager.logs.count)")
let firstPass = manager.state.publications == 1 && manager.logs.count == 1
manager.autoReconnectPausedForWhoop5SecureFailure = true
for _ in 0..<3600 { manager.updateWhoop5StandardHRFallback() }
print("3600 paused notifications: total publications=\\(manager.state.publications) logs=\\(manager.logs.count)")
exit(firstPass && manager.state.publications == 2 && manager.logs.count == 2 ? 0 : 1)
''')
operation=method('StrandiOS/App/HistoricalSyncBackgroundTaskRegistrar.swift','    static func makeOperation(')
(out/'cancellation.swift').write_text('''import Foundation
@MainActor enum HistoricalSyncBackgroundTaskRegistrar {
''' + operation + '''
}
@main struct Probe {
    @MainActor static func main() async {
        var syncRequests = 0
        let expired = HistoricalSyncBackgroundTaskRegistrar.makeOperation { syncRequests += 1 }
        expired.cancel()
        await expired.value
        print("cancelled before first execution: syncRequests=\\(syncRequests)")
        let cancelledPassed = syncRequests == 0
        let active = HistoricalSyncBackgroundTaskRegistrar.makeOperation { syncRequests += 1 }
        await active.value
        print("one subsequent unexpired launch: total syncRequests=\\(syncRequests)")
        exit(cancelledPassed && syncRequests == 1 ? 0 : 1)
    }
}
''')
