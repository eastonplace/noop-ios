# Coach audit evidence

Cloud: 30 tests pass on the final implementation. Original baseline: 15 failing cases / 21 failed assertions out of 26 tests. Retry-boundary baseline: 2 failures out of 4 tests; both valid retry controls pass. Weekly: 8 tests pass; baseline 6 failing cases / 10 failed assertions.

See ui-audit.md for findings and full reviewed-file manifest. cloud/README.md and weekly/README.md describe exact source extraction, test doubles, red/green snapshots and reproduction. Packaged Sources/Tests compile without running the sync scripts. Pass the path to a checkout when refreshing them. Use separate SwiftPM scratch paths for each baseline/final package. No build products or SwiftPM caches are included.

The cloud harness uses the complete real request engine/provider sources. The weekly harness uses exact production method bodies but stubs unrelated engine/UI/persistence dependencies. Neither replaces the required full native iOS build and app-target XCTest gate. All fixtures and keys are synthetic and URLProtocol intercepts transport.

cloud/prompt-literal-proof.json and cloud/check_ai_literals.py preserve the byte-level evidence for all original strings across 32 AI/Coach files.
