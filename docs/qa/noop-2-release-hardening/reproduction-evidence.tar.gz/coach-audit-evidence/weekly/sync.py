from pathlib import Path
import re
import sys
import shutil

repo = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/workspace/scratch/fc582a8e42a6/noop-ios')
root = Path(__file__).resolve().parent
for folder in ['Sources/NOOP', 'Sources/StrandAnalytics', 'Tests/NOOPTests']:
    (root / folder).mkdir(parents=True, exist_ok=True)
(root / 'Package.swift').write_text('''// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "WeeklyCoachOwnershipHarness", targets: [
    .target(name: "StrandAnalytics"), .target(name: "NOOP", dependencies: ["StrandAnalytics"]),
    .testTarget(name: "NOOPTests", dependencies: ["NOOP", "StrandAnalytics"])])
''')

source = (repo / 'StrandiOS/Coach/LocalCoachEngine.swift').read_text()
def method(signature):
    start = source.index('    ' + signature)
    end = source.index('\n    }', start) + len('\n    }')
    return source[start:end]

prefix = source[source.index('@MainActor\nprotocol LocalCoachDataAccess'):source.index('@MainActor\nfinal class LocalCoachEngine')]
prefix = re.sub(r'extension LocalCoachDataService: LocalCoachDataAccess \{.*?\n\}\n', '', prefix, flags=re.S)
names = ['func refreshWeeklyInsightIfNeeded(', 'func clearWeeklyInsight()',
         'private static func dayString(', 'private func reconcileSource()', 'func waitForHydration()',
         'private func preferencesChanged(', 'private func invalidateHistory()', 'private func canOperate(',
         'private func updateAvailability()']
methods = '\n\n'.join(method(name) for name in names)
instruction = next(line for line in source.splitlines() if 'private static let weeklyInsightInstructions =' in line)
shell = (root / 'EngineShell.swift.txt').read_text()
(root / 'Sources/NOOP/WeeklyEngine.swift').write_text('import Foundation\nimport StrandAnalytics\n' + prefix + shell + methods + '\n' + instruction + '\n}\n')
models = (repo / 'StrandiOS/Coach/LocalCoachModels.swift').read_text()
models = models.removeprefix('#if os(iOS)\n').removesuffix('#endif\n')
(root / 'Sources/NOOP/LocalCoachModels.swift').write_text(models + '\nstruct LocalCoachCard: Codable, Equatable, Sendable {}\n')
shutil.copy2(repo / 'Packages/StrandAnalytics/Sources/StrandAnalytics/WeeklyCoachInsightStore.swift', root / 'Sources/StrandAnalytics')
digest = (repo / 'Packages/StrandAnalytics/Sources/StrandAnalytics/WeeklyDigest.swift').read_text()
math = digest[digest.index('    public static func mondayOfWeek'):digest.index('    // MARK: - Empty digest')] + '}\n'
(root / 'Sources/StrandAnalytics/WeekMath.swift').write_text('import Foundation\npublic enum WeeklyDigestEngine {\n' + math)
test = (repo / 'StrandiOSTests/LocalCoachWeeklyInsightOwnershipTests.swift').read_text()
test = test.removeprefix('#if os(iOS)\n').removesuffix('#endif\n')
(root / 'Tests/NOOPTests/LocalCoachWeeklyInsightOwnershipTests.swift').write_text(test)
print('Copied exact weekly/source/consent production methods, cache store, date math, models and app tests. Unrelated persistence/UI are stubbed.')
