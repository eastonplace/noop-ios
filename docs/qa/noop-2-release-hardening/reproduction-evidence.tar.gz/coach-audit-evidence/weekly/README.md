# Weekly Coach insight ownership regression evidence

Base: `a7ade2598d439d33cd20816d69ccc991b29322fc`.

`sync.py` extracts these exact production LocalCoachEngine methods without rewriting their bodies: weekly generation, weekly clear, day formatting, source reconciliation, hydration wait, consent preference changes, history invalidation, operation permission, and availability update. It compiles those methods with the actual LocalCoach models, WeeklyCoachInsightStore, and the date-math portion of WeeklyDigestEngine. The shell in EngineShell.swift.txt substitutes only unrelated UIKit, ordinary conversation and disk persistence dependencies. The production app test file is copied unchanged except removing its iOS conditional envelope. Synthetic data/model dependencies suspend real production methods deterministically.

The harness does **not** compile the complete LocalCoachEngine or its SwiftUI owner. Native app-target CI remains required for that integration.

`baseline-Sources` and `baseline-Tests` preserve the old implementation and exact tests. `red.log` contains eight cases: six failed with ten expected assertions; matching-source cache reuse and an already-protected direct source switch passed. `green.log` contains the same eight cases passing after the patch.

Reproduce with `python sync.py`, then:

```
env CLANG_MODULE_CACHE_PATH=/tmp/noop-clang-cache SWIFTPM_MODULECACHE_OVERRIDE=/tmp/noop-spm-module-cache /tmp/noop-swift/usr/bin/swift test --package-path /tmp/noop-ui-weekly-harness --cache-path /tmp/noop-spm-cache --config-path /tmp/noop-spm-config --security-path /tmp/noop-spm-security --scratch-path /tmp/noop-ui-weekly-green
```

For the baseline, copy Package.swift plus baseline-Sources (renamed Sources) and baseline-Tests (renamed Tests) to an independent package directory and use a distinct scratch path.

No real model, device, network, personal health record or existing Coach persistence file is accessed. Standard UserDefaults is saved/restored only for the weekly-insight key inside each test process. Cloud and weekly Coach prompt preservation is documented in the sibling cloud harness's prompt-literal-proof.json.
