import Foundation
public enum WeeklyDigestEngine {
    public static func mondayOfWeek(containing day: String) -> String? {
        guard let (y, m, d) = parseYMD(day), let w = weekday(y, m, d) else { return nil }
        // weekday: 0=Sunday … 6=Saturday. Days since Monday: Mon=0 … Sun=6.
        let sinceMonday = (w + 6) % 7
        return addDays(day, -sinceMonday)
    }

    /// Add `n` days (may be negative) to a "yyyy-MM-dd" day, returning "yyyy-MM-dd".
    /// Falls back to the input string if it can't be parsed.
    public static func addDays(_ day: String, _ n: Int) -> String {
        guard let (y, m, d) = parseYMD(day) else { return day }
        let jdn = julianDayNumber(y, m, d) + n
        let (ny, nm, nd) = fromJulianDayNumber(jdn)
        return formatYMD(ny, nm, nd)
    }

    /// Sakamoto's day-of-week: 0=Sunday, 1=Monday … 6=Saturday. nil for an invalid
    /// calendar date.
    static func weekday(_ y: Int, _ m: Int, _ d: Int) -> Int? {
        guard (1...12).contains(m), d >= 1, d <= daysInMonth(y, m) else { return nil }
        let t = [0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4]
        var yy = y
        if m < 3 { yy -= 1 }
        return (yy + yy / 4 - yy / 100 + yy / 400 + t[m - 1] + d) % 7
    }

    /// Days in a month, leap-year aware.
    static func daysInMonth(_ y: Int, _ m: Int) -> Int {
        switch m {
        case 1, 3, 5, 7, 8, 10, 12: return 31
        case 4, 6, 9, 11:           return 30
        case 2: return isLeap(y) ? 29 : 28
        default: return 0
        }
    }

    static func isLeap(_ y: Int) -> Bool { (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0) }

    /// Parse "yyyy-MM-dd" into integer components, validating the date is real.
    /// Public so UI layers can format week-range labels without re-implementing the
    /// (timezone-free) date parse.
    public static func parseYMD(_ s: String) -> (Int, Int, Int)? {
        let parts = s.split(separator: "-", omittingEmptySubsequences: false)
        guard parts.count == 3,
              let y = Int(parts[0]), let m = Int(parts[1]), let d = Int(parts[2]),
              (1...12).contains(m), d >= 1, d <= daysInMonth(y, m) else { return nil }
        return (y, m, d)
    }

    /// Zero-padded "yyyy-MM-dd".
    static func formatYMD(_ y: Int, _ m: Int, _ d: Int) -> String {
        let yy = y < 1000 ? String(format: "%04d", y) : "\(y)"
        let mm = m < 10 ? "0\(m)" : "\(m)"
        let dd = d < 10 ? "0\(d)" : "\(d)"
        return "\(yy)-\(mm)-\(dd)"
    }

    /// Convert a proleptic-Gregorian date to a Julian Day Number (integer-only,
    /// timezone-free). Used purely for date arithmetic.
    static func julianDayNumber(_ y: Int, _ m: Int, _ d: Int) -> Int {
        let a = (14 - m) / 12
        let yy = y + 4800 - a
        let mm = m + 12 * a - 3
        return d + (153 * mm + 2) / 5 + 365 * yy + yy / 4 - yy / 100 + yy / 400 - 32045
    }

    /// Inverse of `julianDayNumber`.
    static func fromJulianDayNumber(_ jdn: Int) -> (Int, Int, Int) {
        let a = jdn + 32044
        let b = (4 * a + 3) / 146097
        let c = a - (146097 * b) / 4
        let dd = (4 * c + 3) / 1461
        let e = c - (1461 * dd) / 4
        let mm = (5 * e + 2) / 153
        let day = e - (153 * mm + 2) / 5 + 1
        let month = mm + 3 - 12 * (mm / 10)
        let year = 100 * b + dd - 4800 + mm / 10
        return (year, month, day)
    }

}
