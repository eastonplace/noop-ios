// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "WeeklyCoachOwnershipHarness", targets: [
    .target(name: "StrandAnalytics"), .target(name: "NOOP", dependencies: ["StrandAnalytics"]),
    .testTarget(name: "NOOPTests", dependencies: ["NOOP", "StrandAnalytics"])])
