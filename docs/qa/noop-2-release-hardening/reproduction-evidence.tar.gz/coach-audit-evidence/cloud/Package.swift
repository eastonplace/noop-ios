// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "CoachOwnershipHarness", products: [.library(name: "NOOP", targets: ["NOOP"])],
    targets: [.target(name: "NOOP"), .testTarget(name: "NOOPTests", dependencies: ["NOOP"])])
