import Foundation

@propertyWrapper struct Published<Value> {
    var wrappedValue: Value
    init(wrappedValue: Value) { self.wrappedValue = wrappedValue }
}
protocol ObservableObject {}
struct StubPublisher {
    func send() {}
    func receive(on queue: DispatchQueue) -> Self { self }
    func sink(_ receive: (()) -> Void) -> AnyCancellable { AnyCancellable() }
}
extension ObservableObject { var objectWillChange: StubPublisher { StubPublisher() } }
final class AnyCancellable {}

@MainActor final class Repository: ObservableObject {
    var deviceId: String
    var verifiedExternalSurfaceFenced = false {
        didSet { if verifiedExternalSurfaceFenced && !oldValue { externalSurfaceInvalidationEpoch &+= 1 } }
    }
    var externalSurfaceInvalidationEpoch: UInt64 = 0
    var notificationSourceContext: String { "synthetic:\(deviceId)" }
    var canonicalDays: [DailyMetric] = []
    init(deviceId: String) { self.deviceId = deviceId }
    func storeHandle() async -> StubStore? { nil }
    func journalEntries() async -> [StubJournalEntry] { [] }
    func workoutRows(days: Int) async -> [StubWorkout] { [] }
}
struct DailyMetric: Sendable {
    var day: String
    var totalSleepMin: Double? = nil
    var efficiency: Double? = nil
    var deepMin: Double? = nil
    var remMin: Double? = nil
    var lightMin: Double? = nil
    var restingHr: Int? = nil
    var avgHrv: Double? = nil
    var recovery: Double? = nil
    var strain: Double? = nil
    var spo2Pct: Double? = nil
    var respRateBpm: Double? = nil
    var skinTempDevC: Double? = nil
    var steps: Int? = nil
    var activeKcalEst: Double? = nil
}
actor StubStore {
    func rrIntervals(deviceId: String, from: Int, to: Int, limit: Int) throws -> [Double] { [] }
    func labMarkers(deviceId: String, category: String) throws -> [StubMarker] { [] }
}
struct StubMarker: Sendable {
    var markerKey = ""
    var takenAt = 0
    var value: Double? = nil
    var unit = ""
    var valueText: String? = nil
}
struct StubJournalEntry { var answeredYes = false; var question = ""; var day = "" }
struct StubWorkout {
    var startTs = 0
    var sport = ""
    var durationS: Double? = nil
    var avgHr: Int? = nil
    var energyKcal: Double? = nil
    var distanceM: Double? = nil
}
enum StressIndex { static func stressIndex(rr: [Double]) -> Double? { nil } }
enum EffectRanker {
    struct Effect { var significant = false }
    struct Row { var effect = Effect(); func sentence() -> String { "" } }
    static func rank(behaviors: [String: Set<String>], controls: [String: Set<String>], outcomeByDay: [String: Double], outcome: String) -> [Row] { [] }
}
enum LabMarkerCategory: String, CaseIterable { case synthetic }
enum MarkerCatalog {
    struct Definition { var displayName = "" }
    static func definition(for key: String) -> Definition? { nil }
}
enum LabBookFormat { static func value(_ value: Double, key: String) -> String { "" } }
enum StrainResolver {
    struct Value { var storedValue: Double = 0 }
    static func canonicalWorkout(_ workout: StubWorkout) -> Value? { nil }
}
