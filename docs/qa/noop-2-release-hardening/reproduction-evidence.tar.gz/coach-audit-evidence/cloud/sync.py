from pathlib import Path
import re
import sys

repo = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/workspace/scratch/fc582a8e42a6/noop-ios')
root = Path(__file__).resolve().parent
paths = [repo / 'Strand/AI/AICoach.swift', repo / 'Strand/AI/AIProvider.swift', *sorted((repo / 'Strand/AI/Providers').glob('*.swift'))]
for path in paths:
    text = path.read_text()
    text = re.sub(r'^import (Combine|Security|WhoopStore|StrandAnalytics|StrandImport)\n', '', text, flags=re.M)
    text = text.replace('import Foundation\n', 'import Foundation\nimport FoundationNetworking\n', 1)
    if path.name == 'AICoach.swift':
        first = text.index('enum AIKeyStore {')
        last = text.index('/// Credential operations', first)
        text = text[:first] + '''enum AIKeyStore {
    static var ownerProvider: String? { nil }
    static func read() -> String? { nil }
    static func save(_ key: String, owner: String) -> Bool { false }
    static func clear() {}
}

''' + text[last:]
    (root / 'Sources/NOOP' / path.name).write_text(text)
test = (repo / 'StrandiOSTests/AICoachRequestOwnershipTests.swift').read_text()
test = test.replace('import Foundation\n', 'import Foundation\nimport FoundationNetworking\n', 1)
(root / 'Tests/NOOPTests/AICoachRequestOwnershipTests.swift').write_text(test)
for name in ['AICoachRefreshModelsRaceTests.swift', 'AIProviderModelListTests.swift']:
    text = (repo / 'StrandiOSTests' / name).read_text()
    (root / 'Tests/NOOPTests' / name).write_text(text)
print('Copied engine, provider and ownership tests; only unavailable platform/domain dependencies are stubbed.')
