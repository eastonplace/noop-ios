# Cloud Coach ownership regression evidence

Base: `a7ade2598d439d33cd20816d69ccc991b29322fc`.

This Linux Swift 6 harness compiles the repository's complete AICoachEngine, AIProvider and four provider clients. `sync.py` copies their source and the actual app-target tests. It removes only unavailable module imports, replaces Keychain with an inert implementation, and supplies minimal platform/domain stubs. Tests inject synthetic credentials and a suspended context reader, so the stub repository's health-reading functions are not exercised. The real URLSession/provider request builders run against an in-process URLProtocol; no external request, credential, model or health data is used.

`baseline-Sources` and `baseline-Tests` preserve the original pre-fix implementation with only the credential/context test seams and its 26-case suite. `red-all.log` ran 16 ownership cases plus 10 existing provider/model race cases against that source: 15 of the new cases failed, yielding 21 expected assertions, while the happy path and 10 pre-existing cases passed.

Independent review found a later compatibility-retry admission gap after the first fix. `retry-baseline-Sources` and `retry-baseline-Tests` preserve that intermediate source and the expanded test suite. `retry-red.log` runs four new cases: source retirement during HTTP causes two requests instead of one for both Custom and OpenAI (two expected failures), while both stable-source retries pass. The shared transport now rechecks task-scoped engine ownership and cancellation before every HTTP attempt. `green-all.log` is the final **30-case** run: 20 ownership cases plus 10 existing cases, zero failures.

`red.log` is the first nine-case baseline run. `green.log` is the 16-case ownership-only verification. The URLProtocol helper was corrected to honor stopLoading before the final all-tests red/green comparison; final tests are the same on both sides.

## Reproduce

The packaged Sources/Tests are ready to compile without running sync. Run `python sync.py /absolute/path/to/noop-ios` to refresh from another checkout; the audit checkout is the default. Swift is `/tmp/noop-swift/usr/bin/swift` in the audit environment. Use an independent scratch directory and run outside the restrictive socket sandbox (SwiftPM's local discovery otherwise hangs):

```
env CLANG_MODULE_CACHE_PATH=/tmp/noop-clang-cache SWIFTPM_MODULECACHE_OVERRIDE=/tmp/noop-spm-module-cache /tmp/noop-swift/usr/bin/swift test --package-path /tmp/noop-ui-coach-harness --cache-path /tmp/noop-spm-cache --config-path /tmp/noop-spm-config --security-path /tmp/noop-spm-security --scratch-path /tmp/noop-ui-coach-green
```

For original-baseline reproduction, copy Package.swift, baseline-Sources (renamed Sources), and baseline-Tests (renamed Tests) to a separate package directory, then use the same command with separate package/scratch paths. For the retry baseline, use retry-baseline-Sources and retry-baseline-Tests instead and add `--filter 'AICoachRequestOwnershipTests.*(RetirementDuring|StillRetries)'`. The original baseline package is also available at `/tmp/noop-ui-coach-baseline` during the audit session. Adjust `--package-path` in the command for the packaged evidence location.

`check_ai_literals.py` lexes Swift string tokens, including raw strings, multiline strings, nested interpolation and comments, then compares every original token with the base commit. `prompt-literal-proof.json` proves that every original literal in all 32 cloud/on-device Coach source files remains byte-for-byte unchanged. Only Custom.swift gained two endpoint path literals. This preserves prompts, instructions, context templates, response copy and provider payload string keys.

This harness is evidence for request semantics, not a substitute for the native app build, SwiftUI behavior, Keychain integration or Instruments profiling. Native app-target XCTest suites must still run in macOS/iOS CI.
