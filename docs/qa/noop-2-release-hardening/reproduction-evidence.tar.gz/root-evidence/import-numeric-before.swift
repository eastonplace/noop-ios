import Foundation
import FoundationXML
import Foundation

// MARK: - Source provenance

/// Where a normalized row originated. Mirrors the `dataSource.kind` provenance
/// described in the Strand design spec (§5).
public enum DataSourceKind: String, Sendable, Codable, Equatable, CaseIterable {
    case appleHealth
    case whoopExport
    /// Xiaomi Smart Band (Mi Band) — imported from the Mi Fitness iOS app's
    /// on-device SQLite store (`DataBase/<user_id>/de/<user_id>.db`). Account-free,
    /// fully offline: NOOP reads the file the user already owns.
    case xiaomiBand
    /// Oura Ring — the user's own Account data export (JSON), imported from the file
    /// Oura hands them. Sleep periods + daily readiness/activity → daily metrics + sleep
    /// sessions. Fully offline, no Oura cloud/API.
    case ouraImport
    /// Fitbit — the user's own Google Takeout → Fitbit JSON export (per-day sleep /
    /// resting_heart_rate / steps / heart_rate files). Fully offline, no Fitbit/Google API.
    case fitbitImport
    /// Garmin — the user's own Garmin Connect "Export Your Data" (GDPR) wellness JSON/CSV
    /// (sleep / resting HR / stress / steps). The FIT activity files inside the same ZIP are
    /// handled by the wave-1 FIT parser; this path does the WELLNESS daily + sleep only.
    case garminImport
}

// MARK: - Generic health sample (Apple Health Record sink)

/// A single normalized Apple Health `<Record>` reading.
///
/// Timestamps are normalized to UTC `Date`s while the original UTC offset (in
/// minutes) is preserved in `tzOffsetMin`, matching the `hkSample` table shape
/// in the design spec (§5).
public struct HealthSample: Sendable, Equatable, Hashable {
    /// HealthKit type identifier, stripped of the `HKQuantityTypeIdentifier` /
    /// `HKCategoryTypeIdentifier` prefix (e.g. `HeartRate`, `SleepAnalysis`).
    public var type: String
    /// Numeric value, when the record is quantitative. `nil` for pure category
    /// records whose meaning lives in `valueString`.
    public var value: Double?
    /// Raw string value as it appeared in the export (category enum strings,
    /// or the textual numeric value). Always populated when present.
    public var valueString: String?
    /// Unit string from the record (e.g. `count/min`, `%`, `degC`). May be nil.
    public var unit: String?
    /// Start of the sample, normalized to UTC.
    public var start: Date
    /// End of the sample, normalized to UTC.
    public var end: Date
    /// Original UTC offset of the source timestamp, in minutes (e.g. `60` for
    /// `+0100`, `-300` for `-0500`).
    public var tzOffsetMin: Int
    /// `sourceName` attribute (the device/app that produced the record).
    public var sourceName: String?

    public init(
        type: String,
        value: Double?,
        valueString: String?,
        unit: String?,
        start: Date,
        end: Date,
        tzOffsetMin: Int,
        sourceName: String?
    ) {
        self.type = type
        self.value = value
        self.valueString = valueString
        self.unit = unit
        self.start = start
        self.end = end
        self.tzOffsetMin = tzOffsetMin
        self.sourceName = sourceName
    }

    /// Dedupe key per the spec: `type+startDate+endDate+sourceName+value`.
    /// Records nested in a `<Correlation>` also appear at top level; collapsing
    /// on this key removes the duplicates.
    public var dedupeKey: String {
        let v = valueString ?? value.map { String($0) } ?? ""
        return "\(type)|\(start.timeIntervalSince1970)|\(end.timeIntervalSince1970)|\(sourceName ?? "")|\(v)"
    }
}

// MARK: - Apple Health workout

/// A normalized Apple Health `<Workout>` element.
public struct HealthWorkout: Sendable, Equatable {
    /// `workoutActivityType`, stripped of the `HKWorkoutActivityType` prefix
    /// (e.g. `Running`, `FunctionalStrengthTraining`).
    public var activityType: String
    /// Total duration in seconds (from the `duration`/`durationUnit` attrs).
    public var durationS: Double?
    /// Total distance in metres, when present.
    public var distanceM: Double?
    /// Total active energy burned in kilocalories, when present.
    public var energyKcal: Double?
    /// Average heart rate over the workout, when present (iOS 16+ `<WorkoutStatistics>` only).
    public var avgHr: Double?
    /// Peak heart rate over the workout, when present (iOS 16+ `<WorkoutStatistics>` only).
    public var maxHr: Double?
    public var start: Date
    public var end: Date
    public var tzOffsetMin: Int
    public var sourceName: String?

    public init(
        activityType: String,
        durationS: Double?,
        distanceM: Double?,
        energyKcal: Double?,
        avgHr: Double? = nil,
        maxHr: Double? = nil,
        start: Date,
        end: Date,
        tzOffsetMin: Int,
        sourceName: String?
    ) {
        self.activityType = activityType
        self.durationS = durationS
        self.distanceM = distanceM
        self.energyKcal = energyKcal
        self.avgHr = avgHr
        self.maxHr = maxHr
        self.start = start
        self.end = end
        self.tzOffsetMin = tzOffsetMin
        self.sourceName = sourceName
    }
}

// MARK: - Sleep stage interval

/// The canonical sleep stages Strand recognises from Apple Health
/// `HKCategoryValueSleepAnalysis*` values.
public enum SleepStage: String, Sendable, Equatable, CaseIterable {
    case inBed
    case asleepUnspecified   // legacy "Asleep"
    case asleepCore
    case asleepDeep
    case asleepREM
    case awake
    case unknown

    /// Map a raw HealthKit `SleepAnalysis` category value string to a stage.
    /// Accepts both the modern `HKCategoryValueSleepAnalysis…` form and the
    /// legacy numeric/short forms.
    public static func from(rawValue raw: String) -> SleepStage {
        switch raw {
        case "HKCategoryValueSleepAnalysisInBed", "InBed", "0":
            return .inBed
        case "HKCategoryValueSleepAnalysisAsleep", "HKCategoryValueSleepAnalysisAsleepUnspecified", "Asleep", "1":
            return .asleepUnspecified
        case "HKCategoryValueSleepAnalysisAsleepCore", "AsleepCore", "3":
            return .asleepCore
        case "HKCategoryValueSleepAnalysisAsleepDeep", "AsleepDeep", "4":
            return .asleepDeep
        case "HKCategoryValueSleepAnalysisAsleepREM", "AsleepREM", "5":
            return .asleepREM
        case "HKCategoryValueSleepAnalysisAwake", "Awake", "2":
            return .awake
        default:
            return .unknown
        }
    }
}

/// A single contiguous sleep-stage interval from Apple Health.
public struct SleepStageInterval: Sendable, Equatable, Hashable {
    public var stage: SleepStage
    public var start: Date
    public var end: Date
    public var tzOffsetMin: Int
    public var sourceName: String?
    /// HealthKit's source bundle and object UUID when available. XML keeps its recorded source name.
    public var sourceIdentifier: String?
    public var sampleID: String?

    public init(
        stage: SleepStage,
        start: Date,
        end: Date,
        tzOffsetMin: Int,
        sourceName: String?,
        sourceIdentifier: String? = nil,
        sampleID: String? = nil
    ) {
        self.stage = stage
        self.start = start
        self.end = end
        self.tzOffsetMin = tzOffsetMin
        self.sourceName = sourceName
        self.sourceIdentifier = sourceIdentifier
        self.sampleID = sampleID
    }
}

// MARK: - Whoop daily cycle (physiological_cycles.csv)

/// One row of `physiological_cycles.csv` — Whoop's master daily summary.
///
/// All durations are stored in **minutes** as they appear in the CSV. Energy is
/// stored in **kcal** (Whoop's CSV `(cal)` is actually kcal). Timestamps are the
/// raw `YYYY-MM-DD HH:MM:SS` strings parsed against `cycleTimezone` into UTC
/// `Date`s, with the offset preserved in `tzOffsetMin`.
public struct WhoopCycleRow: Sendable, Equatable {
    /// Cycle start (UTC). The primary key for a Whoop day.
    public var cycleStart: Date?
    public var cycleEnd: Date?
    /// Original `Cycle timezone` offset in minutes (e.g. `+01:00` → 60).
    public var tzOffsetMin: Int

    public var recoveryScore: Double?
    public var restingHeartRate: Double?
    public var hrvMs: Double?
    public var skinTempCelsius: Double?
    public var bloodOxygenPct: Double?
    public var dayStrain: Double?
    public var energyKcal: Double?
    public var avgHeartRate: Double?
    public var maxHeartRate: Double?

    public var sleepOnset: Date?
    public var wakeOnset: Date?
    public var sleepPerformancePct: Double?
    public var respiratoryRate: Double?
    public var asleepDurationMin: Double?
    public var inBedDurationMin: Double?
    public var lightSleepDurationMin: Double?
    public var deepSleepDurationMin: Double?
    public var remDurationMin: Double?
    public var awakeDurationMin: Double?
    public var sleepEfficiencyPct: Double?
    public var sleepConsistencyPct: Double?
    public var sleepNeedMin: Double?
    public var sleepDebtMin: Double?

    public init() {
        self.cycleStart = nil
        self.cycleEnd = nil
        self.tzOffsetMin = 0
    }
}

// MARK: - Whoop sleep (sleeps.csv)

/// One row of `sleeps.csv` — per sleep or nap. Adds the `Nap` boolean over the
/// daily cycle summary.
public struct WhoopSleepRow: Sendable, Equatable {
    public var cycleStart: Date?
    public var sleepOnset: Date?
    public var wakeOnset: Date?
    public var tzOffsetMin: Int
    public var isNap: Bool

    public var sleepPerformancePct: Double?
    public var respiratoryRate: Double?
    public var asleepDurationMin: Double?
    public var inBedDurationMin: Double?
    public var lightSleepDurationMin: Double?
    public var deepSleepDurationMin: Double?
    public var remDurationMin: Double?
    public var awakeDurationMin: Double?
    public var sleepEfficiencyPct: Double?
    public var sleepConsistencyPct: Double?
    public var sleepNeedMin: Double?
    public var sleepDebtMin: Double?

    public init() {
        self.cycleStart = nil
        self.sleepOnset = nil
        self.wakeOnset = nil
        self.tzOffsetMin = 0
        self.isNap = false
    }
}

// MARK: - Whoop workout (workouts.csv)

/// One row of `workouts.csv`. GPS / distance / altitude columns are optional.
public struct WhoopWorkoutRow: Sendable, Equatable {
    public var cycleStart: Date?
    public var workoutStart: Date?
    public var workoutEnd: Date?
    public var tzOffsetMin: Int

    public var activityName: String?
    public var activityStrain: Double?
    public var energyKcal: Double?
    public var avgHeartRate: Double?
    public var maxHeartRate: Double?

    public var hrZone1Pct: Double?
    public var hrZone2Pct: Double?
    public var hrZone3Pct: Double?
    public var hrZone4Pct: Double?
    public var hrZone5Pct: Double?

    // Optional GPS / distance / altitude columns (may be absent entirely).
    public var distanceMeters: Double?
    public var altitudeGainMeters: Double?
    public var altitudeChangeMeters: Double?

    public init() {
        self.cycleStart = nil
        self.workoutStart = nil
        self.workoutEnd = nil
        self.tzOffsetMin = 0
    }
}

// MARK: - Whoop journal (journal_entries.csv)

/// One row of `journal_entries.csv` — tall format: a question and its answer
/// (with optional notes) per cycle.
public struct WhoopJournalRow: Sendable, Equatable {
    public var cycleStart: Date?
    public var tzOffsetMin: Int
    public var question: String?
    public var answer: String?
    public var notes: String?

    public init() {
        self.cycleStart = nil
        self.tzOffsetMin = 0
    }
}

// MARK: - Xiaomi Smart Band (Mi Fitness export)

/// The canonical sleep stages NOOP recognises from the Mi Fitness `sleep` table's
/// per-segment `state` codes. Verified against a real Mi Band 10 export:
/// `1 = awake, 2 = light, 3 = deep, 4 = REM, 5 = awake-in-bed`.
public enum XiaomiSleepStage: String, Sendable, Equatable, CaseIterable {
    case awake
    case light
    case deep
    case rem
    case awakeInBed
    case unknown

    public static func from(state: Int) -> XiaomiSleepStage {
        switch state {
        case 1: return .awake
        case 2: return .light
        case 3: return .deep
        case 4: return .rem
        case 5: return .awakeInBed
        default: return .unknown
        }
    }
}

/// One contiguous sleep-stage interval (`items[]` entry) from a Mi Fitness `sleep` row.
public struct XiaomiSleepStageInterval: Sendable, Equatable {
    public var stage: XiaomiSleepStage
    public var start: Date
    public var end: Date

    public init(stage: XiaomiSleepStage, start: Date, end: Date) {
        self.stage = stage
        self.start = start
        self.end = end
    }
}

/// One sleep session reconstructed from a Mi Fitness `sleep` interval row, including
/// its full hypnogram (`stages`). Durations are minutes, as the band reports them.
public struct XiaomiSleepSession: Sendable, Equatable {
    public var bedtime: Date
    public var wakeTime: Date
    public var deepMin: Double?
    public var lightMin: Double?
    public var remMin: Double?
    public var awakeMin: Double?
    public var avgHr: Int?
    public var minHr: Int?
    public var maxHr: Int?
    public var awakeCount: Int?
    public var sleepScore: Int?
    public var stages: [XiaomiSleepStageInterval]

    public init(
        bedtime: Date,
        wakeTime: Date,
        deepMin: Double? = nil,
        lightMin: Double? = nil,
        remMin: Double? = nil,
        awakeMin: Double? = nil,
        avgHr: Int? = nil,
        minHr: Int? = nil,
        maxHr: Int? = nil,
        awakeCount: Int? = nil,
        sleepScore: Int? = nil,
        stages: [XiaomiSleepStageInterval] = []
    ) {
        self.bedtime = bedtime
        self.wakeTime = wakeTime
        self.deepMin = deepMin
        self.lightMin = lightMin
        self.remMin = remMin
        self.awakeMin = awakeMin
        self.avgHr = avgHr
        self.minHr = minHr
        self.maxHr = maxHr
        self.awakeCount = awakeCount
        self.sleepScore = sleepScore
        self.stages = stages
    }
}

/// One calendar day rolled up from the Mi Fitness `*_day` tables. `day` is the
/// band's local calendar day (`YYYY-MM-DD`, derived from the row's `zone_offset`).
/// All metric fields are optional — a given day only carries what the band recorded.
public struct XiaomiDailyRow: Sendable, Equatable {
    public var day: String
    public var dayStart: Date

    // Activity (steps_day / calories_day / intensity_day / valid_stand_day)
    public var steps: Int?
    public var distanceM: Double?
    public var activeKcal: Double?
    public var intensityMin: Double?
    public var standCount: Int?

    // Heart rate (heart_rate_day)
    public var restingHr: Int?
    public var avgHr: Int?
    public var minHr: Int?
    public var maxHr: Int?

    // Sleep rollup (sleep_day)
    public var totalSleepMin: Double?
    public var deepMin: Double?
    public var lightMin: Double?
    public var remMin: Double?
    public var awakeMin: Double?
    public var sleepScore: Int?

    // Wellbeing (stress_day / spo2_day / vitality)
    public var avgStress: Int?
    public var avgSpo2: Double?
    public var vitality: Int?

    public init(day: String, dayStart: Date) {
        self.day = day
        self.dayStart = dayStart
    }
}

/// Normalized output of parsing a Mi Fitness export (the iOS app sandbox folder,
/// a zip of it, or the bare `<user_id>.db`).
public struct XiaomiImportResult: Sendable, Equatable {
    public var days: [XiaomiDailyRow]
    public var sleeps: [XiaomiSleepSession]
    public var summary: ImportSummary

    public init(days: [XiaomiDailyRow], sleeps: [XiaomiSleepSession], summary: ImportSummary) {
        self.days = days
        self.sleeps = sleeps
        self.summary = summary
    }
}

// MARK: - Wearable file-export import (Oura / Fitbit / Garmin own-data exports)

/// Which third-party wearable an export came from. Used to pick the right parser and to
/// tag every imported row with an honest per-source label (`oura-import` / `fitbit-import` /
/// `garmin-import`), so the UI never confuses Oura/Fitbit/Garmin data with WHOOP's.
public enum WearableBrand: String, Sendable, Equatable, CaseIterable {
    case oura
    case fitbit
    case garmin

    /// The per-source partition / provenance id written as the Data Source device id (mirrors
    /// `"my-whoop"` / `"apple-health"` / `"xiaomi-band"`). Honest: imported, not live.
    public var sourceId: String {
        switch self {
        case .oura:   return "oura-import"
        case .fitbit: return "fitbit-import"
        case .garmin: return "garmin-import"
        }
    }

    /// Human label for the import summary / Data Source card.
    public var displayName: String {
        switch self {
        case .oura:   return "Oura"
        case .fitbit: return "Fitbit"
        case .garmin: return "Garmin"
        }
    }

    public var dataSourceKind: DataSourceKind {
        switch self {
        case .oura:   return .ouraImport
        case .fitbit: return .fitbitImport
        case .garmin: return .garminImport
        }
    }
}

/// One contiguous sleep-stage interval reconstructed from a wearable export's hypnogram, when
/// the export carried per-segment staging (Fitbit `levels.data`, Garmin `sleepLevels`). Oura's
/// account export gives stage DURATIONS but not a per-segment timeline, so its sessions carry the
/// duration breakdown without a stage list — honest: we never synthesize a fake hypnogram.
public struct WearableSleepStageInterval: Sendable, Equatable {
    /// Normalized stage name written into the stage JSON: "deep" / "light" / "rem" / "wake".
    public var stage: String
    public var start: Date
    public var end: Date

    public init(stage: String, start: Date, end: Date) {
        self.stage = stage
        self.start = start
        self.end = end
    }
}

/// One sleep session imported from a wearable export. Durations are MINUTES (as NOOP's
/// `DailyMetric` / sleep model use). A field is nil when the export didn't carry it — never
/// fabricated. `stages` is empty when the export gave only a duration breakdown (Oura).
public struct WearableSleepSession: Sendable, Equatable {
    public var start: Date          // bedtime / sleep onset (UTC)
    public var end: Date            // wake (UTC)
    public var deepMin: Double?
    public var lightMin: Double?
    public var remMin: Double?
    public var awakeMin: Double?
    public var totalSleepMin: Double?
    public var efficiencyPct: Double?
    public var avgHr: Int?
    public var lowestHr: Int?       // Oura/Garmin lowest sleeping HR ≈ resting
    public var avgHrvMs: Double?    // Oura "average_hrv" (rMSSD ms); others nil
    public var respRateBpm: Double? // Oura "average_breath"; others nil
    public var sleepScore: Int?     // the brand's OWN score — stored as reference only, never Charge
    public var stages: [WearableSleepStageInterval]

    public init(
        start: Date,
        end: Date,
        deepMin: Double? = nil,
        lightMin: Double? = nil,
        remMin: Double? = nil,
        awakeMin: Double? = nil,
        totalSleepMin: Double? = nil,
        efficiencyPct: Double? = nil,
        avgHr: Int? = nil,
        lowestHr: Int? = nil,
        avgHrvMs: Double? = nil,
        respRateBpm: Double? = nil,
        sleepScore: Int? = nil,
        stages: [WearableSleepStageInterval] = []
    ) {
        self.start = start
        self.end = end
        self.deepMin = deepMin
        self.lightMin = lightMin
        self.remMin = remMin
        self.awakeMin = awakeMin
        self.totalSleepMin = totalSleepMin
        self.efficiencyPct = efficiencyPct
        self.avgHr = avgHr
        self.lowestHr = lowestHr
        self.avgHrvMs = avgHrvMs
        self.respRateBpm = respRateBpm
        self.sleepScore = sleepScore
        self.stages = stages
    }
}

/// One calendar day rolled up from a wearable export. `day` is the export's own calendar day
/// string (`YYYY-MM-DD`). Every metric is optional — a day only carries what the export recorded.
///
/// HONEST DATA: `readinessScore` (Oura) is THEIR score, kept for reference only — it is NEVER shown
/// as NOOP's Charge. NOOP recomputes its own scores downstream from the raw inputs (RHR / HRV /
/// sleep) that are present, exactly as it does for any imported source.
public struct WearableDailyRow: Sendable, Equatable {
    public var day: String

    // Activity
    public var steps: Int?
    public var distanceM: Double?
    public var activeKcal: Double?
    public var totalKcal: Double?

    // Heart / recovery inputs
    public var restingHr: Int?
    public var avgHrvMs: Double?
    public var respRateBpm: Double?   // night respiration (breaths/min) folded from the session, so it reaches the day rollup (#17)
    public var skinTempDevC: Double?  // Oura "temperature_deviation" (°C from baseline)
    public var spo2Pct: Double?
    public var avgStress: Int?        // Garmin daily average stress (0..100), reference
    public var vo2max: Double?        // Oura "vo2_max" (mL/kg/min); feeds Fitness Age, same as Apple Health VO2max

    // Sleep rollup (mirrors the night's session, for the daily metric)
    public var totalSleepMin: Double?
    public var deepMin: Double?
    public var lightMin: Double?
    public var remMin: Double?
    public var awakeMin: Double?
    public var efficiencyPct: Double?

    // The brand's OWN reference scores — stored under reference keys, never NOOP Charge/Effort/Rest.
    public var readinessScore: Int?   // Oura daily readiness (reference)
    public var sleepScore: Int?       // brand sleep score (reference)

    public init(day: String) {
        self.day = day
    }
}

/// Normalized output of parsing a wearable export (Oura / Fitbit / Garmin own-data export).
public struct WearableImportResult: Sendable, Equatable {
    public var brand: WearableBrand
    public var days: [WearableDailyRow]
    public var sleeps: [WearableSleepSession]
    public var summary: ImportSummary

    public init(brand: WearableBrand, days: [WearableDailyRow], sleeps: [WearableSleepSession], summary: ImportSummary) {
        self.brand = brand
        self.days = days
        self.sleeps = sleeps
        self.summary = summary
    }
}

// MARK: - Import results & summary

/// Lightweight summary of an import: how many normalized rows were produced and
/// the overall date span they cover.
public struct ImportSummary: Sendable, Equatable {
    public var sourceKind: DataSourceKind
    public var recordCount: Int
    public var earliest: Date?
    public var latest: Date?
    /// Per-category counts (e.g. `["HeartRate": 1200, "SleepAnalysis": 88]` for
    /// Apple Health, or `["cycles": 30, "workouts": 12]` for Whoop).
    public var countsByCategory: [String: Int]
    /// Number of XML spans dropped during a tolerant import: either a single
    /// hard parse error after which we kept the partial result (counts as 1), or
    /// the number of illegal-byte runs the pre-parse sanitizer scrubbed. Surfaced
    /// honestly in the UI so a partial import never silently looks complete.
    /// `0` for a fully clean import. Defaulted so other sources (Whoop) and older
    /// call sites stay source-compatible.
    public var skippedSpans: Int

    public init(
        sourceKind: DataSourceKind,
        recordCount: Int,
        earliest: Date?,
        latest: Date?,
        countsByCategory: [String: Int],
        skippedSpans: Int = 0
    ) {
        self.sourceKind = sourceKind
        self.recordCount = recordCount
        self.earliest = earliest
        self.latest = latest
        self.countsByCategory = countsByCategory
        self.skippedSpans = skippedSpans
    }
}

/// Normalized output of parsing an Apple Health export.
public struct AppleHealthImportResult: Sendable, Equatable {
    public var samples: [HealthSample]
    public var workouts: [HealthWorkout]
    public var sleepIntervals: [SleepStageInterval]
    public var summary: ImportSummary
    /// Pre-aggregated per-day sample rows, folded incrementally by the importer
    /// so a multi-year export never has to retain the raw `samples` array in RAM
    /// (issue #355). When the importer kept raw samples (`retainRawSamples:true`,
    /// the default) this is empty and `AppleHealthAggregator.aggregate` re-folds
    /// `samples`; when it dropped them (the app path) this carries the folded
    /// result and `samples` is empty. Defaulted to `[]` for source-compatibility
    /// with existing call sites that build a result from raw `samples`.
    public var sampleDailies: [AppleDailyAggregate]

    public init(
        samples: [HealthSample],
        workouts: [HealthWorkout],
        sleepIntervals: [SleepStageInterval],
        summary: ImportSummary,
        sampleDailies: [AppleDailyAggregate] = []
    ) {
        self.samples = samples
        self.workouts = workouts
        self.sleepIntervals = sleepIntervals
        self.summary = summary
        self.sampleDailies = sampleDailies
    }
}

/// Normalized output of parsing a Whoop CSV export bundle.
public struct WhoopImportResult: Sendable, Equatable {
    public var cycles: [WhoopCycleRow]
    public var sleeps: [WhoopSleepRow]
    public var workouts: [WhoopWorkoutRow]
    public var journal: [WhoopJournalRow]
    public var summary: ImportSummary

    public init(
        cycles: [WhoopCycleRow],
        sleeps: [WhoopSleepRow],
        workouts: [WhoopWorkoutRow],
        journal: [WhoopJournalRow],
        summary: ImportSummary
    ) {
        self.cycles = cycles
        self.sleeps = sleeps
        self.workouts = workouts
        self.journal = journal
        self.summary = summary
    }
}

// MARK: - Errors

public enum ImportError: Error, Equatable, Sendable, CustomStringConvertible, LocalizedError {
    case fileNotFound(String)
    case notAZipOrFolder(String)
    case missingEntry(String)
    case xmlParseFailed(String)
    case emptyExport(String)

    public var description: String {
        switch self {
        case .fileNotFound(let p):    return "File not found: \(p)"
        case .notAZipOrFolder(let p): return "Expected a folder or .zip: \(p)"
        case .missingEntry(let e):    return "Required entry not found: \(e)"
        case .xmlParseFailed(let m):  return "XML parse failed: \(m)"
        case .emptyExport(let m):     return "Export contained no usable data: \(m)"
        }
    }

    /// Honest, human-readable failure text surfaced in the import UI. Without this the enum bridges to
    /// NSError positionally and the user sees an opaque "…ImportError erreur 4" with no clue what went
    /// wrong (#857). `LocalizedError.errorDescription` is what `Error.localizedDescription` returns, so
    /// the Data Sources screen now shows the same plain sentence `description` carries.
    public var errorDescription: String? { description }
}

import Foundation

// MARK: - Daily aggregate model

/// One day's worth of Apple Health metrics, bucketed by the sample's own local
/// day (`start` shifted by `tzOffsetMin`). Mirrors the per-day shape the app
/// stores and charts alongside Whoop.
///
/// All `*Min` fields are minutes; energies are kcal; heart rates are count/min;
/// `spo2Pct` is a 0–100 percentage; `vo2max` is mL/kg/min.
public struct AppleDailyAggregate: Equatable, Sendable {
    /// `yyyy-MM-dd` in the sample's own UTC offset (local civil day).
    public let day: String

    // Cardio / respiratory means
    public let restingHr: Double?
    public let hrvSDNN: Double?
    public let spo2Pct: Double?
    public let respRate: Double?

    // Heart-rate stream
    public let avgHr: Double?
    public let maxHr: Double?
    public let walkingHr: Double?

    // Activity / fitness
    public let steps: Double?
    public let activeKcal: Double?
    public let basalKcal: Double?
    public let vo2max: Double?

    // Body composition (daily latest)
    public let weightKg: Double?
    public let bodyFatPct: Double?
    public let leanMassKg: Double?
    public let bmi: Double?

    // Sleep (minutes per stage), keyed by the wake day
    public let asleepMin: Double?
    public let deepMin: Double?
    public let remMin: Double?
    public let coreMin: Double?
    public let awakeMin: Double?
    public let inBedMin: Double?

    public init(
        day: String,
        restingHr: Double? = nil,
        hrvSDNN: Double? = nil,
        spo2Pct: Double? = nil,
        respRate: Double? = nil,
        avgHr: Double? = nil,
        maxHr: Double? = nil,
        walkingHr: Double? = nil,
        steps: Double? = nil,
        activeKcal: Double? = nil,
        basalKcal: Double? = nil,
        vo2max: Double? = nil,
        weightKg: Double? = nil,
        bodyFatPct: Double? = nil,
        leanMassKg: Double? = nil,
        bmi: Double? = nil,
        asleepMin: Double? = nil,
        deepMin: Double? = nil,
        remMin: Double? = nil,
        coreMin: Double? = nil,
        awakeMin: Double? = nil,
        inBedMin: Double? = nil
    ) {
        self.day = day
        self.restingHr = restingHr
        self.hrvSDNN = hrvSDNN
        self.spo2Pct = spo2Pct
        self.respRate = respRate
        self.avgHr = avgHr
        self.maxHr = maxHr
        self.walkingHr = walkingHr
        self.steps = steps
        self.activeKcal = activeKcal
        self.basalKcal = basalKcal
        self.vo2max = vo2max
        self.weightKg = weightKg
        self.bodyFatPct = bodyFatPct
        self.leanMassKg = leanMassKg
        self.bmi = bmi
        self.asleepMin = asleepMin
        self.deepMin = deepMin
        self.remMin = remMin
        self.coreMin = coreMin
        self.awakeMin = awakeMin
        self.inBedMin = inBedMin
    }
}

// MARK: - Aggregator

/// Turns a parsed Apple Health export into per-day aggregates.
public enum AppleHealthAggregator {

    // MARK: Type identifiers
    //
    // `HealthSample.type` is stored with the `HKQuantityTypeIdentifier` /
    // `HKCategoryTypeIdentifier` prefix already stripped (see
    // `AppleHealthImporter.stripPrefix`). We still accept the full identifier
    // form so callers feeding raw HK strings get the same mapping.

    static let restingHR = "RestingHeartRate"
    static let hrvSDNN = "HeartRateVariabilitySDNN"
    static let spo2 = "OxygenSaturation"
    static let respRate = "RespiratoryRate"
    static let walkingHR = "WalkingHeartRateAverage"
    static let heartRate = "HeartRate"
    static let stepCount = "StepCount"
    static let activeEnergy = "ActiveEnergyBurned"
    static let basalEnergy = "BasalEnergyBurned"
    static let vo2max = "VO2Max"
    static let bodyMass = "BodyMass"
    static let bodyFat = "BodyFatPercentage"
    static let leanMass = "LeanBodyMass"
    static let bodyMassIndex = "BodyMassIndex"

    /// Normalize a sample's `type` to the stripped HK identifier so matching
    /// works whether the caller passed `HeartRate` or
    /// `HKQuantityTypeIdentifierHeartRate`.
    static func normalizedType(_ raw: String) -> String {
        let prefixes = [
            "HKQuantityTypeIdentifier",
            "HKCategoryTypeIdentifier",
            "HKDataTypeIdentifier",
        ]
        for p in prefixes where raw.hasPrefix(p) {
            return String(raw.dropFirst(p.count))
        }
        return raw
    }

    /// Whether a HealthKit mass unit string denotes pounds (`lb`, `lbs`).
    /// HealthKit normally exports BodyMass/LeanBodyMass in kg, but guard against
    /// pound-denominated exports.
    static func unitLooksLikePounds(_ unit: String?) -> Bool {
        guard let u = unit?.lowercased() else { return false }
        return u == "lb" || u == "lbs" || u.contains("pound")
    }

    // MARK: Day bucketing

    /// `yyyy-MM-dd` for a UTC `Date` shifted into its own local offset.
    /// We add the offset to the UTC instant and read the calendar fields in
    /// UTC, which yields the civil (wall-clock) date the sample was recorded on.
    static func localDay(_ utc: Date, tzOffsetMin: Int) -> String {
        let shifted = utc.addingTimeInterval(TimeInterval(tzOffsetMin * 60))
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(identifier: "UTC")!
        let c = cal.dateComponents([.year, .month, .day], from: shifted)
        return String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
    }

    // MARK: - Sample daily aggregation

    /// Group `HealthSamples` by local day and apply the per-type reduction rules.
    ///
    /// This is the **batch** form. It is a thin wrapper over
    /// `AppleDailySampleAccumulator` so the running (incremental) fold and the
    /// batch fold share ONE set of reduction rules — the accumulator is the
    /// single source of truth. The streaming importer feeds samples one-by-one
    /// into the same accumulator so a multi-year export never has to hold the raw
    /// `[HealthSample]` array in RAM.
    public static func daily(samples: [HealthSample]) -> [AppleDailyAggregate] {
        var acc = AppleDailySampleAccumulator()
        for s in samples { acc.add(s) }
        return acc.finish()
    }

    // MARK: - Sleep daily aggregation

    /// Non-overlapping episode totals keyed by the whole episode's final local wake day.
    /// XML and live HealthKit both use `AppleSleepEpisodeReducer`; raw intervals stay unchanged.
    public static func sleepDaily(
        _ intervals: [SleepStageInterval]
    ) -> [String: (asleep: Double, deep: Double, rem: Double, core: Double, awake: Double, inBed: Double)] {
        sleepReduction(intervals).totals
    }

    private typealias SleepTotals = (asleep: Double, deep: Double, rem: Double, core: Double, awake: Double, inBed: Double)

    private static func sleepReduction(_ intervals: [SleepStageInterval])
        -> (totals: [String: SleepTotals], observedAsleepDays: Set<String>,
            observedAwakeDays: Set<String>, observedInBedDays: Set<String>) {
        var output: [String: SleepTotals] = [:]
        var observedAsleepDays: Set<String> = []
        var observedAwakeDays: Set<String> = []
        var observedInBedDays: Set<String> = []
        for episode in AppleSleepEpisodeReducer.reduce(intervals) {
            if episode.hasAsleepEvidence { observedAsleepDays.insert(episode.wakeDay) }
            if episode.hasAwakeEvidence { observedAwakeDays.insert(episode.wakeDay) }
            if episode.inBed > 0 { observedInBedDays.insert(episode.wakeDay) }
            let prior = output[episode.wakeDay] ?? (0, 0, 0, 0, 0, 0)
            output[episode.wakeDay] = (prior.asleep + episode.asleep, prior.deep + episode.deep,
                                       prior.rem + episode.rem, prior.core + episode.core,
                                       prior.awake + episode.awake, prior.inBed + episode.inBed)
        }
        // Preserve the legacy zero-valued unknown-stage day without letting unknown evidence
        // connect, extend, or choose the wake timezone of a real sleep episode.
        for interval in intervals where interval.stage == .unknown {
            let duration = interval.end.timeIntervalSince(interval.start)
            guard duration.isFinite, duration > 0, duration <= 24 * 60 * 60 else { continue }
            let day = localDay(interval.end, tzOffsetMin: interval.tzOffsetMin)
            if output[day] == nil { output[day] = (0, 0, 0, 0, 0, 0) }
        }
        return (output, observedAsleepDays, observedAwakeDays, observedInBedDays)
    }

    // MARK: - Full merge

    /// Full merge of sample-daily + sleep-daily into `[AppleDailyAggregate]`,
    /// one row per day present in either source, sorted ascending by day.
    public static func aggregate(_ result: AppleHealthImportResult) -> [AppleDailyAggregate] {
        // When the importer pre-aggregated the samples incrementally (bounded
        // memory — issue #355), `sampleDailies` is already populated and the raw
        // `samples` array may have been dropped. Use the pre-aggregated form in
        // that case; otherwise fall back to folding the raw samples here (the
        // path tests take when they construct a result from raw `samples`). An
        // empty export leaves both empty → daily([]) → [] — fine.
        let sampleDaily = result.sampleDailies.isEmpty
            ? daily(samples: result.samples)
            : result.sampleDailies
        let sleepResult = sleepReduction(result.sleepIntervals)
        let sleep = sleepResult.totals

        var byDay: [String: AppleDailyAggregate] = [:]
        for d in sampleDaily { byDay[d.day] = d }

        // Union of days from both sources.
        var days = Set(byDay.keys)
        days.formUnion(sleep.keys)

        let merged: [AppleDailyAggregate] = days.map { day in
            let base = byDay[day]
            let s = sleep[day]
            let observedAsleep = sleepResult.observedAsleepDays.contains(day)
            return AppleDailyAggregate(
                day: day,
                restingHr: base?.restingHr,
                hrvSDNN: base?.hrvSDNN,
                spo2Pct: base?.spo2Pct,
                respRate: base?.respRate,
                avgHr: base?.avgHr,
                maxHr: base?.maxHr,
                walkingHr: base?.walkingHr,
                steps: base?.steps,
                activeKcal: base?.activeKcal,
                basalKcal: base?.basalKcal,
                vo2max: base?.vo2max,
                weightKg: base?.weightKg,
                bodyFatPct: base?.bodyFatPct,
                leanMassKg: base?.leanMassKg,
                bmi: base?.bmi,
                asleepMin: observedAsleep ? s?.asleep : nil,
                deepMin: observedAsleep ? s?.deep : nil,
                remMin: observedAsleep ? s?.rem : nil,
                coreMin: observedAsleep ? s?.core : nil,
                awakeMin: sleepResult.observedAwakeDays.contains(day) ? s?.awake : nil,
                inBedMin: sleepResult.observedInBedDays.contains(day) ? s?.inBed : nil
            )
        }
        return merged.sorted { $0.day < $1.day }
    }

    // MARK: - Metric point flattening

    /// Flatten daily aggregates into generic `(day, key, value)` metric points
    /// for the metricSeries store. Only present (non-nil) values are emitted.
    /// Keys are stable, snake_case identifiers.
    public static func metricPoints(_ daily: [AppleDailyAggregate]) -> [(day: String, key: String, value: Double)] {
        var out: [(day: String, key: String, value: Double)] = []
        for d in daily {
            func add(_ key: String, _ value: Double?) {
                if let v = value { out.append((day: d.day, key: key, value: v)) }
            }
            add("resting_hr", d.restingHr)
            add("hrv", d.hrvSDNN)
            add("spo2", d.spo2Pct)
            add("resp_rate", d.respRate)
            add("avg_hr", d.avgHr)
            add("max_hr", d.maxHr)
            add("walking_hr", d.walkingHr)
            add("steps", d.steps)
            add("active_kcal", d.activeKcal)
            add("basal_kcal", d.basalKcal)
            add("vo2max", d.vo2max)
            add("weight", d.weightKg)
            add("body_fat", d.bodyFatPct)
            add("lean_mass", d.leanMassKg)
            add("bmi", d.bmi)
            add("asleep_min", d.asleepMin)
            add("deep_min", d.deepMin)
            add("rem_min", d.remMin)
            add("core_min", d.coreMin)
            add("awake_min", d.awakeMin)
            add("in_bed_min", d.inBedMin)
        }
        return out
    }
}

// MARK: - Incremental (bounded-memory) sample accumulator

/// A running, O(days)-memory accumulator that produces output **identical** to
/// `AppleHealthAggregator.daily(samples:)` without ever holding the raw
/// `[HealthSample]` array.
///
/// WHY this exists (issue #355): a multi-year Apple Health export with
/// Apple-Watch continuous heart-rate is millions of `HealthSample` structs —
/// hundreds of MB to >1 GB — which iOS jetsam-kills mid-import. The streaming
/// SAX importer feeds each parsed sample straight into this accumulator and (on
/// the app path) drops the raw struct, so peak memory is bounded to the number
/// of distinct civil days, not the number of samples.
///
/// It mirrors `daily(samples:)` EXACTLY: same `normalizedType` + per-type switch,
/// the same spo2/bodyFat fraction (0..1→percent) guards, the same pounds→kg unit
/// check, the same "latest by `end`" rule for vo2/weight/bodyFat/lean/bmi, the
/// same first-seen-day order preservation, and the same final
/// `sorted { $0.day < $1.day }`. `daily(samples:)` is implemented as a thin loop
/// over this type, so the existing `AppleHealthAggregatorTests` keep validating
/// both the batch and incremental paths at once.
public struct AppleDailySampleAccumulator {

    /// Per-day running state. Means are kept as (sum, count) — no per-sample
    /// arrays — and max as a running maximum, so memory is O(days).
    private struct DayAcc {
        // Means: running sum + count.
        var restingSum = 0.0; var restingN = 0
        var hrvSum = 0.0;     var hrvN = 0
        var spo2Sum = 0.0;    var spo2N = 0
        var respSum = 0.0;    var respN = 0
        var walkingSum = 0.0; var walkingN = 0
        var hrSum = 0.0;      var hrN = 0
        // HeartRate max (running).
        var hrMax: Double?
        // Sums + presence flags.
        // #589: per-SOURCE step sums. Apple Health keeps overlapping step samples from EACH device
        // (an iPhone AND an Apple Watch both count the same walk); summing across sources double-counts
        // (~2x). We sum WITHIN a source but take the MAX source per day at finish() — the de-overlap
        // Apple's own Health app shows instead of a raw sum.
        var stepsBySource: [String: Double] = [:]
        var active = 0.0; var hasActive = false
        var basal = 0.0;  var hasBasal = false
        // Latest-by-end values.
        var vo2: Double?;     var vo2At: Date?
        var weight: Double?;  var weightAt: Date?
        var bodyFat: Double?; var bodyFatAt: Date?
        var lean: Double?;    var leanAt: Date?
        var bmi: Double?;     var bmiAt: Date?
    }

    private var byDay: [String: DayAcc] = [:]
    /// Preserve first-seen day order for deterministic output before the sort
    /// (mirrors `daily(samples:)`'s `order` array).
    private var order: [String] = []

    public init() {}

    /// Fold one sample into the running per-day state. Applies the SAME
    /// reduction rules as `AppleHealthAggregator.daily(samples:)`.
    public mutating func add(_ s: HealthSample) {
        let type = AppleHealthAggregator.normalizedType(s.type)
        let day = AppleHealthAggregator.localDay(s.start, tzOffsetMin: s.tzOffsetMin)
        if byDay[day] == nil {
            byDay[day] = DayAcc()
            order.append(day)
        }

        switch type {
        case AppleHealthAggregator.restingHR:
            if let v = s.value { byDay[day]!.restingSum += v; byDay[day]!.restingN += 1 }
        case AppleHealthAggregator.hrvSDNN:
            if let v = s.value { byDay[day]!.hrvSum += v; byDay[day]!.hrvN += 1 }
        case AppleHealthAggregator.spo2:
            if let v = s.value {
                // Detect fraction (0..1) → percent. The importer already scales
                // OxygenSaturation by 100, but defend against raw fractional
                // values here too. (Identical to daily().)
                let pct = (v > 0 && v <= 1.0) ? v * 100.0 : v
                byDay[day]!.spo2Sum += pct; byDay[day]!.spo2N += 1
            }
        case AppleHealthAggregator.respRate:
            if let v = s.value { byDay[day]!.respSum += v; byDay[day]!.respN += 1 }
        case AppleHealthAggregator.walkingHR:
            if let v = s.value { byDay[day]!.walkingSum += v; byDay[day]!.walkingN += 1 }
        case AppleHealthAggregator.heartRate:
            if let v = s.value {
                byDay[day]!.hrSum += v; byDay[day]!.hrN += 1
                if let m = byDay[day]!.hrMax { byDay[day]!.hrMax = Swift.max(m, v) }
                else { byDay[day]!.hrMax = v }
            }
        case AppleHealthAggregator.stepCount:
            // Sum WITHIN a source, never across sources (iPhone + Watch overlap → double-count). (#589)
            if let v = s.value { byDay[day]!.stepsBySource[s.sourceName ?? "", default: 0] += v }
        case AppleHealthAggregator.activeEnergy:
            if let v = s.value { byDay[day]!.active += v; byDay[day]!.hasActive = true }
        case AppleHealthAggregator.basalEnergy:
            if let v = s.value { byDay[day]!.basal += v; byDay[day]!.hasBasal = true }
        case AppleHealthAggregator.vo2max:
            if let v = s.value {
                let acc = byDay[day]!
                if acc.vo2 == nil || (acc.vo2At ?? .distantPast) <= s.end {
                    byDay[day]!.vo2 = v
                    byDay[day]!.vo2At = s.end
                }
            }
        case AppleHealthAggregator.bodyMass:
            if let v = s.value {
                // HealthKit stores BodyMass in kg by default. If the unit looks
                // like pounds, convert to kg; otherwise assume kg.
                let kg = AppleHealthAggregator.unitLooksLikePounds(s.unit) ? v * 0.453592 : v
                let acc = byDay[day]!
                if acc.weight == nil || (acc.weightAt ?? .distantPast) <= s.end {
                    byDay[day]!.weight = kg
                    byDay[day]!.weightAt = s.end
                }
            }
        case AppleHealthAggregator.bodyFat:
            if let v = s.value {
                // HealthKit stores a 0..1 fraction → percent. Defend against
                // already-percent values the same way SpO2 does.
                let pct = (v > 0 && v <= 1.0) ? v * 100.0 : v
                let acc = byDay[day]!
                if acc.bodyFat == nil || (acc.bodyFatAt ?? .distantPast) <= s.end {
                    byDay[day]!.bodyFat = pct
                    byDay[day]!.bodyFatAt = s.end
                }
            }
        case AppleHealthAggregator.leanMass:
            if let v = s.value {
                let kg = AppleHealthAggregator.unitLooksLikePounds(s.unit) ? v * 0.453592 : v
                let acc = byDay[day]!
                if acc.lean == nil || (acc.leanAt ?? .distantPast) <= s.end {
                    byDay[day]!.lean = kg
                    byDay[day]!.leanAt = s.end
                }
            }
        case AppleHealthAggregator.bodyMassIndex:
            if let v = s.value {
                let acc = byDay[day]!
                if acc.bmi == nil || (acc.bmiAt ?? .distantPast) <= s.end {
                    byDay[day]!.bmi = v
                    byDay[day]!.bmiAt = s.end
                }
            }
        default:
            break
        }
    }

    /// Emit the per-day aggregates (mean = sum/count, running max, sums, latest),
    /// in first-seen order then sorted ascending by day — identical to
    /// `daily(samples:)`.
    public func finish() -> [AppleDailyAggregate] {
        func mean(_ sum: Double, _ n: Int) -> Double? { n == 0 ? nil : sum / Double(n) }

        let result: [AppleDailyAggregate] = order.map { day in
            let a = byDay[day]!
            return AppleDailyAggregate(
                day: day,
                restingHr: mean(a.restingSum, a.restingN),
                hrvSDNN: mean(a.hrvSum, a.hrvN),
                spo2Pct: mean(a.spo2Sum, a.spo2N),
                respRate: mean(a.respSum, a.respN),
                avgHr: mean(a.hrSum, a.hrN),
                maxHr: a.hrMax,
                walkingHr: mean(a.walkingSum, a.walkingN),
                steps: a.stepsBySource.isEmpty ? nil : a.stepsBySource.values.max(),   // #589 max source, not cross-source sum
                activeKcal: a.hasActive ? a.active : nil,
                basalKcal: a.hasBasal ? a.basal : nil,
                vo2max: a.vo2,
                weightKg: a.weight,
                bodyFatPct: a.bodyFat,
                leanMassKg: a.lean,
                bmi: a.bmi
            )
        }
        return result.sorted { $0.day < $1.day }
    }
}

import Foundation

/// Common XML/live-HealthKit sleep policy. Durations use absolute instants. A gap of at most
/// 30 minutes keeps stages in one episode; gaps add no sleep. Separate naps remain separate episodes
/// and contribute to their wake day's daily total. This does not alter any stored raw evidence.
public enum AppleSleepEpisodeReducer {
    public static let maximumStageGap: TimeInterval = 30 * 60

    public struct Episode: Equatable, Sendable {
        public let start: Date
        public let end: Date
        public let wakeDay: String
        /// Distinguishes a measured zero (sleep evidence overridden by awake) from in-bed-only input.
        public let hasAsleepEvidence: Bool
        public let hasAwakeEvidence: Bool
        public let asleep: Double
        public let deep: Double
        public let rem: Double
        public let core: Double
        public let awake: Double
        /// Union of in-bed envelopes. This companion metric may overlap sleep; it is never added to it.
        public let inBed: Double
    }

    /// Keeps only an unfinished episode across bounded HealthKit query chunks. Overlap queries can
    /// repeat objects; exact interval/source/identity duplicates do not change the result.
    public struct Accumulator {
        private var pending: [SleepStageInterval] = []
        public init() {}

        public mutating func ingest(_ intervals: [SleepStageInterval], through boundary: Date) -> [Episode] {
            let groups = AppleSleepEpisodeReducer.groups(pending + intervals)
            var complete: [Episode] = []
            pending = []
            for group in groups {
                if group.map(\.end).max()!.addingTimeInterval(maximumStageGap) < boundary {
                    complete.append(AppleSleepEpisodeReducer.reduceGroup(group))
                } else {
                    pending.append(contentsOf: group)
                }
            }
            return complete
        }

        public mutating func finish() -> [Episode] {
            let result = AppleSleepEpisodeReducer.reduce(pending)
            pending = []
            return result
        }
    }

    public static func reduce(_ intervals: [SleepStageInterval]) -> [Episode] {
        groups(intervals).map(reduceGroup)
    }

    private static func groups(_ intervals: [SleepStageInterval]) -> [[SleepStageInterval]] {
        let valid = Set(intervals.filter {
            let duration = $0.end.timeIntervalSince($0.start)
            return $0.start.timeIntervalSince1970.isFinite && $0.end.timeIntervalSince1970.isFinite
                && duration > 0 && duration <= 24 * 60 * 60 && $0.stage != .unknown
        }).sorted(by: chronologicalOrder)
        // In-bed envelopes are a companion stream, never proof that two separate sleep nights
        // form one episode. A broad third-party bed envelope must not move both nights to its end.
        return (partition(valid.filter { $0.stage != .inBed })
                + partition(valid.filter { $0.stage == .inBed }))
            .sorted { chronologicalOrder($0[0], $1[0]) }
    }

    private static func partition(_ intervals: [SleepStageInterval]) -> [[SleepStageInterval]] {
        var groups: [[SleepStageInterval]] = []
        var current: [SleepStageInterval] = []
        var end = Date.distantPast
        for interval in intervals {
            if !current.isEmpty && interval.start.timeIntervalSince(end) > maximumStageGap {
                groups.append(current)
                current = []
            }
            current.append(interval)
            end = current.count == 1 ? interval.end : max(end, interval.end)
        }
        if !current.isEmpty { groups.append(current) }
        return groups
    }

    private static func chronologicalOrder(_ lhs: SleepStageInterval, _ rhs: SleepStageInterval) -> Bool {
        if lhs.start != rhs.start { return lhs.start < rhs.start }
        if lhs.end != rhs.end { return lhs.end < rhs.end }
        if sourceKey(lhs) != sourceKey(rhs) { return sourceKey(lhs) < sourceKey(rhs) }
        if lhs.stage != rhs.stage { return lhs.stage.rawValue < rhs.stage.rawValue }
        if lhs.tzOffsetMin != rhs.tzOffsetMin { return lhs.tzOffsetMin < rhs.tzOffsetMin }
        return (lhs.sampleID ?? "") < (rhs.sampleID ?? "")
    }

    private static func sourceKey(_ interval: SleepStageInterval) -> String {
        (interval.sourceName ?? "") + "\u{0}" + (interval.sourceIdentifier ?? "")
    }

    private static func rank(_ stage: SleepStage) -> Int {
        switch stage {
        case .asleepCore, .asleepDeep, .asleepREM, .awake: return 2
        case .asleepUnspecified: return 1
        case .inBed, .unknown: return 0
        }
    }

    private static func reduceGroup(_ intervals: [SleepStageInterval]) -> Episode {
        let start = intervals.map(\.start).min()!
        let end = intervals.map(\.end).max()!
        // At a tied final instant, detailed evidence wins, then stable source/interval order. The
        // chosen final interval supplies the recorded wake offset, including DST and travel changes.
        let wake = intervals.sorted {
            if $0.end != $1.end { return $0.end > $1.end }
            if rank($0.stage) != rank($1.stage) { return rank($0.stage) > rank($1.stage) }
            return chronologicalOrder($0, $1)
        }.first!
        var totals: [SleepStage: Double] = [:]
        var inBed = 0.0
        let boundaries = Array(Set(intervals.flatMap { [$0.start, $0.end] })).sorted()
        // Prefer detailed stages to unspecified summaries. If detailed sources disagree, choose
        // the source with most detailed coverage in this episode, then its stable source identity.
        // This is deterministic arbitration, not a claim that one device measures sleep better.
        let detailed = Dictionary(grouping: intervals.filter { rank($0.stage) == 2 }, by: sourceKey)
        let sourceCoverage = detailed.mapValues { values -> TimeInterval in
            var duration = 0.0
            var lastEnd = Date.distantPast
            for interval in values.sorted(by: chronologicalOrder) {
                duration += max(0, interval.end.timeIntervalSince(max(interval.start, lastEnd)))
                lastEnd = max(lastEnd, interval.end)
            }
            return duration
        }
        struct Event { let instant: Date; let index: Int; let isStart: Bool }
        let events = intervals.enumerated().flatMap { index, interval in
            [Event(instant: interval.start, index: index, isStart: true),
             Event(instant: interval.end, index: index, isStart: false)]
        }.sorted { $0.instant < $1.instant }
        var active: Set<Int> = []
        var eventIndex = 0
        for (left, right) in zip(boundaries, boundaries.dropFirst()) {
            while eventIndex < events.count && events[eventIndex].instant <= left {
                let event = events[eventIndex]
                if event.isStart { active.insert(event.index) } else { active.remove(event.index) }
                eventIndex += 1
            }
            let minutes = right.timeIntervalSince(left) / 60
            if active.contains(where: { intervals[$0].stage == .inBed }) { inBed += minutes }
            let selected = active.map { intervals[$0] }.filter { rank($0.stage) > 0 }.sorted {
                if rank($0.stage) != rank($1.stage) { return rank($0.stage) > rank($1.stage) }
                let lCoverage = sourceCoverage[sourceKey($0)] ?? 0
                let rCoverage = sourceCoverage[sourceKey($1)] ?? 0
                if lCoverage != rCoverage { return lCoverage > rCoverage }
                if sourceKey($0) != sourceKey($1) { return sourceKey($0) < sourceKey($1) }
                return chronologicalOrder($0, $1)
            }.first
            if let selected { totals[selected.stage, default: 0] += minutes }
        }
        let core = totals[.asleepCore] ?? 0, deep = totals[.asleepDeep] ?? 0, rem = totals[.asleepREM] ?? 0
        return Episode(start: start, end: end,
                       wakeDay: AppleHealthAggregator.localDay(end, tzOffsetMin: wake.tzOffsetMin),
                       hasAsleepEvidence: intervals.contains { interval in
                           switch interval.stage {
                           case .asleepCore, .asleepDeep, .asleepREM, .asleepUnspecified: return true
                           default: return false
                           }
                       },
                       hasAwakeEvidence: intervals.contains { $0.stage == .awake },
                       asleep: core + deep + rem + (totals[.asleepUnspecified] ?? 0),
                       deep: deep, rem: rem, core: core, awake: totals[.awake] ?? 0, inBed: inBed)
    }
}

final class HealthXMLDelegate: NSObject, XMLParserDelegate {

    /// When `false`, parsed samples are folded into `dailyAcc` and then dropped
    /// rather than retained in `samples`, so a multi-year export stays within a
    /// bounded memory budget (issue #355). `true` keeps the raw array for
    /// callers/tests that need it.
    let retainRawSamples: Bool

    init(retainRawSamples: Bool = true) {
        self.retainRawSamples = retainRawSamples
        super.init()
    }

    // Outputs
    private(set) var samples: [HealthSample] = []
    private(set) var workouts: [HealthWorkout] = []
    private(set) var sleepIntervals: [SleepStageInterval] = []
    private(set) var countsByType: [String: Int] = [:]
    private(set) var parseError: Error?

    /// Running per-day fold of every (deduped) sample. Always maintained — it is
    /// the bounded-memory aggregate the app consumes and is also produced when
    /// raw samples are retained, so the two paths share one reduction.
    private var dailyAcc = AppleDailySampleAccumulator()

    /// True once at least one usable record/workout/sleep row was seen. Tracked
    /// independently of `samples` because `samples` may be empty when
    /// `retainRawSamples` is false (issue #355).
    private var anyRecordSeen = false

    // Incrementally-tracked summary inputs, so makeResult doesn't need the raw
    // `samples` array (which may be empty).
    private var earliestDate: Date?
    private var latestDate: Date?
    /// Count of distinct (post-dedupe) samples folded in — the `samples.count`
    /// equivalent for the summary's recordCount when raw samples were dropped.
    private var sampleCount = 0

    // Element nesting stack (just the element names).
    private var stack: [String] = []
    // Depth of the current Correlation, if inside one. Records nested inside a
    // Correlation are skipped (they also appear top-level).
    private var correlationDepth = 0
    // The <Workout> currently being assembled. Built at the `<Workout>` start tag from its legacy
    // attributes, filled by any nested `<WorkoutStatistics>` children (iOS 16+), and appended to
    // `workouts` at the `</Workout>` end tag. nil when not inside a workout. Workouts never nest and
    // never appear inside a Correlation, so a single slot (not a stack) is sufficient.
    private var pendingWorkout: HealthWorkout?

    // Dedupe set over HealthSample dedupeKeys — stored as the key's 64-bit HASH, not the full String
    // (#183). A large Apple Health export has tens of millions of unique samples; retaining a ~50-100 B
    // String each was ~1-2 GB of RAM, enough to push an import into sustained memory pressure and hang.
    // A 64-bit hash is 8 B/entry (~10x less); a collision across even 20M samples is ~1e-5, and a rare
    // one just drops a look-alike duplicate — the same effect dedup intends. Within one import run the
    // hash is stable, so identical keys always dedupe.
    private var seenSampleKeys: Set<Int> = []

    /// 64-bit FNV-1a over `s`'s UTF-16 code units — byte-identical to the Android `hash64` (both iterate
    /// UTF-16 units with the same offset basis + prime, wrapping at 64 bits), so the two platforms produce
    /// the same dedupe hashes and drop the exact same look-alike duplicates (#183).
    static func hash64(_ s: String) -> Int {
        var h: UInt64 = 0xcbf29ce484222325   // FNV-1a 64-bit offset basis
        for u in s.utf16 {
            h = (h ^ UInt64(u)) &* 0x100000001b3   // xor code unit, ×= FNV prime (wraps, intended)
        }
        return Int(bitPattern: UInt(h))
    }

    /// True once at least one usable record/workout/sleep row was parsed. Drives the tolerant-parse
    /// decision: a hard error AFTER real data was seen keeps the partial result instead of failing.
    /// Uses `anyRecordSeen` (not `samples`) so it still fires when raw samples are dropped.
    var hasAnyRecord: Bool {
        anyRecordSeen || !workouts.isEmpty || !sleepIntervals.isEmpty
    }

    private let dateParser = HealthDateParser()

    // MARK: XMLParserDelegate

    func parser(
        _ parser: XMLParser,
        didStartElement elementName: String,
        namespaceURI: String?,
        qualifiedName qName: String?,
        attributes attributeDict: [String: String]
    ) {
        let parentIsCorrelation = (stack.last == "Correlation")
        stack.append(elementName)

        // Drain per-element: a multi-year export.xml has tens of millions of elements, each
        // bridging an attribute dictionary + temporaries (date parsing). Without a pool these
        // accumulate until parse() returns, inflating peak memory. Pool drains every element.
        autoreleasepool {
            switch elementName {
            case "Correlation":
                correlationDepth += 1

            case "Record":
                // Skip records nested inside a Correlation (deduped to top-level).
                if parentIsCorrelation || correlationDepth > 0 {
                    return
                }
                handleRecord(attributeDict)

            case "Workout":
                handleWorkout(attributeDict)

            case "WorkoutStatistics":
                // iOS 16+ nests per-workout energy/distance/HR here (was <Workout> attributes on iOS <=15).
                handleWorkoutStatistics(attributeDict)

            default:
                break
            }
        }
    }

    func parser(
        _ parser: XMLParser,
        didEndElement elementName: String,
        namespaceURI: String?,
        qualifiedName qName: String?
    ) {
        if elementName == "Correlation", correlationDepth > 0 {
            correlationDepth -= 1
        }
        if elementName == "Workout" {
            // The whole <Workout> sub-tree (including any <WorkoutStatistics>) has now been seen; commit it.
            finishWorkout()
        }
        if stack.last == elementName {
            stack.removeLast()
        }
    }

    func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) {
        // Ignore benign "no data" / EOF style errors that can occur when the
        // streaming pipe closes; only record genuine malformed-XML errors.
        let ns = parseError as NSError
        if ns.domain == XMLParser.errorDomain {
            // Code 5 == NSXMLParserPrematureDocumentEndError can happen on empty
            // streams; treat truly empty as non-fatal only if we parsed nothing.
            if ns.code == XMLParser.ErrorCode.prematureDocumentEndError.rawValue,
               !anyRecordSeen, workouts.isEmpty, sleepIntervals.isEmpty {
                self.parseError = parseError
                return
            }
        }
        self.parseError = parseError
    }

    // MARK: Record handling

    private func handleRecord(_ attrs: [String: String]) {
        guard let rawType = attrs["type"] else { return }
        let type = Self.stripPrefix(rawType)
        guard AppleHealthImporter.relevantTypes.contains(type) else { return }

        guard
            let startStr = attrs["startDate"],
            let endStr = attrs["endDate"],
            let (start, _) = dateParser.parse(startStr),
            let (end, endOffset) = dateParser.parse(endStr)
        else { return }

        let source = attrs["sourceName"]
        let unit = attrs["unit"]
        let rawValue = attrs["value"]

        if type == "SleepAnalysis" {
            // Sleep is a category record; its value is a stage enum string.
            let stage = SleepStage.from(rawValue: rawValue ?? "")
            let interval = SleepStageInterval(
                stage: stage,
                start: start,
                end: end,
                tzOffsetMin: endOffset,
                sourceName: source
            )
            sleepIntervals.append(interval)
            countsByType[type, default: 0] += 1
            anyRecordSeen = true
            // Mirror the old summary, which spanned EVERY sleep interval's start
            // (intervals are never deduped). Tracked here so a deduped sleep
            // sample still contributes its start to the date span.
            if earliestDate == nil || start < earliestDate! { earliestDate = start }
            if latestDate == nil || start > latestDate! { latestDate = start }

            // Also record a generic sample so the row survives in the sink with
            // its raw value string (dedupe-protected).
            appendSample(
                type: type,
                value: nil,
                valueString: rawValue,
                unit: unit,
                start: start,
                end: end,
                tzOffsetMin: endOffset,
                sourceName: source
            )
            return
        }

        var numeric = rawValue.flatMap { Double($0) }
        // OxygenSaturation is a 0–1 fraction → percent.
        if type == "OxygenSaturation", let v = numeric {
            numeric = v * 100.0
        }

        appendSample(
            type: type,
            value: numeric,
            valueString: rawValue,
            unit: unit,
            start: start,
            end: end,
            tzOffsetMin: endOffset,
            sourceName: source
        )
        countsByType[type, default: 0] += 1
    }

    private func appendSample(
        type: String,
        value: Double?,
        valueString: String?,
        unit: String?,
        start: Date,
        end: Date,
        tzOffsetMin: Int,
        sourceName: String?
    ) {
        let sample = HealthSample(
            type: type,
            value: value,
            valueString: valueString,
            unit: unit,
            start: start,
            end: end,
            tzOffsetMin: tzOffsetMin,
            sourceName: sourceName
        )
        // Dedupe on type+start+end+source+value (correctness-critical). Retain only the key's 64-bit
        // hash, not the String, so the set stays ~10x smaller on a huge export (#183). Uses the SAME
        // FNV-1a as Android (NOT Swift's per-run-randomized hashValue) so both platforms dedupe identically.
        if seenSampleKeys.insert(Self.hash64(sample.dedupeKey)).inserted {
            // Always fold into the bounded per-day accumulator.
            dailyAcc.add(sample)
            anyRecordSeen = true
            sampleCount += 1
            // Track the date span incrementally so makeResult never needs the
            // (possibly empty) raw `samples` array. Matches the prior summary,
            // which spanned sample/workout/sleep `start` dates.
            if earliestDate == nil || start < earliestDate! { earliestDate = start }
            if latestDate == nil || start > latestDate! { latestDate = start }
            // Only retain the raw struct when the caller asked for it.
            if retainRawSamples {
                samples.append(sample)
            }
        }
    }

    // MARK: Workout handling

    private func handleWorkout(_ attrs: [String: String]) {
        guard
            let startStr = attrs["startDate"],
            let endStr = attrs["endDate"],
            let (start, _) = dateParser.parse(startStr),
            let (end, endOffset) = dateParser.parse(endStr)
        else { return }

        let rawActivity = attrs["workoutActivityType"] ?? "Unknown"
        let activity = Self.stripPrefix(rawActivity)

        var durationS: Double?
        if let dStr = attrs["duration"], let d = Double(dStr) {
            // durationUnit is typically "min"; default to minutes per Apple's export.
            let unit = (attrs["durationUnit"] ?? "min").lowercased()
            switch unit {
            case "min": durationS = d * 60.0
            case "sec", "s": durationS = d
            case "hr", "h": durationS = d * 3600.0
            default: durationS = d * 60.0
            }
        }

        // iOS <=15 put per-workout totals on <Workout> as `totalDistance`/`totalEnergyBurned`; iOS 16+
        // moved them into nested <WorkoutStatistics> children (folded in by `handleWorkoutStatistics`).
        // Seed the pending workout from the legacy attributes; the children FILL any still absent — a
        // modern export carries no legacy attributes, so nothing a legacy value set is clobbered.
        let distanceM = attrs["totalDistance"].flatMap { Double($0) }
            .map { Self.distanceMeters($0, unit: attrs["totalDistanceUnit"]) }
        let energyKcal = attrs["totalEnergyBurned"].flatMap { Double($0) }
        // Apple exports energy in kcal by default (totalEnergyBurnedUnit "kcal").

        // Defer the append / counts to `finishWorkout()` at `</Workout>`, once any statistics children
        // have folded in. A truncated workout with no end tag is simply dropped (its tail is counted a
        // skipped span upstream), never counted as a complete row.
        pendingWorkout = HealthWorkout(
            activityType: activity,
            durationS: durationS,
            distanceM: distanceM,
            energyKcal: energyKcal,
            start: start,
            end: end,
            tzOffsetMin: endOffset,
            sourceName: attrs["sourceName"]
        )
    }

    /// Fold one `<WorkoutStatistics>` child into the workout currently being assembled. iOS 16+ emits
    /// per-metric totals here: energy/distance as `sum`, heart rate as `average`/`maximum`. Fills only a
    /// field still absent, so a legacy attribute value already set is never overwritten.
    private func handleWorkoutStatistics(_ attrs: [String: String]) {
        guard var workout = pendingWorkout, let rawType = attrs["type"] else { return }
        let type = Self.stripPrefix(rawType)
        switch type {
        case "ActiveEnergyBurned":
            if workout.energyKcal == nil { workout.energyKcal = attrs["sum"].flatMap { Double($0) } }
        case "HeartRate":
            if workout.avgHr == nil { workout.avgHr = attrs["average"].flatMap { Double($0) } }
            if workout.maxHr == nil { workout.maxHr = attrs["maximum"].flatMap { Double($0) } }
        default:
            if type.hasPrefix("Distance"), workout.distanceM == nil {
                workout.distanceM = attrs["sum"].flatMap { Double($0) }
                    .map { Self.distanceMeters($0, unit: attrs["unit"]) }
            }
        }
        pendingWorkout = workout
    }

    /// Commit the assembled workout at `</Workout>`: append it and fold its start into the summary's
    /// counts + date span (deferred here so any statistics children are already in). No-op when not in a
    /// workout (a stray end tag) or when the start tag was rejected for bad dates.
    private func finishWorkout() {
        guard let workout = pendingWorkout else { return }
        pendingWorkout = nil
        workouts.append(workout)
        countsByType["Workout", default: 0] += 1
        anyRecordSeen = true
        // Workouts don't go through appendSample, so track their start in the
        // incremental date span too (matches the prior summary).
        if earliestDate == nil || workout.start < earliestDate! { earliestDate = workout.start }
        if latestDate == nil || workout.start > latestDate! { latestDate = workout.start }
    }

    /// Convert a distance value in `km` / `mi` / `m` to metres (defaulting to km, Apple's usual unit).
    static func distanceMeters(_ value: Double, unit: String?) -> Double {
        switch (unit ?? "km").lowercased() {
        case "km": return value * 1000.0
        case "mi": return value * 1609.344
        case "m":  return value
        default:   return value * 1000.0
        }
    }

    // MARK: Result

    /// Build the normalized result. `extraSkippedSpans` carries the number of dropped XML spans
    /// (sanitizer-scrubbed illegal-byte runs, plus 1 if a hard parse error truncated the tail) so the
    /// summary reports a partial import honestly instead of looking complete.
    func makeResult(extraSkippedSpans: Int = 0) -> AppleHealthImportResult {
        // Build the summary from incrementally-tracked values, NOT from `samples`
        // (which is empty when raw samples were dropped — issue #355).
        // `sampleCount` is the post-dedupe sample count, matching the old
        // `samples.count`; earliest/latest span sample + workout + sleep starts.
        let summary = ImportSummary(
            sourceKind: .appleHealth,
            recordCount: sampleCount + workouts.count,
            earliest: earliestDate,
            latest: latestDate,
            countsByCategory: countsByType,
            skippedSpans: extraSkippedSpans
        )
        return AppleHealthImportResult(
            samples: samples,
            workouts: workouts,
            sleepIntervals: sleepIntervals,
            summary: summary,
            sampleDailies: dailyAcc.finish()
        )
    }

    // MARK: Helpers

    /// Strip the HealthKit identifier prefix from a type string.
    /// `HKQuantityTypeIdentifierHeartRate` → `HeartRate`,
    /// `HKCategoryTypeIdentifierSleepAnalysis` → `SleepAnalysis`,
    /// `HKWorkoutActivityTypeRunning` → `Running`.
    static func stripPrefix(_ raw: String) -> String {
        let prefixes = [
            "HKQuantityTypeIdentifier",
            "HKCategoryTypeIdentifier",
            "HKDataTypeIdentifier",
            "HKWorkoutActivityType",
        ]
        for p in prefixes where raw.hasPrefix(p) {
            return String(raw.dropFirst(p.count))
        }
        return raw
    }
}
final class HealthDateParser {
    private let formatter: DateFormatter

    init() {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.calendar = Calendar(identifier: .gregorian)
        f.dateFormat = "yyyy-MM-dd HH:mm:ss Z"
        self.formatter = f
    }

    /// Returns (utcDate, offsetMinutes).
    func parse(_ raw: String) -> (Date, Int)? {
        guard let date = formatter.date(from: raw) else {
            // Fallback: try a few alternative shapes (ISO-8601, no seconds).
            return parseFallback(raw)
        }
        return (date, Self.offsetMinutes(from: raw))
    }

    private func parseFallback(_ raw: String) -> (Date, Int)? {
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [.withInternetDateTime]
        if let d = iso.date(from: raw) {
            return (d, Self.offsetMinutes(from: raw))
        }
        return nil
    }

    /// Extract the trailing numeric UTC offset (`+0100`, `-0500`, `+01:00`, `Z`)
    /// from a date string, in minutes.
    static func offsetMinutes(from raw: String) -> Int {
        let trimmed = raw.trimmingCharacters(in: .whitespaces)
        if trimmed.hasSuffix("Z") || trimmed.hasSuffix("z") { return 0 }
        // Offset is the last token; look for the sign within the last ~6 chars.
        let tail = String(trimmed.suffix(6))
        guard let signRange = tail.range(of: "[+-]", options: .regularExpression) else {
            return 0
        }
        let offStr = String(tail[signRange.lowerBound...])
        let sign = offStr.hasPrefix("-") ? -1 : 1
        let digits = offStr.dropFirst().filter { $0.isNumber }
        guard digits.count >= 2 else { return 0 }
        let s = String(digits)
        var hours = 0, minutes = 0
        if s.count >= 4 {
            hours = Int(s.prefix(2)) ?? 0
            minutes = Int(s.dropFirst(2).prefix(2)) ?? 0
        } else {
            hours = Int(s.prefix(2)) ?? 0
        }
        return sign * (hours * 60 + minutes)
    }
}
enum AppleHealthImporter { static let relevantTypes: Set<String> = ["HeartRate", "StepCount", "SleepAnalysis"] }
func autoreleasepool<T>(invoking body: () throws -> T) rethrows -> T { try body() }
@main struct Probe {
 static func main() {
  let xml = """
  <HealthData><Record type="HKQuantityTypeIdentifierHeartRate" sourceName="synthetic" unit="count/min" startDate="2026-10-20 08:00:00 +0000" endDate="2026-10-20 08:00:00 +0000" value="NaN"/></HealthData>
  """
  let delegate = HealthXMLDelegate(retainRawSamples: false)
  let parser = XMLParser(data: Data(xml.utf8)); parser.delegate = delegate
  precondition(parser.parse())
  let d = AppleHealthAggregator.aggregate(delegate.makeResult())[0]
  print("XML parsed; avgHR=\(String(describing:d.avgHr))")
  fflush(stdout)
  // The production AppleHealthImport mapping at base line30.
  let mapped = d.avgHr.map { Int($0.rounded()) }
  print(mapped as Any)
 }
}