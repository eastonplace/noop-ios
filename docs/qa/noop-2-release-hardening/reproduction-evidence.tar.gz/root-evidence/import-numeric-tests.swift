import Foundation

// MARK: - Source provenance

/// Where a normalized row originated. Mirrors the `dataSource.kind` provenance
/// described in the Strand design spec (§5).
public enum DataSourceKind: String, Sendable, Codable, Equatable, CaseIterable {
    case appleHealth
    case whoopExport
    /// Xiaomi Smart Band (Mi Band) — imported from the Mi Fitness iOS app's
    /// on-device SQLite store (`DataBase/<user_id>/de/<user_id>.db`). Account-free,
    /// fully offline: NOOP reads the file the user already owns.
    case xiaomiBand
    /// Oura Ring — the user's own Account data export (JSON), imported from the file
    /// Oura hands them. Sleep periods + daily readiness/activity → daily metrics + sleep
    /// sessions. Fully offline, no Oura cloud/API.
    case ouraImport
    /// Fitbit — the user's own Google Takeout → Fitbit JSON export (per-day sleep /
    /// resting_heart_rate / steps / heart_rate files). Fully offline, no Fitbit/Google API.
    case fitbitImport
    /// Garmin — the user's own Garmin Connect "Export Your Data" (GDPR) wellness JSON/CSV
    /// (sleep / resting HR / stress / steps). The FIT activity files inside the same ZIP are
    /// handled by the wave-1 FIT parser; this path does the WELLNESS daily + sleep only.
    case garminImport
}

// MARK: - Generic health sample (Apple Health Record sink)

/// A single normalized Apple Health `<Record>` reading.
///
/// Timestamps are normalized to UTC `Date`s while the original UTC offset (in
/// minutes) is preserved in `tzOffsetMin`, matching the `hkSample` table shape
/// in the design spec (§5).
public struct HealthSample: Sendable, Equatable, Hashable {
    /// HealthKit type identifier, stripped of the `HKQuantityTypeIdentifier` /
    /// `HKCategoryTypeIdentifier` prefix (e.g. `HeartRate`, `SleepAnalysis`).
    public var type: String
    /// Numeric value, when the record is quantitative. `nil` for pure category
    /// records whose meaning lives in `valueString`.
    public var value: Double?
    /// Raw string value as it appeared in the export (category enum strings,
    /// or the textual numeric value). Always populated when present.
    public var valueString: String?
    /// Unit string from the record (e.g. `count/min`, `%`, `degC`). May be nil.
    public var unit: String?
    /// Start of the sample, normalized to UTC.
    public var start: Date
    /// End of the sample, normalized to UTC.
    public var end: Date
    /// Original UTC offset of the source timestamp, in minutes (e.g. `60` for
    /// `+0100`, `-300` for `-0500`).
    public var tzOffsetMin: Int
    /// `sourceName` attribute (the device/app that produced the record).
    public var sourceName: String?

    public init(
        type: String,
        value: Double?,
        valueString: String?,
        unit: String?,
        start: Date,
        end: Date,
        tzOffsetMin: Int,
        sourceName: String?
    ) {
        self.type = type
        self.value = value
        self.valueString = valueString
        self.unit = unit
        self.start = start
        self.end = end
        self.tzOffsetMin = tzOffsetMin
        self.sourceName = sourceName
    }

    /// Dedupe key per the spec: `type+startDate+endDate+sourceName+value`.
    /// Records nested in a `<Correlation>` also appear at top level; collapsing
    /// on this key removes the duplicates.
    public var dedupeKey: String {
        let v = valueString ?? value.map { String($0) } ?? ""
        return "\(type)|\(start.timeIntervalSince1970)|\(end.timeIntervalSince1970)|\(sourceName ?? "")|\(v)"
    }
}

// MARK: - Apple Health workout

/// A normalized Apple Health `<Workout>` element.
public struct HealthWorkout: Sendable, Equatable {
    /// `workoutActivityType`, stripped of the `HKWorkoutActivityType` prefix
    /// (e.g. `Running`, `FunctionalStrengthTraining`).
    public var activityType: String
    /// Total duration in seconds (from the `duration`/`durationUnit` attrs).
    public var durationS: Double?
    /// Total distance in metres, when present.
    public var distanceM: Double?
    /// Total active energy burned in kilocalories, when present.
    public var energyKcal: Double?
    /// Average heart rate over the workout, when present (iOS 16+ `<WorkoutStatistics>` only).
    public var avgHr: Double?
    /// Peak heart rate over the workout, when present (iOS 16+ `<WorkoutStatistics>` only).
    public var maxHr: Double?
    public var start: Date
    public var end: Date
    public var tzOffsetMin: Int
    public var sourceName: String?

    public init(
        activityType: String,
        durationS: Double?,
        distanceM: Double?,
        energyKcal: Double?,
        avgHr: Double? = nil,
        maxHr: Double? = nil,
        start: Date,
        end: Date,
        tzOffsetMin: Int,
        sourceName: String?
    ) {
        self.activityType = activityType
        self.durationS = durationS
        self.distanceM = distanceM
        self.energyKcal = energyKcal
        self.avgHr = avgHr
        self.maxHr = maxHr
        self.start = start
        self.end = end
        self.tzOffsetMin = tzOffsetMin
        self.sourceName = sourceName
    }
}

// MARK: - Sleep stage interval

/// The canonical sleep stages Strand recognises from Apple Health
/// `HKCategoryValueSleepAnalysis*` values.
public enum SleepStage: String, Sendable, Equatable, CaseIterable {
    case inBed
    case asleepUnspecified   // legacy "Asleep"
    case asleepCore
    case asleepDeep
    case asleepREM
    case awake
    case unknown

    /// Map a raw HealthKit `SleepAnalysis` category value string to a stage.
    /// Accepts both the modern `HKCategoryValueSleepAnalysis…` form and the
    /// legacy numeric/short forms.
    public static func from(rawValue raw: String) -> SleepStage {
        switch raw {
        case "HKCategoryValueSleepAnalysisInBed", "InBed", "0":
            return .inBed
        case "HKCategoryValueSleepAnalysisAsleep", "HKCategoryValueSleepAnalysisAsleepUnspecified", "Asleep", "1":
            return .asleepUnspecified
        case "HKCategoryValueSleepAnalysisAsleepCore", "AsleepCore", "3":
            return .asleepCore
        case "HKCategoryValueSleepAnalysisAsleepDeep", "AsleepDeep", "4":
            return .asleepDeep
        case "HKCategoryValueSleepAnalysisAsleepREM", "AsleepREM", "5":
            return .asleepREM
        case "HKCategoryValueSleepAnalysisAwake", "Awake", "2":
            return .awake
        default:
            return .unknown
        }
    }
}

/// A single contiguous sleep-stage interval from Apple Health.
public struct SleepStageInterval: Sendable, Equatable, Hashable {
    public var stage: SleepStage
    public var start: Date
    public var end: Date
    public var tzOffsetMin: Int
    public var sourceName: String?
    /// HealthKit's source bundle and object UUID when available. XML keeps its recorded source name.
    public var sourceIdentifier: String?
    public var sampleID: String?

    public init(
        stage: SleepStage,
        start: Date,
        end: Date,
        tzOffsetMin: Int,
        sourceName: String?,
        sourceIdentifier: String? = nil,
        sampleID: String? = nil
    ) {
        self.stage = stage
        self.start = start
        self.end = end
        self.tzOffsetMin = tzOffsetMin
        self.sourceName = sourceName
        self.sourceIdentifier = sourceIdentifier
        self.sampleID = sampleID
    }
}

// MARK: - Whoop daily cycle (physiological_cycles.csv)

/// One row of `physiological_cycles.csv` — Whoop's master daily summary.
///
/// All durations are stored in **minutes** as they appear in the CSV. Energy is
/// stored in **kcal** (Whoop's CSV `(cal)` is actually kcal). Timestamps are the
/// raw `YYYY-MM-DD HH:MM:SS` strings parsed against `cycleTimezone` into UTC
/// `Date`s, with the offset preserved in `tzOffsetMin`.
public struct WhoopCycleRow: Sendable, Equatable {
    /// Cycle start (UTC). The primary key for a Whoop day.
    public var cycleStart: Date?
    public var cycleEnd: Date?
    /// Original `Cycle timezone` offset in minutes (e.g. `+01:00` → 60).
    public var tzOffsetMin: Int

    public var recoveryScore: Double?
    public var restingHeartRate: Double?
    public var hrvMs: Double?
    public var skinTempCelsius: Double?
    public var bloodOxygenPct: Double?
    public var dayStrain: Double?
    public var energyKcal: Double?
    public var avgHeartRate: Double?
    public var maxHeartRate: Double?

    public var sleepOnset: Date?
    public var wakeOnset: Date?
    public var sleepPerformancePct: Double?
    public var respiratoryRate: Double?
    public var asleepDurationMin: Double?
    public var inBedDurationMin: Double?
    public var lightSleepDurationMin: Double?
    public var deepSleepDurationMin: Double?
    public var remDurationMin: Double?
    public var awakeDurationMin: Double?
    public var sleepEfficiencyPct: Double?
    public var sleepConsistencyPct: Double?
    public var sleepNeedMin: Double?
    public var sleepDebtMin: Double?

    public init() {
        self.cycleStart = nil
        self.cycleEnd = nil
        self.tzOffsetMin = 0
    }
}

// MARK: - Whoop sleep (sleeps.csv)

/// One row of `sleeps.csv` — per sleep or nap. Adds the `Nap` boolean over the
/// daily cycle summary.
public struct WhoopSleepRow: Sendable, Equatable {
    public var cycleStart: Date?
    public var sleepOnset: Date?
    public var wakeOnset: Date?
    public var tzOffsetMin: Int
    public var isNap: Bool

    public var sleepPerformancePct: Double?
    public var respiratoryRate: Double?
    public var asleepDurationMin: Double?
    public var inBedDurationMin: Double?
    public var lightSleepDurationMin: Double?
    public var deepSleepDurationMin: Double?
    public var remDurationMin: Double?
    public var awakeDurationMin: Double?
    public var sleepEfficiencyPct: Double?
    public var sleepConsistencyPct: Double?
    public var sleepNeedMin: Double?
    public var sleepDebtMin: Double?

    public init() {
        self.cycleStart = nil
        self.sleepOnset = nil
        self.wakeOnset = nil
        self.tzOffsetMin = 0
        self.isNap = false
    }
}

// MARK: - Whoop workout (workouts.csv)

/// One row of `workouts.csv`. GPS / distance / altitude columns are optional.
public struct WhoopWorkoutRow: Sendable, Equatable {
    public var cycleStart: Date?
    public var workoutStart: Date?
    public var workoutEnd: Date?
    public var tzOffsetMin: Int

    public var activityName: String?
    public var activityStrain: Double?
    public var energyKcal: Double?
    public var avgHeartRate: Double?
    public var maxHeartRate: Double?

    public var hrZone1Pct: Double?
    public var hrZone2Pct: Double?
    public var hrZone3Pct: Double?
    public var hrZone4Pct: Double?
    public var hrZone5Pct: Double?

    // Optional GPS / distance / altitude columns (may be absent entirely).
    public var distanceMeters: Double?
    public var altitudeGainMeters: Double?
    public var altitudeChangeMeters: Double?

    public init() {
        self.cycleStart = nil
        self.workoutStart = nil
        self.workoutEnd = nil
        self.tzOffsetMin = 0
    }
}

// MARK: - Whoop journal (journal_entries.csv)

/// One row of `journal_entries.csv` — tall format: a question and its answer
/// (with optional notes) per cycle.
public struct WhoopJournalRow: Sendable, Equatable {
    public var cycleStart: Date?
    public var tzOffsetMin: Int
    public var question: String?
    public var answer: String?
    public var notes: String?

    public init() {
        self.cycleStart = nil
        self.tzOffsetMin = 0
    }
}

// MARK: - Xiaomi Smart Band (Mi Fitness export)

/// The canonical sleep stages NOOP recognises from the Mi Fitness `sleep` table's
/// per-segment `state` codes. Verified against a real Mi Band 10 export:
/// `1 = awake, 2 = light, 3 = deep, 4 = REM, 5 = awake-in-bed`.
public enum XiaomiSleepStage: String, Sendable, Equatable, CaseIterable {
    case awake
    case light
    case deep
    case rem
    case awakeInBed
    case unknown

    public static func from(state: Int) -> XiaomiSleepStage {
        switch state {
        case 1: return .awake
        case 2: return .light
        case 3: return .deep
        case 4: return .rem
        case 5: return .awakeInBed
        default: return .unknown
        }
    }
}

/// One contiguous sleep-stage interval (`items[]` entry) from a Mi Fitness `sleep` row.
public struct XiaomiSleepStageInterval: Sendable, Equatable {
    public var stage: XiaomiSleepStage
    public var start: Date
    public var end: Date

    public init(stage: XiaomiSleepStage, start: Date, end: Date) {
        self.stage = stage
        self.start = start
        self.end = end
    }
}

/// One sleep session reconstructed from a Mi Fitness `sleep` interval row, including
/// its full hypnogram (`stages`). Durations are minutes, as the band reports them.
public struct XiaomiSleepSession: Sendable, Equatable {
    public var bedtime: Date
    public var wakeTime: Date
    public var deepMin: Double?
    public var lightMin: Double?
    public var remMin: Double?
    public var awakeMin: Double?
    public var avgHr: Int?
    public var minHr: Int?
    public var maxHr: Int?
    public var awakeCount: Int?
    public var sleepScore: Int?
    public var stages: [XiaomiSleepStageInterval]

    public init(
        bedtime: Date,
        wakeTime: Date,
        deepMin: Double? = nil,
        lightMin: Double? = nil,
        remMin: Double? = nil,
        awakeMin: Double? = nil,
        avgHr: Int? = nil,
        minHr: Int? = nil,
        maxHr: Int? = nil,
        awakeCount: Int? = nil,
        sleepScore: Int? = nil,
        stages: [XiaomiSleepStageInterval] = []
    ) {
        self.bedtime = bedtime
        self.wakeTime = wakeTime
        self.deepMin = deepMin
        self.lightMin = lightMin
        self.remMin = remMin
        self.awakeMin = awakeMin
        self.avgHr = avgHr
        self.minHr = minHr
        self.maxHr = maxHr
        self.awakeCount = awakeCount
        self.sleepScore = sleepScore
        self.stages = stages
    }
}

/// One calendar day rolled up from the Mi Fitness `*_day` tables. `day` is the
/// band's local calendar day (`YYYY-MM-DD`, derived from the row's `zone_offset`).
/// All metric fields are optional — a given day only carries what the band recorded.
public struct XiaomiDailyRow: Sendable, Equatable {
    public var day: String
    public var dayStart: Date

    // Activity (steps_day / calories_day / intensity_day / valid_stand_day)
    public var steps: Int?
    public var distanceM: Double?
    public var activeKcal: Double?
    public var intensityMin: Double?
    public var standCount: Int?

    // Heart rate (heart_rate_day)
    public var restingHr: Int?
    public var avgHr: Int?
    public var minHr: Int?
    public var maxHr: Int?

    // Sleep rollup (sleep_day)
    public var totalSleepMin: Double?
    public var deepMin: Double?
    public var lightMin: Double?
    public var remMin: Double?
    public var awakeMin: Double?
    public var sleepScore: Int?

    // Wellbeing (stress_day / spo2_day / vitality)
    public var avgStress: Int?
    public var avgSpo2: Double?
    public var vitality: Int?

    public init(day: String, dayStart: Date) {
        self.day = day
        self.dayStart = dayStart
    }
}

/// Normalized output of parsing a Mi Fitness export (the iOS app sandbox folder,
/// a zip of it, or the bare `<user_id>.db`).
public struct XiaomiImportResult: Sendable, Equatable {
    public var days: [XiaomiDailyRow]
    public var sleeps: [XiaomiSleepSession]
    public var summary: ImportSummary

    public init(days: [XiaomiDailyRow], sleeps: [XiaomiSleepSession], summary: ImportSummary) {
        self.days = days
        self.sleeps = sleeps
        self.summary = summary
    }
}

// MARK: - Wearable file-export import (Oura / Fitbit / Garmin own-data exports)

/// Which third-party wearable an export came from. Used to pick the right parser and to
/// tag every imported row with an honest per-source label (`oura-import` / `fitbit-import` /
/// `garmin-import`), so the UI never confuses Oura/Fitbit/Garmin data with WHOOP's.
public enum WearableBrand: String, Sendable, Equatable, CaseIterable {
    case oura
    case fitbit
    case garmin

    /// The per-source partition / provenance id written as the Data Source device id (mirrors
    /// `"my-whoop"` / `"apple-health"` / `"xiaomi-band"`). Honest: imported, not live.
    public var sourceId: String {
        switch self {
        case .oura:   return "oura-import"
        case .fitbit: return "fitbit-import"
        case .garmin: return "garmin-import"
        }
    }

    /// Human label for the import summary / Data Source card.
    public var displayName: String {
        switch self {
        case .oura:   return "Oura"
        case .fitbit: return "Fitbit"
        case .garmin: return "Garmin"
        }
    }

    public var dataSourceKind: DataSourceKind {
        switch self {
        case .oura:   return .ouraImport
        case .fitbit: return .fitbitImport
        case .garmin: return .garminImport
        }
    }
}

/// One contiguous sleep-stage interval reconstructed from a wearable export's hypnogram, when
/// the export carried per-segment staging (Fitbit `levels.data`, Garmin `sleepLevels`). Oura's
/// account export gives stage DURATIONS but not a per-segment timeline, so its sessions carry the
/// duration breakdown without a stage list — honest: we never synthesize a fake hypnogram.
public struct WearableSleepStageInterval: Sendable, Equatable {
    /// Normalized stage name written into the stage JSON: "deep" / "light" / "rem" / "wake".
    public var stage: String
    public var start: Date
    public var end: Date

    public init(stage: String, start: Date, end: Date) {
        self.stage = stage
        self.start = start
        self.end = end
    }
}

/// One sleep session imported from a wearable export. Durations are MINUTES (as NOOP's
/// `DailyMetric` / sleep model use). A field is nil when the export didn't carry it — never
/// fabricated. `stages` is empty when the export gave only a duration breakdown (Oura).
public struct WearableSleepSession: Sendable, Equatable {
    public var start: Date          // bedtime / sleep onset (UTC)
    public var end: Date            // wake (UTC)
    public var deepMin: Double?
    public var lightMin: Double?
    public var remMin: Double?
    public var awakeMin: Double?
    public var totalSleepMin: Double?
    public var efficiencyPct: Double?
    public var avgHr: Int?
    public var lowestHr: Int?       // Oura/Garmin lowest sleeping HR ≈ resting
    public var avgHrvMs: Double?    // Oura "average_hrv" (rMSSD ms); others nil
    public var respRateBpm: Double? // Oura "average_breath"; others nil
    public var sleepScore: Int?     // the brand's OWN score — stored as reference only, never Charge
    public var stages: [WearableSleepStageInterval]

    public init(
        start: Date,
        end: Date,
        deepMin: Double? = nil,
        lightMin: Double? = nil,
        remMin: Double? = nil,
        awakeMin: Double? = nil,
        totalSleepMin: Double? = nil,
        efficiencyPct: Double? = nil,
        avgHr: Int? = nil,
        lowestHr: Int? = nil,
        avgHrvMs: Double? = nil,
        respRateBpm: Double? = nil,
        sleepScore: Int? = nil,
        stages: [WearableSleepStageInterval] = []
    ) {
        self.start = start
        self.end = end
        self.deepMin = deepMin
        self.lightMin = lightMin
        self.remMin = remMin
        self.awakeMin = awakeMin
        self.totalSleepMin = totalSleepMin
        self.efficiencyPct = efficiencyPct
        self.avgHr = avgHr
        self.lowestHr = lowestHr
        self.avgHrvMs = avgHrvMs
        self.respRateBpm = respRateBpm
        self.sleepScore = sleepScore
        self.stages = stages
    }
}

/// One calendar day rolled up from a wearable export. `day` is the export's own calendar day
/// string (`YYYY-MM-DD`). Every metric is optional — a day only carries what the export recorded.
///
/// HONEST DATA: `readinessScore` (Oura) is THEIR score, kept for reference only — it is NEVER shown
/// as NOOP's Charge. NOOP recomputes its own scores downstream from the raw inputs (RHR / HRV /
/// sleep) that are present, exactly as it does for any imported source.
public struct WearableDailyRow: Sendable, Equatable {
    public var day: String

    // Activity
    public var steps: Int?
    public var distanceM: Double?
    public var activeKcal: Double?
    public var totalKcal: Double?

    // Heart / recovery inputs
    public var restingHr: Int?
    public var avgHrvMs: Double?
    public var respRateBpm: Double?   // night respiration (breaths/min) folded from the session, so it reaches the day rollup (#17)
    public var skinTempDevC: Double?  // Oura "temperature_deviation" (°C from baseline)
    public var spo2Pct: Double?
    public var avgStress: Int?        // Garmin daily average stress (0..100), reference
    public var vo2max: Double?        // Oura "vo2_max" (mL/kg/min); feeds Fitness Age, same as Apple Health VO2max

    // Sleep rollup (mirrors the night's session, for the daily metric)
    public var totalSleepMin: Double?
    public var deepMin: Double?
    public var lightMin: Double?
    public var remMin: Double?
    public var awakeMin: Double?
    public var efficiencyPct: Double?

    // The brand's OWN reference scores — stored under reference keys, never NOOP Charge/Effort/Rest.
    public var readinessScore: Int?   // Oura daily readiness (reference)
    public var sleepScore: Int?       // brand sleep score (reference)

    public init(day: String) {
        self.day = day
    }
}

/// Normalized output of parsing a wearable export (Oura / Fitbit / Garmin own-data export).
public struct WearableImportResult: Sendable, Equatable {
    public var brand: WearableBrand
    public var days: [WearableDailyRow]
    public var sleeps: [WearableSleepSession]
    public var summary: ImportSummary

    public init(brand: WearableBrand, days: [WearableDailyRow], sleeps: [WearableSleepSession], summary: ImportSummary) {
        self.brand = brand
        self.days = days
        self.sleeps = sleeps
        self.summary = summary
    }
}

// MARK: - Import results & summary

/// Lightweight summary of an import: how many normalized rows were produced and
/// the overall date span they cover.
public struct ImportSummary: Sendable, Equatable {
    public var sourceKind: DataSourceKind
    public var recordCount: Int
    public var earliest: Date?
    public var latest: Date?
    /// Per-category counts (e.g. `["HeartRate": 1200, "SleepAnalysis": 88]` for
    /// Apple Health, or `["cycles": 30, "workouts": 12]` for Whoop).
    public var countsByCategory: [String: Int]
    /// Number of XML spans dropped during a tolerant import: either a single
    /// hard parse error after which we kept the partial result (counts as 1), or
    /// the number of illegal-byte runs the pre-parse sanitizer scrubbed. Surfaced
    /// honestly in the UI so a partial import never silently looks complete.
    /// `0` for a fully clean import. Defaulted so other sources (Whoop) and older
    /// call sites stay source-compatible.
    public var skippedSpans: Int

    public init(
        sourceKind: DataSourceKind,
        recordCount: Int,
        earliest: Date?,
        latest: Date?,
        countsByCategory: [String: Int],
        skippedSpans: Int = 0
    ) {
        self.sourceKind = sourceKind
        self.recordCount = recordCount
        self.earliest = earliest
        self.latest = latest
        self.countsByCategory = countsByCategory
        self.skippedSpans = skippedSpans
    }
}

/// Normalized output of parsing an Apple Health export.
public struct AppleHealthImportResult: Sendable, Equatable {
    public var samples: [HealthSample]
    public var workouts: [HealthWorkout]
    public var sleepIntervals: [SleepStageInterval]
    public var summary: ImportSummary
    /// Pre-aggregated per-day sample rows, folded incrementally by the importer
    /// so a multi-year export never has to retain the raw `samples` array in RAM
    /// (issue #355). When the importer kept raw samples (`retainRawSamples:true`,
    /// the default) this is empty and `AppleHealthAggregator.aggregate` re-folds
    /// `samples`; when it dropped them (the app path) this carries the folded
    /// result and `samples` is empty. Defaulted to `[]` for source-compatibility
    /// with existing call sites that build a result from raw `samples`.
    public var sampleDailies: [AppleDailyAggregate]

    public init(
        samples: [HealthSample],
        workouts: [HealthWorkout],
        sleepIntervals: [SleepStageInterval],
        summary: ImportSummary,
        sampleDailies: [AppleDailyAggregate] = []
    ) {
        self.samples = samples
        self.workouts = workouts
        self.sleepIntervals = sleepIntervals
        self.summary = summary
        self.sampleDailies = sampleDailies
    }
}

/// Normalized output of parsing a Whoop CSV export bundle.
public struct WhoopImportResult: Sendable, Equatable {
    public var cycles: [WhoopCycleRow]
    public var sleeps: [WhoopSleepRow]
    public var workouts: [WhoopWorkoutRow]
    public var journal: [WhoopJournalRow]
    public var summary: ImportSummary

    public init(
        cycles: [WhoopCycleRow],
        sleeps: [WhoopSleepRow],
        workouts: [WhoopWorkoutRow],
        journal: [WhoopJournalRow],
        summary: ImportSummary
    ) {
        self.cycles = cycles
        self.sleeps = sleeps
        self.workouts = workouts
        self.journal = journal
        self.summary = summary
    }
}

// MARK: - Errors

public enum ImportError: Error, Equatable, Sendable, CustomStringConvertible, LocalizedError {
    case fileNotFound(String)
    case notAZipOrFolder(String)
    case missingEntry(String)
    case xmlParseFailed(String)
    case emptyExport(String)

    public var description: String {
        switch self {
        case .fileNotFound(let p):    return "File not found: \(p)"
        case .notAZipOrFolder(let p): return "Expected a folder or .zip: \(p)"
        case .missingEntry(let e):    return "Required entry not found: \(e)"
        case .xmlParseFailed(let m):  return "XML parse failed: \(m)"
        case .emptyExport(let m):     return "Export contained no usable data: \(m)"
        }
    }

    /// Honest, human-readable failure text surfaced in the import UI. Without this the enum bridges to
    /// NSError positionally and the user sees an opaque "…ImportError erreur 4" with no clue what went
    /// wrong (#857). `LocalizedError.errorDescription` is what `Error.localizedDescription` returns, so
    /// the Data Sources screen now shows the same plain sentence `description` carries.
    public var errorDescription: String? { description }
}

import Foundation

/// Conversion at an external-data boundary must fail for an unrepresentable number, rather than
/// trap the process. Keep the caller's existing rounding policy for every representable value.
public enum ImportNumericSafety {
    public static func integer(
        _ value: Double?, rounding: FloatingPointRoundingRule = .towardZero
    ) -> Int? {
        guard let value else { return nil }
        return Int(exactly: value.rounded(rounding))
    }

    /// Keep valid fractional readings verbatim until their eventual display/storage conversion.
    static func integerValue(
        _ value: Double?, rounding: FloatingPointRoundingRule = .toNearestOrAwayFromZero
    ) -> Double? {
        integer(value, rounding: rounding) == nil ? nil : value
    }
}

import Foundation

// MARK: - Daily aggregate model

/// One day's worth of Apple Health metrics, bucketed by the sample's own local
/// day (`start` shifted by `tzOffsetMin`). Mirrors the per-day shape the app
/// stores and charts alongside Whoop.
///
/// All `*Min` fields are minutes; energies are kcal; heart rates are count/min;
/// `spo2Pct` is a 0–100 percentage; `vo2max` is mL/kg/min.
public struct AppleDailyAggregate: Equatable, Sendable {
    /// `yyyy-MM-dd` in the sample's own UTC offset (local civil day).
    public let day: String

    // Cardio / respiratory means
    public let restingHr: Double?
    public let hrvSDNN: Double?
    public let spo2Pct: Double?
    public let respRate: Double?

    // Heart-rate stream
    public let avgHr: Double?
    public let maxHr: Double?
    public let walkingHr: Double?

    // Activity / fitness
    public let steps: Double?
    public let activeKcal: Double?
    public let basalKcal: Double?
    public let vo2max: Double?

    // Body composition (daily latest)
    public let weightKg: Double?
    public let bodyFatPct: Double?
    public let leanMassKg: Double?
    public let bmi: Double?

    // Sleep (minutes per stage), keyed by the wake day
    public let asleepMin: Double?
    public let deepMin: Double?
    public let remMin: Double?
    public let coreMin: Double?
    public let awakeMin: Double?
    public let inBedMin: Double?

    public init(
        day: String,
        restingHr: Double? = nil,
        hrvSDNN: Double? = nil,
        spo2Pct: Double? = nil,
        respRate: Double? = nil,
        avgHr: Double? = nil,
        maxHr: Double? = nil,
        walkingHr: Double? = nil,
        steps: Double? = nil,
        activeKcal: Double? = nil,
        basalKcal: Double? = nil,
        vo2max: Double? = nil,
        weightKg: Double? = nil,
        bodyFatPct: Double? = nil,
        leanMassKg: Double? = nil,
        bmi: Double? = nil,
        asleepMin: Double? = nil,
        deepMin: Double? = nil,
        remMin: Double? = nil,
        coreMin: Double? = nil,
        awakeMin: Double? = nil,
        inBedMin: Double? = nil
    ) {
        self.day = day
        self.restingHr = restingHr
        self.hrvSDNN = hrvSDNN
        self.spo2Pct = spo2Pct
        self.respRate = respRate
        self.avgHr = avgHr
        self.maxHr = maxHr
        self.walkingHr = walkingHr
        self.steps = steps
        self.activeKcal = activeKcal
        self.basalKcal = basalKcal
        self.vo2max = vo2max
        self.weightKg = weightKg
        self.bodyFatPct = bodyFatPct
        self.leanMassKg = leanMassKg
        self.bmi = bmi
        self.asleepMin = asleepMin
        self.deepMin = deepMin
        self.remMin = remMin
        self.coreMin = coreMin
        self.awakeMin = awakeMin
        self.inBedMin = inBedMin
    }
}

// MARK: - Aggregator

/// Turns a parsed Apple Health export into per-day aggregates.
public enum AppleHealthAggregator {

    // MARK: Type identifiers
    //
    // `HealthSample.type` is stored with the `HKQuantityTypeIdentifier` /
    // `HKCategoryTypeIdentifier` prefix already stripped (see
    // `AppleHealthImporter.stripPrefix`). We still accept the full identifier
    // form so callers feeding raw HK strings get the same mapping.

    static let restingHR = "RestingHeartRate"
    static let hrvSDNN = "HeartRateVariabilitySDNN"
    static let spo2 = "OxygenSaturation"
    static let respRate = "RespiratoryRate"
    static let walkingHR = "WalkingHeartRateAverage"
    static let heartRate = "HeartRate"
    static let stepCount = "StepCount"
    static let activeEnergy = "ActiveEnergyBurned"
    static let basalEnergy = "BasalEnergyBurned"
    static let vo2max = "VO2Max"
    static let bodyMass = "BodyMass"
    static let bodyFat = "BodyFatPercentage"
    static let leanMass = "LeanBodyMass"
    static let bodyMassIndex = "BodyMassIndex"

    /// Normalize a sample's `type` to the stripped HK identifier so matching
    /// works whether the caller passed `HeartRate` or
    /// `HKQuantityTypeIdentifierHeartRate`.
    static func normalizedType(_ raw: String) -> String {
        let prefixes = [
            "HKQuantityTypeIdentifier",
            "HKCategoryTypeIdentifier",
            "HKDataTypeIdentifier",
        ]
        for p in prefixes where raw.hasPrefix(p) {
            return String(raw.dropFirst(p.count))
        }
        return raw
    }

    /// Whether a HealthKit mass unit string denotes pounds (`lb`, `lbs`).
    /// HealthKit normally exports BodyMass/LeanBodyMass in kg, but guard against
    /// pound-denominated exports.
    static func unitLooksLikePounds(_ unit: String?) -> Bool {
        guard let u = unit?.lowercased() else { return false }
        return u == "lb" || u == "lbs" || u.contains("pound")
    }

    // MARK: Day bucketing

    /// `yyyy-MM-dd` for a UTC `Date` shifted into its own local offset.
    /// We add the offset to the UTC instant and read the calendar fields in
    /// UTC, which yields the civil (wall-clock) date the sample was recorded on.
    static func localDay(_ utc: Date, tzOffsetMin: Int) -> String {
        let shifted = utc.addingTimeInterval(TimeInterval(tzOffsetMin * 60))
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(identifier: "UTC")!
        let c = cal.dateComponents([.year, .month, .day], from: shifted)
        return String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
    }

    // MARK: - Sample daily aggregation

    /// Group `HealthSamples` by local day and apply the per-type reduction rules.
    ///
    /// This is the **batch** form. It is a thin wrapper over
    /// `AppleDailySampleAccumulator` so the running (incremental) fold and the
    /// batch fold share ONE set of reduction rules — the accumulator is the
    /// single source of truth. The streaming importer feeds samples one-by-one
    /// into the same accumulator so a multi-year export never has to hold the raw
    /// `[HealthSample]` array in RAM.
    public static func daily(samples: [HealthSample]) -> [AppleDailyAggregate] {
        var acc = AppleDailySampleAccumulator()
        for s in samples { acc.add(s) }
        return acc.finish()
    }

    // MARK: - Sleep daily aggregation

    /// Non-overlapping episode totals keyed by the whole episode's final local wake day.
    /// XML and live HealthKit both use `AppleSleepEpisodeReducer`; raw intervals stay unchanged.
    public static func sleepDaily(
        _ intervals: [SleepStageInterval]
    ) -> [String: (asleep: Double, deep: Double, rem: Double, core: Double, awake: Double, inBed: Double)] {
        sleepReduction(intervals).totals
    }

    private typealias SleepTotals = (asleep: Double, deep: Double, rem: Double, core: Double, awake: Double, inBed: Double)

    private static func sleepReduction(_ intervals: [SleepStageInterval])
        -> (totals: [String: SleepTotals], observedAsleepDays: Set<String>,
            observedAwakeDays: Set<String>, observedInBedDays: Set<String>) {
        var output: [String: SleepTotals] = [:]
        var observedAsleepDays: Set<String> = []
        var observedAwakeDays: Set<String> = []
        var observedInBedDays: Set<String> = []
        for episode in AppleSleepEpisodeReducer.reduce(intervals) {
            if episode.hasAsleepEvidence { observedAsleepDays.insert(episode.wakeDay) }
            if episode.hasAwakeEvidence { observedAwakeDays.insert(episode.wakeDay) }
            if episode.inBed > 0 { observedInBedDays.insert(episode.wakeDay) }
            let prior = output[episode.wakeDay] ?? (0, 0, 0, 0, 0, 0)
            output[episode.wakeDay] = (prior.asleep + episode.asleep, prior.deep + episode.deep,
                                       prior.rem + episode.rem, prior.core + episode.core,
                                       prior.awake + episode.awake, prior.inBed + episode.inBed)
        }
        // Preserve the legacy zero-valued unknown-stage day without letting unknown evidence
        // connect, extend, or choose the wake timezone of a real sleep episode.
        for interval in intervals where interval.stage == .unknown {
            let duration = interval.end.timeIntervalSince(interval.start)
            guard duration.isFinite, duration > 0, duration <= 24 * 60 * 60 else { continue }
            let day = localDay(interval.end, tzOffsetMin: interval.tzOffsetMin)
            if output[day] == nil { output[day] = (0, 0, 0, 0, 0, 0) }
        }
        return (output, observedAsleepDays, observedAwakeDays, observedInBedDays)
    }

    // MARK: - Full merge

    /// Full merge of sample-daily + sleep-daily into `[AppleDailyAggregate]`,
    /// one row per day present in either source, sorted ascending by day.
    public static func aggregate(_ result: AppleHealthImportResult) -> [AppleDailyAggregate] {
        // When the importer pre-aggregated the samples incrementally (bounded
        // memory — issue #355), `sampleDailies` is already populated and the raw
        // `samples` array may have been dropped. Use the pre-aggregated form in
        // that case; otherwise fall back to folding the raw samples here (the
        // path tests take when they construct a result from raw `samples`). An
        // empty export leaves both empty → daily([]) → [] — fine.
        let sampleDaily = result.sampleDailies.isEmpty
            ? daily(samples: result.samples)
            : result.sampleDailies
        let sleepResult = sleepReduction(result.sleepIntervals)
        let sleep = sleepResult.totals

        var byDay: [String: AppleDailyAggregate] = [:]
        for d in sampleDaily { byDay[d.day] = d }

        // Union of days from both sources.
        var days = Set(byDay.keys)
        days.formUnion(sleep.keys)

        let merged: [AppleDailyAggregate] = days.map { day in
            let base = byDay[day]
            let s = sleep[day]
            let observedAsleep = sleepResult.observedAsleepDays.contains(day)
            return AppleDailyAggregate(
                day: day,
                restingHr: base?.restingHr,
                hrvSDNN: base?.hrvSDNN,
                spo2Pct: base?.spo2Pct,
                respRate: base?.respRate,
                avgHr: base?.avgHr,
                maxHr: base?.maxHr,
                walkingHr: base?.walkingHr,
                steps: base?.steps,
                activeKcal: base?.activeKcal,
                basalKcal: base?.basalKcal,
                vo2max: base?.vo2max,
                weightKg: base?.weightKg,
                bodyFatPct: base?.bodyFatPct,
                leanMassKg: base?.leanMassKg,
                bmi: base?.bmi,
                asleepMin: observedAsleep ? s?.asleep : nil,
                deepMin: observedAsleep ? s?.deep : nil,
                remMin: observedAsleep ? s?.rem : nil,
                coreMin: observedAsleep ? s?.core : nil,
                awakeMin: sleepResult.observedAwakeDays.contains(day) ? s?.awake : nil,
                inBedMin: sleepResult.observedInBedDays.contains(day) ? s?.inBed : nil
            )
        }
        return merged.sorted { $0.day < $1.day }
    }

    // MARK: - Metric point flattening

    /// Flatten daily aggregates into generic `(day, key, value)` metric points
    /// for the metricSeries store. Only present (non-nil) values are emitted.
    /// Keys are stable, snake_case identifiers.
    public static func metricPoints(_ daily: [AppleDailyAggregate]) -> [(day: String, key: String, value: Double)] {
        var out: [(day: String, key: String, value: Double)] = []
        for d in daily {
            func add(_ key: String, _ value: Double?) {
                if let v = value { out.append((day: d.day, key: key, value: v)) }
            }
            add("resting_hr", d.restingHr)
            add("hrv", d.hrvSDNN)
            add("spo2", d.spo2Pct)
            add("resp_rate", d.respRate)
            add("avg_hr", d.avgHr)
            add("max_hr", d.maxHr)
            add("walking_hr", d.walkingHr)
            add("steps", d.steps)
            add("active_kcal", d.activeKcal)
            add("basal_kcal", d.basalKcal)
            add("vo2max", d.vo2max)
            add("weight", d.weightKg)
            add("body_fat", d.bodyFatPct)
            add("lean_mass", d.leanMassKg)
            add("bmi", d.bmi)
            add("asleep_min", d.asleepMin)
            add("deep_min", d.deepMin)
            add("rem_min", d.remMin)
            add("core_min", d.coreMin)
            add("awake_min", d.awakeMin)
            add("in_bed_min", d.inBedMin)
        }
        return out
    }
}

// MARK: - Incremental (bounded-memory) sample accumulator

/// A running, O(days)-memory accumulator that produces output **identical** to
/// `AppleHealthAggregator.daily(samples:)` without ever holding the raw
/// `[HealthSample]` array.
///
/// WHY this exists (issue #355): a multi-year Apple Health export with
/// Apple-Watch continuous heart-rate is millions of `HealthSample` structs —
/// hundreds of MB to >1 GB — which iOS jetsam-kills mid-import. The streaming
/// SAX importer feeds each parsed sample straight into this accumulator and (on
/// the app path) drops the raw struct, so peak memory is bounded to the number
/// of distinct civil days, not the number of samples.
///
/// It mirrors `daily(samples:)` EXACTLY: same `normalizedType` + per-type switch,
/// the same spo2/bodyFat fraction (0..1→percent) guards, the same pounds→kg unit
/// check, the same "latest by `end`" rule for vo2/weight/bodyFat/lean/bmi, the
/// same first-seen-day order preservation, and the same final
/// `sorted { $0.day < $1.day }`. `daily(samples:)` is implemented as a thin loop
/// over this type, so the existing `AppleHealthAggregatorTests` keep validating
/// both the batch and incremental paths at once.
public struct AppleDailySampleAccumulator {

    /// Per-day running state. Means are kept as (sum, count) — no per-sample
    /// arrays — and max as a running maximum, so memory is O(days).
    private struct DayAcc {
        // Means: running sum + count.
        var restingSum = 0.0; var restingN = 0
        var hrvSum = 0.0;     var hrvN = 0
        var spo2Sum = 0.0;    var spo2N = 0
        var respSum = 0.0;    var respN = 0
        var walkingSum = 0.0; var walkingN = 0
        var hrSum = 0.0;      var hrN = 0
        // HeartRate max (running).
        var hrMax: Double?
        // Sums + presence flags.
        // #589: per-SOURCE step sums. Apple Health keeps overlapping step samples from EACH device
        // (an iPhone AND an Apple Watch both count the same walk); summing across sources double-counts
        // (~2x). We sum WITHIN a source but take the MAX source per day at finish() — the de-overlap
        // Apple's own Health app shows instead of a raw sum.
        var stepsBySource: [String: Double] = [:]
        var active = 0.0; var hasActive = false
        var basal = 0.0;  var hasBasal = false
        // Latest-by-end values.
        var vo2: Double?;     var vo2At: Date?
        var weight: Double?;  var weightAt: Date?
        var bodyFat: Double?; var bodyFatAt: Date?
        var lean: Double?;    var leanAt: Date?
        var bmi: Double?;     var bmiAt: Date?
    }

    private var byDay: [String: DayAcc] = [:]
    /// Preserve first-seen day order for deterministic output before the sort
    /// (mirrors `daily(samples:)`'s `order` array).
    private var order: [String] = []

    public init() {}

    /// Fold one sample into the running per-day state. Applies the SAME
    /// reduction rules as `AppleHealthAggregator.daily(samples:)`.
    public mutating func add(_ s: HealthSample) {
        let type = AppleHealthAggregator.normalizedType(s.type)
        if let value = s.value {
            // A malformed XML number must not poison a day's means or trap an integer-backed
            // heart-rate/step projection. Valid fractional readings keep the same reduction rules.
            guard value.isFinite else { return }
            switch type {
            case AppleHealthAggregator.restingHR, AppleHealthAggregator.walkingHR, AppleHealthAggregator.heartRate:
                guard ImportNumericSafety.integer(value, rounding: .toNearestOrAwayFromZero) != nil else { return }
            case AppleHealthAggregator.stepCount:
                guard ImportNumericSafety.integer(value) != nil else { return }
            default: break
            }
        }
        let day = AppleHealthAggregator.localDay(s.start, tzOffsetMin: s.tzOffsetMin)
        if byDay[day] == nil {
            byDay[day] = DayAcc()
            order.append(day)
        }

        switch type {
        case AppleHealthAggregator.restingHR:
            if let v = s.value { byDay[day]!.restingSum += v; byDay[day]!.restingN += 1 }
        case AppleHealthAggregator.hrvSDNN:
            if let v = s.value { byDay[day]!.hrvSum += v; byDay[day]!.hrvN += 1 }
        case AppleHealthAggregator.spo2:
            if let v = s.value {
                // Detect fraction (0..1) → percent. The importer already scales
                // OxygenSaturation by 100, but defend against raw fractional
                // values here too. (Identical to daily().)
                let pct = (v > 0 && v <= 1.0) ? v * 100.0 : v
                byDay[day]!.spo2Sum += pct; byDay[day]!.spo2N += 1
            }
        case AppleHealthAggregator.respRate:
            if let v = s.value { byDay[day]!.respSum += v; byDay[day]!.respN += 1 }
        case AppleHealthAggregator.walkingHR:
            if let v = s.value { byDay[day]!.walkingSum += v; byDay[day]!.walkingN += 1 }
        case AppleHealthAggregator.heartRate:
            if let v = s.value {
                byDay[day]!.hrSum += v; byDay[day]!.hrN += 1
                if let m = byDay[day]!.hrMax { byDay[day]!.hrMax = Swift.max(m, v) }
                else { byDay[day]!.hrMax = v }
            }
        case AppleHealthAggregator.stepCount:
            // Sum WITHIN a source, never across sources (iPhone + Watch overlap → double-count). (#589)
            if let v = s.value { byDay[day]!.stepsBySource[s.sourceName ?? "", default: 0] += v }
        case AppleHealthAggregator.activeEnergy:
            if let v = s.value { byDay[day]!.active += v; byDay[day]!.hasActive = true }
        case AppleHealthAggregator.basalEnergy:
            if let v = s.value { byDay[day]!.basal += v; byDay[day]!.hasBasal = true }
        case AppleHealthAggregator.vo2max:
            if let v = s.value {
                let acc = byDay[day]!
                if acc.vo2 == nil || (acc.vo2At ?? .distantPast) <= s.end {
                    byDay[day]!.vo2 = v
                    byDay[day]!.vo2At = s.end
                }
            }
        case AppleHealthAggregator.bodyMass:
            if let v = s.value {
                // HealthKit stores BodyMass in kg by default. If the unit looks
                // like pounds, convert to kg; otherwise assume kg.
                let kg = AppleHealthAggregator.unitLooksLikePounds(s.unit) ? v * 0.453592 : v
                let acc = byDay[day]!
                if acc.weight == nil || (acc.weightAt ?? .distantPast) <= s.end {
                    byDay[day]!.weight = kg
                    byDay[day]!.weightAt = s.end
                }
            }
        case AppleHealthAggregator.bodyFat:
            if let v = s.value {
                // HealthKit stores a 0..1 fraction → percent. Defend against
                // already-percent values the same way SpO2 does.
                let pct = (v > 0 && v <= 1.0) ? v * 100.0 : v
                let acc = byDay[day]!
                if acc.bodyFat == nil || (acc.bodyFatAt ?? .distantPast) <= s.end {
                    byDay[day]!.bodyFat = pct
                    byDay[day]!.bodyFatAt = s.end
                }
            }
        case AppleHealthAggregator.leanMass:
            if let v = s.value {
                let kg = AppleHealthAggregator.unitLooksLikePounds(s.unit) ? v * 0.453592 : v
                let acc = byDay[day]!
                if acc.lean == nil || (acc.leanAt ?? .distantPast) <= s.end {
                    byDay[day]!.lean = kg
                    byDay[day]!.leanAt = s.end
                }
            }
        case AppleHealthAggregator.bodyMassIndex:
            if let v = s.value {
                let acc = byDay[day]!
                if acc.bmi == nil || (acc.bmiAt ?? .distantPast) <= s.end {
                    byDay[day]!.bmi = v
                    byDay[day]!.bmiAt = s.end
                }
            }
        default:
            break
        }
    }

    /// Emit the per-day aggregates (mean = sum/count, running max, sums, latest),
    /// in first-seen order then sorted ascending by day — identical to
    /// `daily(samples:)`.
    public func finish() -> [AppleDailyAggregate] {
        func mean(_ sum: Double, _ n: Int) -> Double? { n == 0 ? nil : sum / Double(n) }

        let result: [AppleDailyAggregate] = order.map { day in
            let a = byDay[day]!
            return AppleDailyAggregate(
                day: day,
                restingHr: mean(a.restingSum, a.restingN),
                hrvSDNN: mean(a.hrvSum, a.hrvN),
                spo2Pct: mean(a.spo2Sum, a.spo2N),
                respRate: mean(a.respSum, a.respN),
                avgHr: mean(a.hrSum, a.hrN),
                maxHr: a.hrMax,
                walkingHr: mean(a.walkingSum, a.walkingN),
                // #589: maximum source, not cross-source sum. Individually representable entries
                // may still overflow the integer-backed daily total when combined.
                steps: ImportNumericSafety.integerValue(a.stepsBySource.values.max(), rounding: .towardZero),
                activeKcal: a.hasActive ? a.active : nil,
                basalKcal: a.hasBasal ? a.basal : nil,
                vo2max: a.vo2,
                weightKg: a.weight,
                bodyFatPct: a.bodyFat,
                leanMassKg: a.lean,
                bmi: a.bmi
            )
        }
        return result.sorted { $0.day < $1.day }
    }
}

import Foundation

/// Common XML/live-HealthKit sleep policy. Durations use absolute instants. A gap of at most
/// 30 minutes keeps stages in one episode; gaps add no sleep. Separate naps remain separate episodes
/// and contribute to their wake day's daily total. This does not alter any stored raw evidence.
public enum AppleSleepEpisodeReducer {
    public static let maximumStageGap: TimeInterval = 30 * 60

    public struct Episode: Equatable, Sendable {
        public let start: Date
        public let end: Date
        public let wakeDay: String
        /// Distinguishes a measured zero (sleep evidence overridden by awake) from in-bed-only input.
        public let hasAsleepEvidence: Bool
        public let hasAwakeEvidence: Bool
        public let asleep: Double
        public let deep: Double
        public let rem: Double
        public let core: Double
        public let awake: Double
        /// Union of in-bed envelopes. This companion metric may overlap sleep; it is never added to it.
        public let inBed: Double
    }

    /// Keeps only an unfinished episode across bounded HealthKit query chunks. Overlap queries can
    /// repeat objects; exact interval/source/identity duplicates do not change the result.
    public struct Accumulator {
        private var pending: [SleepStageInterval] = []
        public init() {}

        public mutating func ingest(_ intervals: [SleepStageInterval], through boundary: Date) -> [Episode] {
            let groups = AppleSleepEpisodeReducer.groups(pending + intervals)
            var complete: [Episode] = []
            pending = []
            for group in groups {
                if group.map(\.end).max()!.addingTimeInterval(maximumStageGap) < boundary {
                    complete.append(AppleSleepEpisodeReducer.reduceGroup(group))
                } else {
                    pending.append(contentsOf: group)
                }
            }
            return complete
        }

        public mutating func finish() -> [Episode] {
            let result = AppleSleepEpisodeReducer.reduce(pending)
            pending = []
            return result
        }
    }

    public static func reduce(_ intervals: [SleepStageInterval]) -> [Episode] {
        groups(intervals).map(reduceGroup)
    }

    private static func groups(_ intervals: [SleepStageInterval]) -> [[SleepStageInterval]] {
        let valid = Set(intervals.filter {
            let duration = $0.end.timeIntervalSince($0.start)
            return $0.start.timeIntervalSince1970.isFinite && $0.end.timeIntervalSince1970.isFinite
                && duration > 0 && duration <= 24 * 60 * 60 && $0.stage != .unknown
        }).sorted(by: chronologicalOrder)
        // In-bed envelopes are a companion stream, never proof that two separate sleep nights
        // form one episode. A broad third-party bed envelope must not move both nights to its end.
        return (partition(valid.filter { $0.stage != .inBed })
                + partition(valid.filter { $0.stage == .inBed }))
            .sorted { chronologicalOrder($0[0], $1[0]) }
    }

    private static func partition(_ intervals: [SleepStageInterval]) -> [[SleepStageInterval]] {
        var groups: [[SleepStageInterval]] = []
        var current: [SleepStageInterval] = []
        var end = Date.distantPast
        for interval in intervals {
            if !current.isEmpty && interval.start.timeIntervalSince(end) > maximumStageGap {
                groups.append(current)
                current = []
            }
            current.append(interval)
            end = current.count == 1 ? interval.end : max(end, interval.end)
        }
        if !current.isEmpty { groups.append(current) }
        return groups
    }

    private static func chronologicalOrder(_ lhs: SleepStageInterval, _ rhs: SleepStageInterval) -> Bool {
        if lhs.start != rhs.start { return lhs.start < rhs.start }
        if lhs.end != rhs.end { return lhs.end < rhs.end }
        if sourceKey(lhs) != sourceKey(rhs) { return sourceKey(lhs) < sourceKey(rhs) }
        if lhs.stage != rhs.stage { return lhs.stage.rawValue < rhs.stage.rawValue }
        if lhs.tzOffsetMin != rhs.tzOffsetMin { return lhs.tzOffsetMin < rhs.tzOffsetMin }
        return (lhs.sampleID ?? "") < (rhs.sampleID ?? "")
    }

    private static func sourceKey(_ interval: SleepStageInterval) -> String {
        (interval.sourceName ?? "") + "\u{0}" + (interval.sourceIdentifier ?? "")
    }

    private static func rank(_ stage: SleepStage) -> Int {
        switch stage {
        case .asleepCore, .asleepDeep, .asleepREM, .awake: return 2
        case .asleepUnspecified: return 1
        case .inBed, .unknown: return 0
        }
    }

    private static func reduceGroup(_ intervals: [SleepStageInterval]) -> Episode {
        let start = intervals.map(\.start).min()!
        let end = intervals.map(\.end).max()!
        // At a tied final instant, detailed evidence wins, then stable source/interval order. The
        // chosen final interval supplies the recorded wake offset, including DST and travel changes.
        let wake = intervals.sorted {
            if $0.end != $1.end { return $0.end > $1.end }
            if rank($0.stage) != rank($1.stage) { return rank($0.stage) > rank($1.stage) }
            return chronologicalOrder($0, $1)
        }.first!
        var totals: [SleepStage: Double] = [:]
        var inBed = 0.0
        let boundaries = Array(Set(intervals.flatMap { [$0.start, $0.end] })).sorted()
        // Prefer detailed stages to unspecified summaries. If detailed sources disagree, choose
        // the source with most detailed coverage in this episode, then its stable source identity.
        // This is deterministic arbitration, not a claim that one device measures sleep better.
        let detailed = Dictionary(grouping: intervals.filter { rank($0.stage) == 2 }, by: sourceKey)
        let sourceCoverage = detailed.mapValues { values -> TimeInterval in
            var duration = 0.0
            var lastEnd = Date.distantPast
            for interval in values.sorted(by: chronologicalOrder) {
                duration += max(0, interval.end.timeIntervalSince(max(interval.start, lastEnd)))
                lastEnd = max(lastEnd, interval.end)
            }
            return duration
        }
        struct Event { let instant: Date; let index: Int; let isStart: Bool }
        let events = intervals.enumerated().flatMap { index, interval in
            [Event(instant: interval.start, index: index, isStart: true),
             Event(instant: interval.end, index: index, isStart: false)]
        }.sorted { $0.instant < $1.instant }
        var active: Set<Int> = []
        var eventIndex = 0
        for (left, right) in zip(boundaries, boundaries.dropFirst()) {
            while eventIndex < events.count && events[eventIndex].instant <= left {
                let event = events[eventIndex]
                if event.isStart { active.insert(event.index) } else { active.remove(event.index) }
                eventIndex += 1
            }
            let minutes = right.timeIntervalSince(left) / 60
            if active.contains(where: { intervals[$0].stage == .inBed }) { inBed += minutes }
            let selected = active.map { intervals[$0] }.filter { rank($0.stage) > 0 }.sorted {
                if rank($0.stage) != rank($1.stage) { return rank($0.stage) > rank($1.stage) }
                let lCoverage = sourceCoverage[sourceKey($0)] ?? 0
                let rCoverage = sourceCoverage[sourceKey($1)] ?? 0
                if lCoverage != rCoverage { return lCoverage > rCoverage }
                if sourceKey($0) != sourceKey($1) { return sourceKey($0) < sourceKey($1) }
                return chronologicalOrder($0, $1)
            }.first
            if let selected { totals[selected.stage, default: 0] += minutes }
        }
        let core = totals[.asleepCore] ?? 0, deep = totals[.asleepDeep] ?? 0, rem = totals[.asleepREM] ?? 0
        return Episode(start: start, end: end,
                       wakeDay: AppleHealthAggregator.localDay(end, tzOffsetMin: wake.tzOffsetMin),
                       hasAsleepEvidence: intervals.contains { interval in
                           switch interval.stage {
                           case .asleepCore, .asleepDeep, .asleepREM, .asleepUnspecified: return true
                           default: return false
                           }
                       },
                       hasAwakeEvidence: intervals.contains { $0.stage == .awake },
                       asleep: core + deep + rem + (totals[.asleepUnspecified] ?? 0),
                       deep: deep, rem: rem, core: core, awake: totals[.awake] ?? 0, inBed: inBed)
    }
}

import Foundation

// MARK: - UTF-8 BOM handling

enum BOM {
    /// Strip a leading UTF-8 byte-order-mark (EF BB BF) from raw bytes.
    static func stripUTF8(_ data: Data) -> Data {
        guard data.count >= 3,
              data[data.startIndex] == 0xEF,
              data[data.startIndex + 1] == 0xBB,
              data[data.startIndex + 2] == 0xBF
        else { return data }
        return data.subdata(in: (data.startIndex + 3)..<data.endIndex)
    }

    /// Strip a leading BOM from a decoded string (covers the case where the
    /// bytes were already decoded and the BOM survived as U+FEFF).
    static func stripString(_ s: String) -> String {
        if s.hasPrefix("\u{FEFF}") { return String(s.dropFirst()) }
        return s
    }
}

// MARK: - Header normalization

enum HeaderNorm {
    /// Normalize a CSV header to a stable lookup key.
    ///
    /// lowercase, `%`→`pct`, drop parens (keep inner content), collapse runs of
    /// non-alphanumerics to `_`, trim `_`. Mirrors the reference Python parser so
    /// the same field aliases apply.
    ///   "Heart rate variability (ms)" -> "heart_rate_variability_ms"
    ///   "Recovery score %"            -> "recovery_score_pct"
    static func normalize(_ header: String) -> String {
        // Fold diacritics first so localized headers normalize deterministically regardless of
        // NFC/NFD form (ä→a, ö→o, ü→u). English headers are unaffected. (issue #3)
        var s = header.folding(options: .diacriticInsensitive, locale: Locale(identifier: "en_US_POSIX"))
            .lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        s = s.replacingOccurrences(of: "%", with: "pct")
        var out = ""
        out.reserveCapacity(s.count)
        var lastWasUnderscore = false
        for ch in s {
            if ch.isLetter || ch.isNumber, ch.isASCII {
                out.append(ch)
                lastWasUnderscore = false
            } else {
                // Any non-alphanumeric (including parens, spaces, slashes, etc.)
                // becomes a single underscore.
                if !lastWasUnderscore {
                    out.append("_")
                    lastWasUnderscore = true
                }
            }
        }
        // Trim leading/trailing underscores.
        while out.hasPrefix("_") { out.removeFirst() }
        while out.hasSuffix("_") { out.removeLast() }
        // Map localized column headers onto their canonical English keys so the parsers
        // (which look up English keys) find the values. (issue #3)
        return foreignAliases[out] ?? out
    }

    /// Localized WHOOP export column headers → canonical English normalized keys. Keys are the
    /// diacritic-folded normalized form of the foreign header. German added from a real export
    /// (issue #3, headers supplied by the reporter); more languages can be appended here.
    static let foreignAliases: [String: String] = [
        // — German (physiologische_zyklen / Schlaf / Trainings / logbuch_eintraege) —
        "startzeit_des_zyklus": "cycle_start_time",
        "endzeit_des_zyklus": "cycle_end_time",
        "zeitzone_des_zyklus": "cycle_timezone",
        "erholungswert_pct": "recovery_score_pct",
        "ruheherzfrequenz_schlage_pro_minute": "resting_heart_rate_bpm",
        "herzfrequenzvariabilitat_ms": "heart_rate_variability_ms",
        "hauttemperatur_celsius": "skin_temp_celsius",
        "blutsauerstoff_pct": "blood_oxygen_pct",
        "tagesbelastung": "day_strain",
        "verbrannte_energie_cal": "energy_burned_cal",
        "max_hf_schlage_pro_minute": "max_hr_bpm",
        "durchschnittliche_hf_schlage_pro_minute": "average_hr_bpm",
        "beginn_des_schlafs": "sleep_onset",
        "beginn_des_aufwachens": "wake_onset",
        "schlafleistung_pct": "sleep_performance_pct",
        "atemfrequenz_atemzuge_min": "respiratory_rate_rpm",
        "schlafdauer_min": "asleep_duration_min",
        "dauer_im_bett_min": "in_bed_duration_min",
        "dauer_des_leichtschlafs_min": "light_sleep_duration_min",
        "dauer_des_tiefschlafs_min": "deep_sws_duration_min",
        "dauer_des_rem_schlafs_min": "rem_duration_min",
        "dauer_des_aufwachens_min": "awake_duration_min",
        "schlafbedarf_min": "sleep_need_min",
        "schlafdefizit_min": "sleep_debt_min",
        "schlafeffizienz_pct": "sleep_efficiency_pct",
        "schlafbestandigkeit_pct": "sleep_consistency_pct",
        "nickerchen": "nap",
        "startzeit_des_trainings": "workout_start_time",
        "endzeit_des_trainings": "workout_end_time",
        "name_der_aktivitat": "activity_name",
        "aktivitatsbelastung": "activity_strain",
        "hf_zone_1_pct": "hr_zone_1_pct",
        "hf_zone_2_pct": "hr_zone_2_pct",
        "hf_zone_3_pct": "hr_zone_3_pct",
        "hf_zone_4_pct": "hr_zone_4_pct",
        "hf_zone_5_pct": "hr_zone_5_pct",
        "fragetext": "question_text",
        "beantwortet_mit_ja": "answered_yes_no",
        "anmerkungen": "notes",
        // — Spanish (physiological_cycles keeps its English filename but Spanish columns / sueño.csv /
        //   entrenamientos.csv). Headers supplied by a real export (issue #76). —
        "hora_de_inicio_del_ciclo": "cycle_start_time",
        "hora_de_finalizacion_del_ciclo": "cycle_end_time",
        "zona_horaria_del_ciclo": "cycle_timezone",
        "puntuacion_de_recuperacion_pct": "recovery_score_pct",
        "frecuencia_cardiaca_en_reposo_lpm": "resting_heart_rate_bpm",
        "variabilidad_de_la_frecuencia_cardiaca_ms": "heart_rate_variability_ms",
        "temp_cutanea_grados_centigrados": "skin_temp_celsius",
        "oxigeno_en_sangre_pct": "blood_oxygen_pct",
        "esfuerzo_del_dia": "day_strain",
        "energia_quemada_cal": "energy_burned_cal",
        "fc_max_lpm": "max_hr_bpm",
        "fc_promedio_lpm": "average_hr_bpm",
        "inicio_del_sueno": "sleep_onset",
        "inicio_de_la_vigilia": "wake_onset",
        "calificacion_del_sueno_pct": "sleep_performance_pct",
        "frecuencia_respiratoria_rpm": "respiratory_rate_rpm",
        "duracion_del_sueno_min": "asleep_duration_min",
        "tiempo_en_la_cama_min": "in_bed_duration_min",
        "duracion_de_sueno_ligero_min": "light_sleep_duration_min",
        "duracion_de_sueno_profundo_sws_min": "deep_sws_duration_min",
        "duracion_de_sueno_rem_min": "rem_duration_min",
        "tempo_despierto_a_min": "awake_duration_min",       // WHOOP's es export reads "Tempo despierto/a"
        "sueno_necesario_min": "sleep_need_min",
        "deuda_de_sueno_min": "sleep_debt_min",
        "eficiencia_del_sueno_pct": "sleep_efficiency_pct",
        "regularidad_del_sueno_pct": "sleep_consistency_pct",
        "siesta": "nap",
        // Workout columns inferred from WHOOP's consistent es naming (a real entrenamientos.csv header
        // would confirm); harmless if a name differs — an unmatched alias simply never fires.
        "hora_de_inicio_del_entrenamiento": "workout_start_time",
        "hora_de_finalizacion_del_entrenamiento": "workout_end_time",
        "nombre_de_la_actividad": "activity_name",
        "esfuerzo_de_la_actividad": "activity_strain",
        // — French (physiological_cycles keeps its English filename; sommeil.csv / entrainements.csv).
        //   Full header set incl. workouts, from a real export (issue #79). Apostrophes (' or ’) and the
        //   non-breaking space before % both fold to "_" in normalize, so these keys are exact. —
        "heure_de_debut_du_cycle": "cycle_start_time",
        "heure_de_fin_du_cycle": "cycle_end_time",
        "fuseau_horaire_du_cycle": "cycle_timezone",
        "score_de_recuperation_pct": "recovery_score_pct",
        "frequence_cardiaque_au_repos_bpm": "resting_heart_rate_bpm",
        "variabilite_de_la_frequence_cardiaque_ms": "heart_rate_variability_ms",
        "temperature_cutanee_celsius": "skin_temp_celsius",
        "niveau_d_oxygene_pct": "blood_oxygen_pct",
        "effort_du_jour": "day_strain",
        "depense_energetique_cal": "energy_burned_cal",
        "fc_max_bpm": "max_hr_bpm",
        "fc_moyenne_bpm": "average_hr_bpm",
        "premiers_signes_de_sommeil": "sleep_onset",
        "premiers_signes_de_reveil": "wake_onset",
        "performance_sommeil_pct": "sleep_performance_pct",
        "frequence_respiratoire_tr_min": "respiratory_rate_rpm",
        "duree_du_sommeil_min": "asleep_duration_min",
        "temps_passe_au_lit_min": "in_bed_duration_min",
        "duree_du_sommeil_leger_min": "light_sleep_duration_min",
        "duree_du_sommeil_profond_min": "deep_sws_duration_min",
        "duree_du_sommeil_paradoxal_min": "rem_duration_min",      // paradoxal = REM
        "temps_d_eveil_min": "awake_duration_min",
        "besoins_en_sommeil_min": "sleep_need_min",
        "dette_de_sommeil_min": "sleep_debt_min",
        "efficacite_du_sommeil_pct": "sleep_efficiency_pct",
        "regularite_du_sommeil_pct": "sleep_consistency_pct",
        "sieste": "nap",
        "heure_de_debut_de_l_entrainement": "workout_start_time",
        "heure_de_fin_de_l_entrainement": "workout_end_time",
        "nom_de_l_activite": "activity_name",
        "effort_activite": "activity_strain",
        "zone_fc_1_pct": "hr_zone_1_pct",
        "zone_fc_2_pct": "hr_zone_2_pct",
        "zone_fc_3_pct": "hr_zone_3_pct",
        "zone_fc_4_pct": "hr_zone_4_pct",
        "zone_fc_5_pct": "hr_zone_5_pct",
        // — Brazilian Portuguese (ciclos_fisiológicos / sonos / treinos / entradas_diário), issue #692.
        //   Full header set across cycles, sleeps, workouts and journal, from a real pt-BR export. Note
        //   "FC máx." folds to the same key as the French "FC max." alias above, and a Swift dictionary
        //   literal traps on a duplicate key, so it is deliberately NOT repeated here. —
        "hora_de_inicio_do_ciclo": "cycle_start_time",
        "hora_de_fim_do_ciclo": "cycle_end_time",
        "fuso_horario_do_ciclo": "cycle_timezone",
        "pontuacao_de_recuperacao_pct": "recovery_score_pct",
        "frequencia_cardiaca_em_repouso_bpm": "resting_heart_rate_bpm",
        "variabilidade_da_frequencia_cardiaca_ms": "heart_rate_variability_ms",
        "temp_da_pele_celsius": "skin_temp_celsius",
        "pct_de_oxigenio_no_sangue": "blood_oxygen_pct",   // "% de oxigênio no sangue" → leading % becomes pct_…
        "esforco_diario": "day_strain",
        "energia_queimada_cal": "energy_burned_cal",
        "fc_media_bpm": "average_hr_bpm",
        "inicio_do_sono": "sleep_onset",
        "inicio_da_vigilia": "wake_onset",
        "desempenho_do_sono_pct": "sleep_performance_pct",
        "frequencia_respiratoria_rpm": "respiratory_rate_rpm",
        "duracao_do_sono_min": "asleep_duration_min",
        "duracao_na_cama_min": "in_bed_duration_min",
        "duracao_do_sono_leve_min": "light_sleep_duration_min",
        "duracao_profundo_sono_min": "deep_sws_duration_min",   // "Duração profundo (Sono) (min)"
        "duracao_rem_min": "rem_duration_min",
        "duracao_de_vigilia_min": "awake_duration_min",
        "necessidade_de_sono_min": "sleep_need_min",
        "debito_de_sono_min": "sleep_debt_min",
        "eficacia_do_sono_pct": "sleep_efficiency_pct",
        "consistencia_do_sono_pct": "sleep_consistency_pct",
        "sesta": "nap",
        "hora_de_inicio_do_treino": "workout_start_time",
        "hora_de_fim_do_treino": "workout_end_time",
        "nome_da_atividade": "activity_name",
        "esforco_da_atividade": "activity_strain",
        "zona_1_de_fc_pct": "hr_zone_1_pct",
        "zona_2_de_fc_pct": "hr_zone_2_pct",
        "zona_3_de_fc_pct": "hr_zone_3_pct",
        "zona_4_de_fc_pct": "hr_zone_4_pct",
        "zona_5_de_fc_pct": "hr_zone_5_pct",
        "texto_de_pergunta": "question_text",
        "respondeu_sim": "answered_yes_no",
        "notas": "notes",
    ]
}

// MARK: - Tolerant CSV reader

/// A tolerant, header-name-driven CSV parser.
///
/// - Handles UTF-8 BOM, quoted fields with embedded commas/quotes/newlines
///   (RFC-4180 style with `""` escaping), and CRLF or LF line endings.
/// - Exposes rows as `[normalizedHeader: rawCellString]` so callers match
///   columns by name; missing columns simply return `nil`.
struct CSVTable {
    /// Original header strings, in file order.
    let headers: [String]
    /// Normalized header keys, parallel to `headers`.
    let normalizedHeaders: [String]
    /// Rows; each is a normalized-key → cell-value dictionary.
    let rows: [[String: String]]

    /// Parse CSV text (BOM already advisable to strip, but handled here too).
    init(text rawText: String) {
        let text = BOM.stripString(rawText)
        // Detect the field delimiter from the header line. WHOOP exports are comma-separated, but other
        // sources are not: a real Oura account-export CSV uses `;` (and some locales' spreadsheet exports
        // use `;` or a tab). Sniffing per file lets one parser read all of them; default stays `,` so the
        // WHOOP path is byte-for-byte unchanged. (issue #862)
        let delimiter = CSVTable.detectDelimiter(text)
        var records = CSVTable.parseRecords(text, delimiter: delimiter)
        guard !records.isEmpty else {
            self.headers = []
            self.normalizedHeaders = []
            self.rows = []
            return
        }
        let headerRow = records.removeFirst()
        self.headers = headerRow
        let normHeaders = headerRow.map { HeaderNorm.normalize($0) }
        self.normalizedHeaders = normHeaders

        var parsedRows: [[String: String]] = []
        parsedRows.reserveCapacity(records.count)
        for fields in records {
            // Skip completely blank lines.
            if fields.count == 1, fields[0].trimmingCharacters(in: .whitespaces).isEmpty {
                continue
            }
            var dict: [String: String] = [:]
            for (i, key) in normHeaders.enumerated() where !key.isEmpty {
                let value = i < fields.count ? fields[i] : ""
                // First non-empty header wins if duplicated (rare).
                if dict[key] == nil || dict[key]!.isEmpty {
                    dict[key] = value
                }
            }
            parsedRows.append(dict)
        }
        self.rows = parsedRows
    }

    /// Parse from raw `Data` (strips UTF-8 BOM, decodes UTF-8 with a latin-1
    /// fallback for the rare malformed export).
    init(data: Data) {
        let clean = BOM.stripUTF8(data)
        let text = String(data: clean, encoding: .utf8)
            ?? String(data: clean, encoding: .isoLatin1)
            ?? ""
        self.init(text: text)
    }

    // MARK: Delimiter detection

    /// Sniff the field delimiter from the FIRST (header) line of a CSV: whichever of `,`, `;` or tab
    /// appears most outside quotes. Defaults to `,` (so WHOOP / Fitbit exports are unaffected) when the
    /// header has none of them. Only the header line is scanned, so it's O(header length). (issue #862)
    static func detectDelimiter(_ text: String) -> Character {
        var commas = 0, semis = 0, tabs = 0
        var inQuotes = false
        for ch in text.unicodeScalars {
            if ch == "\"" { inQuotes.toggle(); continue }
            if inQuotes { continue }
            if ch == "\n" || ch == "\r" { break }   // header line only
            switch ch {
            case ",":  commas += 1
            case ";":  semis += 1
            case "\t": tabs += 1
            default:   break
            }
        }
        if semis > commas && semis >= tabs { return ";" }
        if tabs > commas && tabs > semis { return "\t" }
        return ","
    }

    // MARK: RFC-4180-ish record splitter

    /// Split CSV text into records of fields, honouring quotes and escaped
    /// quotes, and treating CRLF / CR / LF uniformly as row terminators.
    /// `delimiter` is the field separator (auto-detected per file; `,` by default).
    static func parseRecords(_ text: String, delimiter: Character = ",") -> [[String]] {
        let sep = delimiter.unicodeScalars.first ?? ","
        var records: [[String]] = []
        var field = ""
        var record: [String] = []
        var inQuotes = false
        var sawAnyField = false

        var iterator = text.unicodeScalars.makeIterator()
        var pending: Unicode.Scalar? = nil

        func nextScalar() -> Unicode.Scalar? {
            if let p = pending { pending = nil; return p }
            return iterator.next()
        }

        while let scalar = nextScalar() {
            if inQuotes {
                if scalar == "\"" {
                    // Look ahead for an escaped quote ("").
                    if let look = iterator.next() {
                        if look == "\"" {
                            field.unicodeScalars.append("\"")
                        } else {
                            inQuotes = false
                            pending = look
                        }
                    } else {
                        inQuotes = false
                    }
                } else {
                    field.unicodeScalars.append(scalar)
                }
            } else {
                switch scalar {
                case "\"":
                    inQuotes = true
                    sawAnyField = true
                case sep:
                    record.append(field)
                    field = ""
                    sawAnyField = true
                case "\r":
                    // Consume an optional following \n (CRLF).
                    if let look = iterator.next(), look != "\n" {
                        pending = look
                    }
                    record.append(field)
                    records.append(record)
                    field = ""
                    record = []
                    sawAnyField = false
                case "\n":
                    record.append(field)
                    records.append(record)
                    field = ""
                    record = []
                    sawAnyField = false
                default:
                    field.unicodeScalars.append(scalar)
                    sawAnyField = true
                }
            }
        }
        // Flush the final field/record if the file didn't end with a newline.
        if sawAnyField || !field.isEmpty || !record.isEmpty {
            record.append(field)
            records.append(record)
        }
        return records
    }
}

// MARK: - Cell accessors

extension Dictionary where Key == String, Value == String {
    /// First non-empty cell among the given normalized keys, trimmed; `nil` if
    /// absent or blank.
    func cell(_ keys: String...) -> String? {
        for k in keys {
            if let v = self[k] {
                let t = v.trimmingCharacters(in: .whitespacesAndNewlines)
                if !t.isEmpty { return t }
            }
        }
        return nil
    }

    /// Parse a cell as a finite `Double`, tolerating thousands separators and stray
    /// units accidentally left in the cell.
    func double(_ keys: String...) -> Double? {
        for k in keys {
            if let v = self[k] {
                let t = v.trimmingCharacters(in: .whitespacesAndNewlines)
                if t.isEmpty { continue }
                if let d = Double(t) {
                    if d.isFinite { return d }
                    continue
                }
                // Tolerate values like "1,234" or "62 ms".
                let cleaned = t
                    .replacingOccurrences(of: ",", with: "")
                    .components(separatedBy: CharacterSet(charactersIn: "0123456789.+-eE").inverted)
                    .joined()
                if let d = Double(cleaned), d.isFinite { return d }
            }
        }
        return nil
    }

    /// Parse a cell as a boolean (`true`/`yes`/`1`).
    func bool(_ keys: String...) -> Bool? {
        for k in keys {
            if let v = self[k] {
                let t = v.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
                if t.isEmpty { continue }
                if ["true", "yes", "1", "y"].contains(t) { return true }
                if ["false", "no", "0", "n"].contains(t) { return false }
            }
        }
        return nil
    }
}

// MARK: - Whoop timestamp parsing

enum WhoopTime {
    /// Parse a `Cycle timezone` string like `UTC+01:00`, `UTC-05:00`, `+01:00`,
    /// or `Z` into an offset in **minutes**.
    static func tzOffsetMinutes(_ raw: String?) -> Int {
        guard var s = raw?.trimmingCharacters(in: .whitespaces), !s.isEmpty else { return 0 }
        let upper = s.uppercased()
        if upper == "UTC" || upper == "Z" || upper == "GMT" { return 0 }
        if upper.hasPrefix("UTC") { s = String(s.dropFirst(3)) }
        else if upper.hasPrefix("GMT") { s = String(s.dropFirst(3)) }
        s = s.trimmingCharacters(in: .whitespaces)
        if s.isEmpty || s == "Z" { return 0 }

        var sign = 1
        if s.hasPrefix("+") { s.removeFirst() }
        else if s.hasPrefix("-") { sign = -1; s.removeFirst() }

        // Accept HH:MM or HHMM.
        let comps = s.split(separator: ":", maxSplits: 1, omittingEmptySubsequences: false)
        var hours = 0, minutes = 0
        if comps.count == 2 {
            hours = Int(comps[0]) ?? 0
            minutes = Int(comps[1]) ?? 0
        } else {
            let digits = String(s.prefix(while: { $0.isNumber }))
            if digits.count >= 3 {
                hours = Int(digits.prefix(digits.count - 2)) ?? 0
                minutes = Int(digits.suffix(2)) ?? 0
            } else {
                hours = Int(digits) ?? 0
            }
        }
        return sign * (hours * 60 + minutes)
    }

    /// Parse a Whoop CSV timestamp `YYYY-MM-DD HH:MM:SS` interpreted in the
    /// timezone given by `offsetMinutes`, returning a UTC `Date`.
    ///
    /// Some exports already include an offset inside the timestamp itself
    /// (e.g. `2024-01-02 03:04:05+0000`); when present that wins.
    static func parse(_ raw: String?, offsetMinutes: Int) -> Date? {
        guard let s0 = raw?.trimmingCharacters(in: .whitespaces), !s0.isEmpty else { return nil }

        // 1) ISO-8601 with embedded offset (e.g. "...T...Z", "...+01:00").
        if let d = isoFormatter.date(from: s0) { return d }
        if let d = isoFormatterFractional.date(from: s0) { return d }

        // 2) Plain "YYYY-MM-DD HH:MM:SS" or with a 'T'.
        let normalized = s0.replacingOccurrences(of: "T", with: " ")
        // Reuse one formatter (allocating a DateFormatter per CSV row was a measurable cost on
        // imports with tens of thousands of rows). Imports run on a single thread, so the shared
        // mutable formatter is safe; only timeZone/dateFormat are set per parse.
        let fmt = plainFormatter
        fmt.timeZone = TimeZone(secondsFromGMT: offsetMinutes * 60) ?? TimeZone(identifier: "UTC")!
        for pattern in ["yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd"] {
            fmt.dateFormat = pattern
            if let d = fmt.date(from: normalized) { return d }
        }
        return nil
    }

    /// Parse only an ISO-8601 timestamp that carries an **embedded UTC offset** (e.g. `…Z`,
    /// `…+01:00`), returning the absolute `Date`. Returns nil for zoneless strings, so callers can
    /// distinguish a timestamp whose offset is authoritative from a zoneless wall-clock one that must
    /// be interpreted in a chosen timezone (used by the Hevy lifting importer, #649).
    static func parseISOWithOffset(_ raw: String?) -> Date? {
        guard let s = raw?.trimmingCharacters(in: .whitespaces), !s.isEmpty else { return nil }
        if let d = isoFormatter.date(from: s) { return d }
        if let d = isoFormatterFractional.date(from: s) { return d }
        return nil
    }

    private static let plainFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.calendar = Calendar(identifier: .gregorian)
        return f
    }()

    private static let isoFormatter: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime]
        return f
    }()

    private static let isoFormatterFractional: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return f
    }()
}

struct WhoopExportImporter {
func parseCycles(_ table: CSVTable) -> [WhoopCycleRow] {
        var out: [WhoopCycleRow] = []
        out.reserveCapacity(table.rows.count)
        for row in table.rows {
            let tz = WhoopTime.tzOffsetMinutes(row.cell("cycle_timezone"))

            var r = WhoopCycleRow()
            r.tzOffsetMin = tz
            r.cycleStart = WhoopTime.parse(row.cell("cycle_start_time"), offsetMinutes: tz)
            r.cycleEnd   = WhoopTime.parse(row.cell("cycle_end_time"), offsetMinutes: tz)

            // Skip rows with no usable timestamp at all.
            if r.cycleStart == nil && r.cycleEnd == nil { continue }

            r.recoveryScore    = row.double("recovery_score_pct")
            r.restingHeartRate = ImportNumericSafety.integerValue(row.double("resting_heart_rate_bpm", "resting_heart_rate"))
            r.hrvMs            = row.double("heart_rate_variability_ms", "heart_rate_variability_rmssd_ms")
            r.skinTempCelsius  = row.double("skin_temp_celsius", "skin_temp_f")
            r.bloodOxygenPct   = row.double("blood_oxygen_pct", "blood_oxygen_pct_pct")
            r.dayStrain        = row.double("day_strain")
            r.energyKcal       = row.double("energy_burned_cal")  // CSV "(cal)" == kcal
            r.avgHeartRate     = ImportNumericSafety.integerValue(row.double("average_hr_bpm", "average_heart_rate_bpm"))
            r.maxHeartRate     = ImportNumericSafety.integerValue(row.double("max_hr_bpm", "max_heart_rate_bpm"))

            r.sleepOnset = WhoopTime.parse(row.cell("sleep_onset"), offsetMinutes: tz)
            r.wakeOnset  = WhoopTime.parse(row.cell("wake_onset"), offsetMinutes: tz)

            r.sleepPerformancePct = row.double("sleep_performance_pct")
            r.respiratoryRate     = row.double("respiratory_rate_rpm", "respiratory_rate")
            r.asleepDurationMin   = row.double("asleep_duration_min")
            r.inBedDurationMin    = row.double("in_bed_duration_min")
            r.lightSleepDurationMin = row.double("light_sleep_duration_min")
            r.deepSleepDurationMin  = row.double("deep_sws_duration_min", "deep_sleep_duration_min")
            r.remDurationMin        = row.double("rem_duration_min")
            r.awakeDurationMin      = row.double("awake_duration_min")
            r.sleepEfficiencyPct    = row.double("sleep_efficiency_pct")
            r.sleepConsistencyPct   = row.double("sleep_consistency_pct")
            r.sleepNeedMin          = row.double("sleep_need_min")
            r.sleepDebtMin          = row.double("sleep_debt_min")

            out.append(r)
        }
        return out
    }
func parseWorkouts(_ table: CSVTable) -> [WhoopWorkoutRow] {
        var out: [WhoopWorkoutRow] = []
        out.reserveCapacity(table.rows.count)
        for row in table.rows {
            let tz = WhoopTime.tzOffsetMinutes(row.cell("cycle_timezone"))

            var r = WhoopWorkoutRow()
            r.tzOffsetMin = tz
            r.cycleStart   = WhoopTime.parse(row.cell("cycle_start_time"), offsetMinutes: tz)
            r.workoutStart = WhoopTime.parse(row.cell("workout_start_time"), offsetMinutes: tz)
            r.workoutEnd   = WhoopTime.parse(row.cell("workout_end_time"), offsetMinutes: tz)

            if r.workoutStart == nil && r.workoutEnd == nil && r.cycleStart == nil { continue }

            r.activityName   = row.cell("activity_name")
            // Parsed VERBATIM (WHOOP's 0–21 scale) to preserve the CSV round-trip contract; the
            // 0–21→0–100 Effort rescale is applied at the store-write (WhoopImporter), like day_strain.
            r.activityStrain = row.double("activity_strain")
            r.energyKcal     = row.double("energy_burned_cal")  // CSV "(cal)" == kcal
            r.avgHeartRate   = ImportNumericSafety.integerValue(row.double("average_hr_bpm", "average_heart_rate_bpm"))
            r.maxHeartRate   = ImportNumericSafety.integerValue(row.double("max_hr_bpm", "max_heart_rate_bpm"))

            r.hrZone1Pct = row.double("hr_zone_1_pct", "zone_1_pct", "hr_zone_1_pct_pct")
            r.hrZone2Pct = row.double("hr_zone_2_pct", "zone_2_pct", "hr_zone_2_pct_pct")
            r.hrZone3Pct = row.double("hr_zone_3_pct", "zone_3_pct", "hr_zone_3_pct_pct")
            r.hrZone4Pct = row.double("hr_zone_4_pct", "zone_4_pct", "hr_zone_4_pct_pct")
            r.hrZone5Pct = row.double("hr_zone_5_pct", "zone_5_pct", "hr_zone_5_pct_pct")

            // Optional GPS / distance / altitude columns.
            r.distanceMeters       = row.double("distance_meters", "distance_meter")
            r.altitudeGainMeters   = row.double("altitude_gain_meters", "altitude_gain_meter")
            r.altitudeChangeMeters = row.double("altitude_change_meters", "altitude_change_meter")

            out.append(r)
        }
        return out
    }
}
import XCTest


final class ImportNumericSafetyTests: XCTestCase {
    func testIntegerConversionPreservesRoundingAndRejectsUnrepresentableValues() {
        XCTAssertEqual(ImportNumericSafety.integer(80.6, rounding: .toNearestOrAwayFromZero), 81)
        XCTAssertEqual(ImportNumericSafety.integer(80.6), 80)
        XCTAssertEqual(ImportNumericSafety.integer(-80.6), -80)
        XCTAssertEqual(ImportNumericSafety.integer(Double(Int.min)), Int.min)
        for value in [Double.nan, .infinity, -.infinity, Double(Int.max), 1e100, -1e100] {
            XCTAssertNil(ImportNumericSafety.integer(value))
        }
        XCTAssertNil(ImportNumericSafety.integer(nil))
    }

    func testWhoopCycleParsingRejectsUnrepresentableHeartRatesAndKeepsOtherValues() throws {
        let csv = """
        Cycle start time,Resting heart rate (bpm),Recovery score %,Average HR (bpm),Max HR (bpm)
        2026-10-20 08:00:00,1e100,78,80.6,1e100
        """
        let rows = WhoopExportImporter().parseCycles(CSVTable(data: Data(csv.utf8)))
        let row = try XCTUnwrap(rows.first)
        XCTAssertNil(row.restingHeartRate)
        XCTAssertNil(row.maxHeartRate)
        XCTAssertEqual(row.avgHeartRate, 80.6)
        XCTAssertEqual(row.recoveryScore, 78)
    }

    func testWhoopWorkoutParsingRejectsUnrepresentableHeartRates() throws {
        let csv = """
        Workout start time,Average HR (bpm),Max HR (bpm)
        2026-10-20 08:00:00,1e100,159.6
        """
        let rows = WhoopExportImporter().parseWorkouts(CSVTable(data: Data(csv.utf8)))
        let row = try XCTUnwrap(rows.first)
        XCTAssertNil(row.avgHeartRate)
        XCTAssertEqual(row.maxHeartRate, 159.6)
    }

    func testAppleInvalidReadingsDoNotPoisonValidDailyMeans() throws {
        for type in ["HeartRate", "RestingHeartRate", "WalkingHeartRateAverage"] {
            let samples = [Double.nan, .infinity, -.infinity, 1e100, 80.6].map { sample(type, value: $0) }
            let day = try XCTUnwrap(AppleHealthAggregator.daily(samples: samples).first)
            let value: Double?
            switch type {
            case "RestingHeartRate": value = day.restingHr
            case "WalkingHeartRateAverage": value = day.walkingHr
            default: value = day.avgHr; XCTAssertEqual(day.maxHr, 80.6)
            }
            XCTAssertEqual(value, 80.6)
        }
    }

    func testAppleStepTotalsRejectOverflowWithoutChangingValidSourceReduction() throws {
        let huge = Double(Int.max).nextDown
        let overflowing = try XCTUnwrap(AppleHealthAggregator.daily(samples: [
            sample("StepCount", value: huge), sample("StepCount", value: huge),
        ]).first)
        XCTAssertNil(overflowing.steps)

        let valid = try XCTUnwrap(AppleHealthAggregator.daily(samples: [
            sample("StepCount", value: .nan), sample("StepCount", value: 1e100),
            sample("StepCount", value: 1.5), sample("StepCount", value: 2.5),
        ]).first)
        XCTAssertEqual(valid.steps, 4)
    }

    private func sample(_ type: String, value: Double) -> HealthSample {
        let date = Date(timeIntervalSince1970: 1_792_454_400)
        return HealthSample(type: type, value: value, valueString: nil, unit: nil,
                            start: date, end: date, tzOffsetMin: 0, sourceName: "synthetic")
    }
}

@main struct Runner { static func main() { XCTMain([testCase([
("testIntegerConversionPreservesRoundingAndRejectsUnrepresentableValues", ImportNumericSafetyTests.testIntegerConversionPreservesRoundingAndRejectsUnrepresentableValues),
("testWhoopCycleParsingRejectsUnrepresentableHeartRatesAndKeepsOtherValues", ImportNumericSafetyTests.testWhoopCycleParsingRejectsUnrepresentableHeartRatesAndKeepsOtherValues),
("testWhoopWorkoutParsingRejectsUnrepresentableHeartRates", ImportNumericSafetyTests.testWhoopWorkoutParsingRejectsUnrepresentableHeartRates),
("testAppleInvalidReadingsDoNotPoisonValidDailyMeans", ImportNumericSafetyTests.testAppleInvalidReadingsDoNotPoisonValidDailyMeans),
("testAppleStepTotalsRejectOverflowWithoutChangingValidSourceReduction", ImportNumericSafetyTests.testAppleStepTotalsRejectOverflowWithoutChangingValidSourceReduction)
])]) } }