# Synthetic release-hardening reproduction evidence

See the committed specialist reports for scope, commands and limitations.
All health inputs and credentials are synthetic/inert. No compiled build products are included.

- coach-audit-evidence/: ready Swift source/test snapshots and scripts, with their own README.
- ble-audit-evidence/: executed before/after production-method probes and protocol logs.
- data-audit-evidence/: generators and logs for real-SQLite/GRDB, reclip and DST probes.
- root-evidence/: import numeric parser/aggregator crash and XCTest sources; connection callback logs.

Temporary absolute paths in generators document this audit host. Set their repository/toolchain paths to your checkout before reuse. Native iOS tests in the repository remain required.

The root import snapshots compile with Swift 6.4.1 using swiftc -module-cache-path <scratch> <file.swift> -o <binary>. The before executable intentionally terminates at the demonstrated NaN-to-Int trap; run with core dumps disabled. The tests executable runs five XCTest methods.
